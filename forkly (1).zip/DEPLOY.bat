@echo off
cd /d "%~dp0"
if not exist "src\App.tsx" (
  echo ERROR: wrong folder. Put DEPLOY.bat in the project root.
  pause
  exit /b 1
)
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed. Get it from https://nodejs.org
  pause
  exit /b 1
)
rem one-time: install dependencies
if not exist "node_modules" (
  echo Installing dependencies once...
  call npm install
)
rem first run = NEW Vercel project, every run after = update the SAME project
node scripts\deploy.mjs
if errorlevel 1 (
  echo.
  echo Failed. Read the error line above. "Cannot reach api.vercel.com" = network problem. 401/403 = check VERCEL_TOKEN in .env.local
)
pause
