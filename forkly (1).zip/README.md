# Forkly — AI-Powered Sales CRM Demo

A working CRM: capture restaurant leads, manage conversations, generate personalized AI follow-ups, require human approval, book demos, monitor follow-ups, track activity.

## Stack
Vite + React 19 + TypeScript + Tailwind CSS v4 + react-router-dom + Recharts + Zod + Supabase (optional) + Claude API (optional).

## Run
```bash
npm install
npm run dev
```
Build: `npm run build`.

## Setup (Supabase + n8n)
1. **Supabase** → SQL Editor → run `supabase/migrations/001_init.sql` then `002`, `003` and `004` (or just paste `supabase/RUN_ALL.sql`) (makes every table live).
2. Copy `.env.example` → `.env.local` and fill it (publishable key in `VITE_SUPABASE_PUBLISHABLE_KEY`, secret key only in `SUPABASE_SERVICE_ROLE_KEY`).
3. `npm install && npm run dev` — `/api/*` functions run inside the Vite dev server, so everything works locally.
4. **Vercel**: add the same variables in Project → Settings → Environment Variables, deploy.
   Open **Settings → Integrations** in the app to see what is connected.

## Troubleshooting: "Cannot reach <ref>.supabase.co"
1. Open supabase.com/dashboard. Is the project listed? If the ref in `.env.local` is not there, the project was deleted or belongs to another account: copy the URL from Project Settings -> API into `VITE_SUPABASE_URL` and `SUPABASE_URL`.
2. Project shows "Paused" (free plan pauses after inactivity): click **Restore project**, wait until Healthy.
3. Run `supabase/RUN_ALL.sql` in SQL Editor of that project (creates all tables).
4. Put the publishable key in `VITE_SUPABASE_PUBLISHABLE_KEY`, secret key in `SUPABASE_SERVICE_ROLE_KEY`.
5. Stop and restart `npm run dev` (Vite reads env only at start). On Vercel: change env vars, then Redeploy.

## How it flows
- Browser ⇄ Supabase (publishable key, RLS) — all CRM data, live-updated via Realtime.
- **Approve & Send** → `POST /api/approve` → Supabase (service key) → n8n `N8N_PATH_APPROVE` (header `x-webhook-secret`).
  Idempotent: a message already Sending/Accepted/Delivered is never re-sent; on failure the approval returns to Pending for retry.
- **Booking create/update/cancel** → `POST /api/bookings` → n8n `N8N_PATH_BOOKINGS`.
- **n8n → CRM**: `POST /api/n8n-callback` with header `x-webhook-secret`. Events: `message.status`, `message.inbound`, `lead.created`, `booking.status` (payloads documented at the top of `api/n8n-callback.ts`).
- If n8n/service key is not configured, Approve falls back to a simulated send; if Supabase is not configured the app runs on localStorage.

## n8n payload sent on approve (`message.approved`)
`{ event, approval_id, message_id, message_type, objective, content, lead:{id,name,restaurant_name,phone,phone_intl,email,source,status}, callback_url, sent_at }`
Respond with JSON like `{ "provider_message_id": "wamid...", "status": "Accepted by Provider" }` (any 2xx = accepted).

## Security notes
- `VITE_*` variables are public. The app refuses to use a `sb_secret_`/service_role key in the browser.
- RLS policies are permissive demo policies and `/api/*` has no user auth yet — add Supabase Auth before going to real customers.

## Professional features (added)
- **Ctrl/Cmd+K command palette**: search leads, offers, pages and quick actions.
- **Notification center**: pending approvals, overdue tasks, demos today, hot leads without follow-up, stale leads.
- **Reports**: funnel, source performance, team leaderboard, trend, CSV export.
- **Leads**: CSV import (validation + duplicate skip), bulk assign / bulk stage move, quick call and WhatsApp.
- **Automation rules** (Settings): round-robin assignment, auto first follow-up task, stale-lead threshold.
- **Templates**: message library with `{{variables}}`, insertable from WhatsApp.
- **Roles**: Admin / Sales Manager / Salesperson / Viewer permissions in the UI (`src/lib/permissions.ts`). Enforce the same rules with Supabase RLS before production.
- **Error boundary**: a crashing page no longer blanks the app.

## Campaigns, segments, win-back, analytics (page `/campaigns`)
Run `supabase/migrations/005_campaigns.sql` (or `RUN_ALL.sql`) first.
- **Campaigns**: name, segment, offer type (or a saved offer), message with `{{variables}}`, image/PDF, schedule, channel. Flow: Draft -> Submit -> manager **Approve** -> Sent (or Scheduled).
- **Segments**: interested-not-booked, demo-not-bought, past clients, no reply for N days, interested in a service (tags set on the lead profile).
- **Win-back**: finds Interested / Demo Booked / Trial leads idle for N days, prepares a message per lead, sends it to the **Approval Center**. Nothing goes out without a human approving.
- **Analytics**: sent, delivered, replies, interested, bookings per campaign (attribution windows shown in the UI).

### Consent and WhatsApp rules (enforced in UI and again on the server)
- Only `consent_status = opted_in` leads are messaged. Default is `unknown` (= not messaged). Record consent on the lead profile or in bulk (Segments tab) with a source.
- Replies such as STOP / إيقاف / الغاء set `opted_out` automatically (`/api/n8n-callback`, event `message.inbound`).
- WhatsApp: outside the 24h customer window only an **approved template** can be sent (campaign/win-back template name + language).
- Max one marketing message per contact per 7 days. Consent is re-checked at send time.

### n8n
- New webhook `N8N_PATH_CAMPAIGN` (default `dem_campaign`). Payload `event: "campaign.send"` with `recipients[]` (`message_id, phone_intl, content, use_template, ...`), `template`, `attachment`. Answer 2xx immediately, loop with delays, and report each result with `POST /api/n8n-callback` `message.status`.
- `/api/approve` payload now also has `template`, `use_template`, `campaign_id`.
- Scheduled sends: call `POST /api/campaigns-run` (header `x-webhook-secret`) every 5 minutes from an n8n Schedule Trigger. (Vercel Hobby crons are daily only, so no cron is added to `vercel.json`.)
- Meta Lead Ads: send `consent: true` in `lead.created` only if the form had an opt-in checkbox.

## My Tasks (`/my-day`) and manager Reports
- **My Tasks**: per salesperson: customers to follow up today, overdue, appointments in the next 14 days, completed tasks. Actions: call, WhatsApp, done, +1 day, new task. A lead's own "next follow-up" date counts unless a pending task already covers that lead. Managers/Admins can switch to any team member or the whole team.
- **Reports**: new leads, contacted, bookings, conversion rate, lead->booking rate, per-salesperson table (leads, contacted, won, conversion, bookings, overdue, response time), best lead sources (marked "Best"), CSV export. Managers/Admins (`report.team`) see everyone; other roles see only their own customers.
No new migration needed for these two.
