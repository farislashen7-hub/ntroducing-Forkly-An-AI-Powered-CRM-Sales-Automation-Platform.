// api/_lib/campaign.ts — sends one approved campaign. SERVER ONLY (service key).
//
// Rules re-checked here at send time, because consent can change between approval and a scheduled send:
//   1. lead is not archived and consent_status === 'opted_in'
//   2. lead has a phone (whatsapp/sms) or an email (email)
//   3. WhatsApp: outside the 24h customer-service window an approved template is required
//   4. at most one marketing message per contact per FREQUENCY_CAP_DAYS
//   5. idempotent: a lead that already has a non-failed message for this campaign is skipped
import type { SupabaseClient } from '@supabase/supabase-js';
import { callN8n } from './n8n.js';
import { toIntl } from './phone.js';

export const WINDOW_HOURS = 24;
export const FREQUENCY_CAP_DAYS = 7;

export interface CampaignRow {
  id: string; name: string; message: string; channel: 'whatsapp' | 'sms' | 'email';
  template_name: string | null; template_language: string | null;
  attachment_url: string | null; attachment_name: string | null; attachment_type: string | null;
  include_optout: boolean; scheduled_at: string | null; status: string;
  audience_lead_ids: string[] | null; approved_by: string | null;
}
interface Cfg { campaignUrl: string; secret: string; callbackUrl: string; defaultCC: string }

const isArabic = (s: string) => /[\u0600-\u06FF]/.test(s);
const optOut = (body: string) => (isArabic(body) ? 'لإيقاف الرسائل الترويجية أرسل "إيقاف".' : 'Reply STOP to unsubscribe.');

export function renderVars(body: string, lead: { name: string; restaurant_name: string; phone: string }, owner: string): string {
  const v: Record<string, string> = {
    name: lead.name, first_name: lead.name.split(/\s+/)[0] || lead.name,
    restaurant: lead.restaurant_name, phone: lead.phone, owner,
  };
  return body.replace(/\{\{\s*(\w+)\s*\}\}/g, (_, k: string) => v[k] ?? `{{${k}}}`);
}

const chunk = <T>(a: T[], n: number) => Array.from({ length: Math.ceil(a.length / n) }, (_, i) => a.slice(i * n, i * n + n));

export interface DispatchResult { ok: boolean; status: string; sent: number; skipped: number; error?: string }

export async function dispatchCampaign(sb: SupabaseClient, cfg: Cfg, c: CampaignRow, reviewer: string | null): Promise<DispatchResult> {
  const now = new Date();
  const nowIso = now.toISOString();

  // Atomic claim: only one caller can move the campaign into Sending (double click, cron + manual, retries).
  const { data: claimed } = await sb.from('campaigns')
    .update({ status: 'Sending', approved_by: reviewer ?? c.approved_by, last_error: null, updated_at: nowIso })
    .eq('id', c.id).in('status', ['Pending Approval', 'Scheduled', 'Failed']).select('id');
  if (!claimed || claimed.length === 0) return { ok: false, status: 'Skipped', sent: 0, skipped: 0, error: 'Campaign is already sending, sent or cancelled' };

  const fail = async (error: string): Promise<DispatchResult> => {
    await sb.from('campaigns').update({ status: 'Failed', last_error: error, updated_at: new Date().toISOString() }).eq('id', c.id);
    return { ok: false, status: 'Failed', sent: 0, skipped: 0, error };
  };

  if (!cfg.campaignUrl || !cfg.secret) return fail('n8n campaign webhook is not configured (N8N_WEBHOOK_BASE / N8N_WEBHOOK_SECRET).');
  const ids = c.audience_lead_ids ?? [];
  if (!ids.length) return fail('Campaign has no recipients.');

  // ---- load what the eligibility rules need ----
  const leads: any[] = [];
  for (const part of chunk(ids, 100)) {
    const { data, error } = await sb.from('leads').select('*').in('id', part).eq('archived', false);
    if (error) return fail(`Could not load leads: ${error.message}`);
    leads.push(...(data ?? []));
  }
  const since = new Date(now.getTime() - FREQUENCY_CAP_DAYS * 86400000).toISOString();
  const windowStart = now.getTime() - WINDOW_HOURS * 3600000;

  const { data: inbound } = await sb.from('conversations').select('lead_id,created_at').eq('direction', 'inbound').gte('created_at', new Date(windowStart).toISOString()).limit(5000);
  const inWindow = new Set((inbound ?? []).map(r => r.lead_id as string));

  const { data: recent } = await sb.from('messages').select('lead_id,campaign_id,objective,status').eq('direction', 'outbound').gte('created_at', since).in('status', ['Pending Approval', 'Approved', 'Sending', 'Accepted by Provider', 'Delivered']).limit(5000);
  const capped = new Set<string>();
  for (const m of recent ?? []) {
    if (m.campaign_id === c.id) continue; // this campaign's own messages are handled by `done` below
    if (m.campaign_id || /win-?back|campaign/i.test(m.objective ?? '')) capped.add(m.lead_id);
  }
  // leads that already got a non-failed message from THIS campaign (makes retries idempotent)
  const done = new Set<string>();
  const { data: mine } = await sb.from('messages').select('lead_id,status').eq('campaign_id', c.id).limit(5000);
  for (const m of mine ?? []) if (m.status !== 'Failed') done.add(m.lead_id);

  const { data: owners } = await sb.from('profiles').select('id,full_name');
  const ownerName = new Map<string, string>((owners ?? []).map(p => [p.id as string, p.full_name as string] as [string, string]));

  // ---- eligibility ----
  const recipients: { lead: any; content: string; phone_intl: string | null }[] = [];
  let skipped = 0;
  for (const l of leads) {
    if (done.has(l.id)) { skipped++; continue; }
    if (l.consent_status !== 'opted_in') { skipped++; continue; }
    const phone = toIntl(l.phone ?? '', cfg.defaultCC);
    if (c.channel === 'email' ? !/\S+@\S+\.\S+/.test(l.email ?? '') : !phone) { skipped++; continue; }
    if (c.channel === 'whatsapp' && !c.template_name && !inWindow.has(l.id)) { skipped++; continue; }
    if (capped.has(l.id)) { skipped++; continue; }
    let content = renderVars(c.message, l, ownerName.get(l.assigned_to) ?? 'Forkly');
    if (c.include_optout) content = `${content.trimEnd()}\n\n${optOut(content)}`;
    recipients.push({ lead: l, content, phone_intl: phone });
  }
  if (!recipients.length) return fail(`No eligible recipients (${skipped} skipped: consent, contact details, 24h window or frequency cap).`);

  // ---- create message rows (status Sending) ----
  const objective = `Campaign: ${c.name}`.slice(0, 120);
  const rows = recipients.map(r => ({
    lead_id: r.lead.id, content: r.content, message_type: c.channel, direction: 'outbound', status: 'Sending',
    objective, simulated: false, campaign_id: c.id, template_name: c.template_name, template_language: c.template_name ? (c.template_language ?? 'ar') : null,
  }));
  const messageIds = new Map<string, string>(); // lead_id -> message_id
  for (const part of chunk(rows, 200)) {
    const { data, error } = await sb.from('messages').insert(part).select('id,lead_id');
    if (error) return fail(`Could not create messages: ${error.message}`);
    for (const m of data ?? []) messageIds.set(m.lead_id as string, m.id as string);
  }

  // ---- hand the whole batch to n8n (it should answer 2xx immediately and loop with delays) ----
  const result = await callN8n(cfg.campaignUrl, {
    event: 'campaign.send',
    campaign_id: c.id, campaign_name: c.name, channel: c.channel,
    template: c.template_name ? { name: c.template_name, language: c.template_language ?? 'ar' } : null,
    attachment: c.attachment_url ? { url: c.attachment_url, name: c.attachment_name, type: c.attachment_type } : null,
    callback_url: cfg.callbackUrl || null,
    sent_at: nowIso,
    recipients: recipients.map(r => ({
      message_id: messageIds.get(r.lead.id), lead_id: r.lead.id,
      name: r.lead.name, first_name: String(r.lead.name).split(/\s+/)[0], restaurant_name: r.lead.restaurant_name,
      phone_intl: r.phone_intl, email: r.lead.email ?? null,
      content: r.content, use_template: c.channel === 'whatsapp' && Boolean(c.template_name),
    })),
  }, 30000);

  const allIds = [...messageIds.values()];
  if (!result.ok) {
    for (const part of chunk(allIds, 100)) await sb.from('messages').update({ status: 'Failed', updated_at: new Date().toISOString() }).in('id', part);
    await sb.from('activity_logs').insert({ lead_id: null, actor_id: reviewer, event_type: 'Message Failed', description: `Campaign "${c.name}" failed: ${result.error}`, metadata: { campaignId: c.id } });
    return fail(result.error ?? 'n8n error');
  }

  // optional per-message results from n8n: { results: [{ message_id, status, provider_message_id }] }
  const per = new Map<string, { status?: string; provider_message_id?: string }>();
  for (const r of (result.data?.results ?? []) as any[]) if (r?.message_id) per.set(r.message_id, r);
  const okStatus = (s?: string) => (s === 'Delivered' || s === 'Failed' ? s : 'Accepted by Provider');
  const stamp = new Date().toISOString();
  const bulkAccepted = allIds.filter(id => !per.has(id));
  for (const part of chunk(bulkAccepted, 100)) await sb.from('messages').update({ status: 'Accepted by Provider', updated_at: stamp }).in('id', part);
  for (const [id, r] of per) await sb.from('messages').update({ status: okStatus(r.status), provider_message_id: r.provider_message_id ?? null, updated_at: stamp }).eq('id', id);

  for (const part of chunk(recipients.map(r => r.lead.id as string), 100)) await sb.from('leads').update({ last_contact_at: stamp, updated_at: stamp }).in('id', part);
  await sb.from('campaigns').update({ status: 'Sent', sent_at: stamp, updated_at: stamp }).eq('id', c.id);
  await sb.from('activity_logs').insert({ lead_id: null, actor_id: reviewer, event_type: 'Campaign Sent', description: `Campaign "${c.name}" handed to n8n: ${recipients.length} recipients, ${skipped} skipped`, metadata: { campaignId: c.id, recipients: recipients.length, skipped } });
  return { ok: true, status: 'Sent', sent: recipients.length, skipped };
}
