// api/_lib/env.ts — server-only configuration (never imported by src/)
const clean = (v?: string) => (v ?? '').trim();

export function getConfig() {
  const base = clean(process.env.N8N_WEBHOOK_BASE).replace(/\/+$/, '');
  const approvePath = clean(process.env.N8N_PATH_APPROVE).replace(/^\/+/, '');
  const bookingsPath = clean(process.env.N8N_PATH_BOOKINGS).replace(/^\/+/, '');
  const regeneratePath = (clean(process.env.N8N_PATH_REGENERATE) || 'dem_regenerated').replace(/^\/+/, '');
  const wipePath = (clean(process.env.N8N_PATH_WIPE) || 'res-wipe-all').replace(/^\/+/, '');
  const campaignPath = (clean(process.env.N8N_PATH_CAMPAIGN) || 'dem_campaign').replace(/^\/+/, '');
  const secret = clean(process.env.N8N_WEBHOOK_SECRET);
  const supabaseUrl = clean(process.env.SUPABASE_URL) || clean(process.env.VITE_SUPABASE_URL);
  const serviceKey = clean(process.env.SUPABASE_SERVICE_ROLE_KEY);
  const publicUrl =
    clean(process.env.PUBLIC_APP_URL) ||
    (process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : '') ||
    (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : '');
  return {
    n8nBase: base,
    approveUrl: base && approvePath ? `${base}/${approvePath}` : '',
    bookingsUrl: base && bookingsPath ? `${base}/${bookingsPath}` : '',
    regenerateUrl: base ? `${base}/${regeneratePath}` : '',
    wipeUrl: base ? `${base}/${wipePath}` : '',
    campaignUrl: base ? `${base}/${campaignPath}` : '',
    campaignPath,
    approvePath, bookingsPath, regeneratePath, wipePath, secret,
    supabaseUrl, serviceKey,
    defaultCC: clean(process.env.DEFAULT_GULF_CC) || '966',
    callbackUrl: publicUrl ? `${publicUrl}/api/n8n-callback` : '',
  };
}

export function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' } });
}
