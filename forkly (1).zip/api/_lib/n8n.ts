// api/_lib/n8n.ts — POST to an n8n Production webhook with the shared secret
import { getConfig } from './env.js';

export interface N8nResult { ok: boolean; status: number; data: any; error?: string }

export async function callN8n(url: string, payload: unknown, timeoutMs = 25000): Promise<N8nResult> {
  const { secret } = getConfig();
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: 'POST',
      signal: ctrl.signal,
      headers: {
        'content-type': 'application/json',
        'x-webhook-secret': secret,
        'ngrok-skip-browser-warning': 'true', // free ngrok shows an interstitial otherwise
        'user-agent': 'forkly-crm/1.0',
      },
      body: JSON.stringify(payload),
    });
    const text = await res.text();
    let data: any = null;
    try { data = text ? JSON.parse(text) : null; } catch { data = { raw: text.slice(0, 500) }; }
    if (!res.ok) return { ok: false, status: res.status, data, error: `n8n responded ${res.status}${data?.message ? `: ${data.message}` : ''}` };
    return { ok: true, status: res.status, data };
  } catch (e) {
    const err = e as Error;
    return { ok: false, status: 0, data: null, error: err.name === 'AbortError' ? 'n8n timeout' : `n8n unreachable: ${err.message}` };
  } finally {
    clearTimeout(t);
  }
}
