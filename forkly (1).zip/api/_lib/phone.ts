// api/_lib/phone.ts — normalise to digits-only international format (wa.me style)
export function toIntl(raw: string, defaultCC: string): string | null {
  let d = (raw || '').replace(/[^\d+]/g, '');
  const hadPlus = d.startsWith('+');
  d = d.replace(/\D/g, '');
  if (!d) return null;
  if (!hadPlus && d.startsWith('00')) d = d.slice(2);
  else if (!hadPlus && d.startsWith('0')) d = defaultCC + d.slice(1); // local 05xxxxxxxx -> 9665xxxxxxxx
  else if (!hadPlus && d.length <= 9) d = defaultCC + d;              // 5xxxxxxxx -> 9665xxxxxxxx
  return d.length >= 8 && d.length <= 15 ? d : null;
}
