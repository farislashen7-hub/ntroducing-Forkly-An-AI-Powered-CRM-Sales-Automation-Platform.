// api/_lib/supabase.ts — service-role client (bypasses RLS). SERVER ONLY.
import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { getConfig } from './env.js';

let client: SupabaseClient | null = null;
export function admin(): SupabaseClient | null {
  const { supabaseUrl, serviceKey } = getConfig();
  if (!supabaseUrl || !serviceKey) return null;
  if (!client) client = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
  return client;
}

export const isUuid = (v: unknown): v is string =>
  typeof v === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
