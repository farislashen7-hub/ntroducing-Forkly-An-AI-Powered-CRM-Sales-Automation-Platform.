// POST /api/approve  { approval_id, edited_content?, reviewer_id? }
// Approves a drafted message and hands it to n8n (WhatsApp send). Authoritative
// idempotency lives here: a message already Sending/Accepted/Delivered is never re-sent.
import { getConfig, json } from './_lib/env.js';
import { admin, isUuid } from './_lib/supabase.js';
import { callN8n } from './_lib/n8n.js';
import { toIntl } from './_lib/phone.js';

export default {
  async fetch(request: Request): Promise<Response> {
    if (request.method !== 'POST') return json({ ok: false, error: 'Method not allowed' }, 405);
    const cfg = getConfig();
    const sb = admin();
    if (!sb || !cfg.approveUrl || !cfg.secret) {
      return json({ ok: false, error: 'Server not configured (Supabase service key / n8n webhook).' }, 503);
    }

    let body: { approval_id?: string; edited_content?: string; reviewer_id?: string };
    try { body = await request.json(); } catch { return json({ ok: false, error: 'Invalid JSON' }, 400); }
    if (!isUuid(body.approval_id)) return json({ ok: false, error: 'approval_id required' }, 400);
    const reviewer = isUuid(body.reviewer_id) ? body.reviewer_id : null;

    const { data: approval } = await sb.from('approvals').select('*').eq('id', body.approval_id).maybeSingle();
    if (!approval) return json({ ok: false, error: 'Approval not found' }, 404);
    if (approval.status !== 'Pending') return json({ ok: false, error: `Approval already ${approval.status}` }, 409);

    const { data: message } = await sb.from('messages').select('*').eq('id', approval.message_id).maybeSingle();
    if (!message) return json({ ok: false, error: 'Message not found' }, 404);
    const { data: lead } = await sb.from('leads').select('*').eq('id', message.lead_id).maybeSingle();
    if (!lead) return json({ ok: false, error: 'Lead not found' }, 404);

    const phone = toIntl(lead.phone, cfg.defaultCC);
    if (!phone) return json({ ok: false, error: `Invalid phone number for ${lead.name}: "${lead.phone}"` }, 422);

    const content = (body.edited_content ?? message.content ?? '').trim();
    if (!content) return json({ ok: false, error: 'Empty message' }, 422);

    // Marketing messages (campaign / win-back): consent is mandatory, and WhatsApp needs an approved template
    // unless the customer wrote to us in the last 24h. Checked BEFORE the message is claimed, so nothing changes on refusal.
    const isMarketing = Boolean(message.campaign_id) || /win-?back|campaign/i.test(message.objective ?? '');
    if (isMarketing) {
      if (lead.consent_status === 'opted_out') return json({ ok: false, error: `${lead.name} opted out of marketing messages.` }, 422);
      if (lead.consent_status !== 'opted_in') return json({ ok: false, error: `${lead.name} has no marketing consent on file. Record consent first.` }, 422);
      if (message.message_type === 'whatsapp' && !message.template_name) {
        const since = new Date(Date.now() - 24 * 3600000).toISOString();
        const { data: recent } = await sb.from('conversations').select('id').eq('lead_id', lead.id).eq('direction', 'inbound').gte('created_at', since).limit(1);
        if (!recent?.length) return json({ ok: false, error: `${lead.name} has not written in the last 24h. WhatsApp requires an approved template for this message.` }, 422);
      }
    }

    // Atomic claim — only one concurrent request can flip the message to Sending.
    const { data: claimed } = await sb.from('messages')
      .update({ status: 'Sending', content, updated_at: new Date().toISOString() })
      .eq('id', message.id)
      .in('status', ['Pending Approval', 'Drafted', 'Approved', 'Failed'])
      .select('id');
    if (!claimed || claimed.length === 0) return json({ ok: false, error: 'Message already sent or in flight' }, 409);

    const now = new Date().toISOString();
    await sb.from('approvals').update({ status: 'Approved', reviewed_by: reviewer, reviewed_at: now, approved_content: content }).eq('id', approval.id);
    await sb.from('activity_logs').insert({ lead_id: lead.id, actor_id: reviewer, event_type: 'Message Approved', description: 'Message approved', metadata: { messageId: message.id } });

    const result = await callN8n(cfg.approveUrl, {
      event: 'message.approved',
      approval_id: approval.id,
      message_id: message.id,
      message_type: message.message_type,
      objective: message.objective,
      content,
      lead: { id: lead.id, name: lead.name, restaurant_name: lead.restaurant_name, phone: lead.phone, phone_intl: phone, email: lead.email, source: lead.source, status: lead.status },
      callback_url: cfg.callbackUrl || null,
      campaign_id: message.campaign_id ?? null,
      // set for marketing messages that must go out as an approved WhatsApp template
      use_template: Boolean(message.template_name),
      template: message.template_name ? {
        name: message.template_name,
        language: message.template_language ?? 'ar',
        variables: { name: lead.name, first_name: String(lead.name).split(/\s+/)[0], restaurant: lead.restaurant_name },
      } : null,
      sent_at: now,
    });

    if (!result.ok) {
      // Back to a retryable state: message Failed, approval Pending again.
      await sb.from('messages').update({ status: 'Failed', updated_at: new Date().toISOString() }).eq('id', message.id);
      await sb.from('approvals').update({ status: 'Pending', reviewed_by: null, reviewed_at: null, approved_content: null }).eq('id', approval.id);
      await sb.from('activity_logs').insert({ lead_id: lead.id, actor_id: reviewer, event_type: 'Message Failed', description: `Send failed: ${result.error}`, metadata: { messageId: message.id, httpStatus: result.status } });
      return json({ ok: false, status: 'Failed', error: result.error }, 502);
    }

    const d = result.data ?? {};
    const providerId: string | null = d.provider_message_id ?? d.messages?.[0]?.id ?? d.message_id ?? d.id ?? null;
    const status = ['Delivered', 'Accepted by Provider'].includes(d.status) ? d.status : 'Accepted by Provider';
    await sb.from('messages').update({ status, provider_message_id: providerId, simulated: false, updated_at: new Date().toISOString() }).eq('id', message.id);
    await sb.from('leads').update({ last_contact_at: new Date().toISOString(), updated_at: new Date().toISOString() }).eq('id', lead.id);
    await sb.from('activity_logs').insert({ lead_id: lead.id, actor_id: reviewer, event_type: 'Message Sent', description: 'Message accepted by provider (via n8n)', metadata: { messageId: message.id, providerMessageId: providerId } });

    return json({ ok: true, status, provider_message_id: providerId, simulated: false });
  },
};
