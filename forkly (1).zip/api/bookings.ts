// POST /api/bookings  { booking_id, action: 'created' | 'updated' | 'cancelled' }
// Sends the booking (plus lead details) to n8n — Google Calendar / confirmation messages live there.
import { getConfig, json } from './_lib/env.js';
import { admin, isUuid } from './_lib/supabase.js';
import { callN8n } from './_lib/n8n.js';
import { toIntl } from './_lib/phone.js';

export default {
  async fetch(request: Request): Promise<Response> {
    if (request.method !== 'POST') return json({ ok: false, error: 'Method not allowed' }, 405);
    const cfg = getConfig();
    const sb = admin();
    if (!sb || !cfg.bookingsUrl || !cfg.secret) return json({ ok: false, error: 'Server not configured' }, 503);

    let body: { booking_id?: string; action?: string };
    try { body = await request.json(); } catch { return json({ ok: false, error: 'Invalid JSON' }, 400); }
    if (!isUuid(body.booking_id)) return json({ ok: false, error: 'booking_id required' }, 400);
    const action = ['created', 'updated', 'cancelled'].includes(body.action ?? '') ? body.action! : 'updated';

    const { data: booking } = await sb.from('bookings').select('*').eq('id', body.booking_id).maybeSingle();
    if (!booking) return json({ ok: false, error: 'Booking not found' }, 404);
    const { data: lead } = await sb.from('leads').select('*').eq('id', booking.lead_id).maybeSingle();
    const { data: owner } = booking.assigned_to
      ? await sb.from('profiles').select('full_name,email').eq('id', booking.assigned_to).maybeSingle()
      : { data: null };

    const time = String(booking.booking_time).slice(0, 5);
    const result = await callN8n(cfg.bookingsUrl, {
      event: `booking.${action}`,
      booking: {
        id: booking.id, status: booking.status, date: booking.booking_date, time,
        timezone: booking.timezone, notes: booking.notes,
        starts_at_local: `${booking.booking_date}T${time}:00`,
      },
      lead: lead && {
        id: lead.id, name: lead.name, restaurant_name: lead.restaurant_name,
        phone: lead.phone, phone_intl: toIntl(lead.phone, cfg.defaultCC), email: lead.email, status: lead.status,
      },
      owner: owner ?? null,
      callback_url: cfg.callbackUrl || null,
      sent_at: new Date().toISOString(),
    });

    await sb.from('activity_logs').insert({
      lead_id: booking.lead_id,
      event_type: result.ok ? 'Booking Created' : 'Message Failed',
      description: result.ok ? `Booking ${action} — synced to n8n` : `Booking sync to n8n failed: ${result.error}`,
      metadata: { bookingId: booking.id, action, n8nStatus: result.status },
    });

    if (!result.ok) return json({ ok: false, error: result.error }, 502);
    return json({ ok: true });
  },
};
