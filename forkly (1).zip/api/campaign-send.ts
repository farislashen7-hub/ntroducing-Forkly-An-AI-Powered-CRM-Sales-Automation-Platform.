// POST /api/campaign-send  { campaign_id, action: 'approve' | 'cancel', reviewer_id? }
//  approve: Pending Approval | Failed -> sends now, or -> Scheduled when scheduled_at is in the future.
//           (the scheduled run is done by POST /api/campaigns-run, see README)
//  cancel : Draft | Pending Approval | Scheduled -> Cancelled
import { getConfig, json } from './_lib/env.js';
import { admin, isUuid } from './_lib/supabase.js';
import { dispatchCampaign, type CampaignRow } from './_lib/campaign.js';

export default {
  async fetch(request: Request): Promise<Response> {
    if (request.method !== 'POST') return json({ ok: false, error: 'Method not allowed' }, 405);
    const cfg = getConfig();
    const sb = admin();
    if (!sb) return json({ ok: false, error: 'Server not configured (Supabase service key).' }, 503);

    let body: { campaign_id?: string; action?: string; reviewer_id?: string };
    try { body = await request.json(); } catch { return json({ ok: false, error: 'Invalid JSON' }, 400); }
    if (!isUuid(body.campaign_id)) return json({ ok: false, error: 'campaign_id required' }, 400);
    const reviewer = isUuid(body.reviewer_id) ? body.reviewer_id : null;
    const now = new Date().toISOString();

    const { data: c, error } = await sb.from('campaigns').select('*').eq('id', body.campaign_id).maybeSingle();
    if (error) return json({ ok: false, error: error.message }, 500);
    if (!c) return json({ ok: false, error: 'Campaign not found' }, 404);

    if (body.action === 'cancel') {
      const { data } = await sb.from('campaigns').update({ status: 'Cancelled', updated_at: now }).eq('id', c.id).in('status', ['Draft', 'Pending Approval', 'Scheduled']).select('id');
      if (!data?.length) return json({ ok: false, error: `Cannot cancel a campaign that is ${c.status}` }, 409);
      await sb.from('activity_logs').insert({ lead_id: null, actor_id: reviewer, event_type: 'Campaign Cancelled', description: `Campaign "${c.name}" cancelled`, metadata: { campaignId: c.id } });
      return json({ ok: true, status: 'Cancelled' });
    }

    if (body.action !== 'approve') return json({ ok: false, error: 'action must be approve or cancel' }, 422);
    if (!cfg.campaignUrl || !cfg.secret) return json({ ok: false, error: 'n8n campaign webhook is not configured (N8N_WEBHOOK_BASE / N8N_WEBHOOK_SECRET).' }, 503);
    if (!['Pending Approval', 'Failed'].includes(c.status)) return json({ ok: false, error: `Campaign is ${c.status}` }, 409);
    if (!c.message?.trim()) return json({ ok: false, error: 'Campaign message is empty' }, 422);
    if (!(c.audience_lead_ids ?? []).length) return json({ ok: false, error: 'Campaign has no recipients' }, 422);
    await sb.from('activity_logs').insert({ lead_id: null, actor_id: reviewer, event_type: 'Campaign Approved', description: `Campaign "${c.name}" approved`, metadata: { campaignId: c.id } });

    // future date -> keep it for the scheduler
    if (c.scheduled_at && new Date(c.scheduled_at).getTime() > Date.now() + 60_000) {
      await sb.from('campaigns').update({ status: 'Scheduled', approved_by: reviewer, last_error: null, updated_at: now }).eq('id', c.id).in('status', ['Pending Approval', 'Failed']);
      return json({ ok: true, status: 'Scheduled' });
    }

    const r = await dispatchCampaign(sb, cfg, c as CampaignRow, reviewer);
    return json(r, r.ok ? 200 : r.status === 'Skipped' ? 409 : 502);
  },
};
