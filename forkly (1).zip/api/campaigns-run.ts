// POST|GET /api/campaigns-run — sends every Scheduled campaign whose time has come.
// Call it every 5 minutes from an n8n "Schedule Trigger" (HTTP Request node, header x-webhook-secret)
// or from a Vercel Cron (sends `Authorization: Bearer $CRON_SECRET`; sub-daily crons need the Pro plan).
import { timingSafeEqual } from 'node:crypto';
import { getConfig, json } from './_lib/env.js';
import { admin } from './_lib/supabase.js';
import { dispatchCampaign, type CampaignRow } from './_lib/campaign.js';

const safeEq = (a: string, b: string) => {
  const A = Buffer.from(a), B = Buffer.from(b);
  return A.length === B.length && A.length > 0 && timingSafeEqual(A, B);
};

export default {
  async fetch(request: Request): Promise<Response> {
    const cfg = getConfig();
    const sb = admin();
    if (!sb || !cfg.secret) return json({ ok: false, error: 'Server not configured' }, 503);
    const cron = (process.env.CRON_SECRET ?? '').trim();
    const bearer = (request.headers.get('authorization') ?? '').replace(/^Bearer\s+/i, '');
    const authorised = safeEq(request.headers.get('x-webhook-secret') ?? '', cfg.secret) || (cron !== '' && safeEq(bearer, cron));
    if (!authorised) return json({ ok: false, error: 'Unauthorized' }, 401);

    const { data, error } = await sb.from('campaigns').select('*').eq('status', 'Scheduled').lte('scheduled_at', new Date().toISOString()).order('scheduled_at').limit(5);
    if (error) return json({ ok: false, error: error.message }, 500);
    const results = [];
    for (const c of data ?? []) results.push({ id: c.id, name: c.name, ...(await dispatchCampaign(sb, cfg, c as CampaignRow, c.approved_by ?? null)) });
    return json({ ok: true, ran: results.length, results });
  },
};
