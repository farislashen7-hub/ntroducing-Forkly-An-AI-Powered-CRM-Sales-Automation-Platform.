// GET /api/health — configuration flags only, never values
import { getConfig, json } from './_lib/env.js';

export default {
  async fetch(): Promise<Response> {
    const c = getConfig();
    let host: string | null = null;
    try { host = c.n8nBase ? new URL(c.n8nBase).host : null; } catch { /* malformed */ }
    return json({
      supabase_server: Boolean(c.supabaseUrl && c.serviceKey),
      n8n: Boolean(c.approveUrl && c.secret),
      n8n_base_host: host,
      paths: { approve: c.approvePath, bookings: c.bookingsPath, regenerate: c.regeneratePath, campaign: c.campaignPath },
      secret_set: Boolean(c.secret),
    });
  },
};
