// POST /api/n8n-callback — n8n -> CRM. Header: x-webhook-secret must equal N8N_WEBHOOK_SECRET.
// Events:
//  message.status  { message_id | provider_message_id, status: 'Delivered'|'Failed'|'Accepted by Provider', error? }
//  message.inbound { phone, content, provider_message_id? }          (customer replied on WhatsApp)
//  lead.created    { name, restaurant_name?, phone, email?, source?, notes?, consent?: true, consent_source? }   (e.g. Meta Lead Ads)
//                  `consent: true` ONLY when the customer ticked a marketing opt-in (e.g. a Lead Ads checkbox).
//  message.inbound also handles opt-out keywords (STOP / UNSUBSCRIBE / إيقاف / الغاء): consent_status -> opted_out.
//  booking.status  { booking_id, status: 'Scheduled'|'Confirmed'|'Completed'|'Cancelled'|'No-show' }
import { timingSafeEqual } from 'node:crypto';
import { getConfig, json } from './_lib/env.js';
import { admin, isUuid } from './_lib/supabase.js';
import { toIntl } from './_lib/phone.js';

const OPT_OUT_RE = /^\s*(stop|stop all|unsubscribe|cancel|opt\s?out|ايقاف|إيقاف|وقف|الغاء|إلغاء|الغاء الاشتراك|إلغاء الاشتراك|لا ارغب|لا أرغب)\s*[.!؟?]*\s*$/i;

const safeEq = (a: string, b: string) => {
  const A = Buffer.from(a), B = Buffer.from(b);
  return A.length === B.length && timingSafeEqual(A, B);
};

export default {
  async fetch(request: Request): Promise<Response> {
    if (request.method !== 'POST') return json({ ok: false, error: 'Method not allowed' }, 405);
    const cfg = getConfig();
    const sb = admin();
    if (!sb || !cfg.secret) return json({ ok: false, error: 'Server not configured' }, 503);
    if (!safeEq(request.headers.get('x-webhook-secret') ?? '', cfg.secret)) return json({ ok: false, error: 'Unauthorized' }, 401);

    let b: any;
    try { b = await request.json(); } catch { return json({ ok: false, error: 'Invalid JSON' }, 400); }
    const now = new Date().toISOString();

    switch (b.event) {
      case 'message.status': {
        const allowed = ['Delivered', 'Failed', 'Accepted by Provider'];
        if (!allowed.includes(b.status)) return json({ ok: false, error: 'bad status' }, 422);
        let q = sb.from('messages').update({ status: b.status, updated_at: now });
        if (isUuid(b.message_id)) q = q.eq('id', b.message_id);
        else if (b.provider_message_id) q = q.eq('provider_message_id', String(b.provider_message_id));
        else return json({ ok: false, error: 'message_id or provider_message_id required' }, 422);
        const { data, error } = await q.select('id,lead_id');
        if (error) return json({ ok: false, error: error.message }, 500);
        if (b.status === 'Failed' && data?.[0]) {
          await sb.from('activity_logs').insert({ lead_id: data[0].lead_id, event_type: 'Message Failed', description: `Delivery failed${b.error ? `: ${b.error}` : ''}`, metadata: { messageId: data[0].id } });
        }
        return json({ ok: true, updated: data?.length ?? 0 });
      }

      case 'message.inbound': {
        const phone = toIntl(String(b.phone ?? ''), cfg.defaultCC);
        const content = String(b.content ?? '').trim();
        if (!phone || !content) return json({ ok: false, error: 'phone and content required' }, 422);
        const { data: leads } = await sb.from('leads').select('id,phone').eq('archived', false).limit(5000);
        const lead = (leads ?? []).find(l => toIntl(l.phone, cfg.defaultCC) === phone);
        if (!lead) return json({ ok: false, error: 'No lead with that phone', phone }, 404);
        await sb.from('conversations').insert({ lead_id: lead.id, direction: 'inbound', content });
        const optOut = OPT_OUT_RE.test(content);
        await sb.from('leads').update(optOut
          ? { last_contact_at: now, updated_at: now, consent_status: 'opted_out', consent_at: now, consent_source: 'Customer reply (opt-out keyword)' }
          : { last_contact_at: now, updated_at: now }).eq('id', lead.id);
        await sb.from('activity_logs').insert(optOut
          ? { lead_id: lead.id, event_type: 'Consent Updated', description: 'Customer opted out of marketing messages (reply keyword)', metadata: { providerMessageId: b.provider_message_id ?? null } }
          : { lead_id: lead.id, event_type: 'Lead Updated', description: 'Inbound WhatsApp reply received', metadata: { providerMessageId: b.provider_message_id ?? null } });
        return json({ ok: true, lead_id: lead.id, opted_out: optOut });
      }

      case 'lead.created': {
        const phone = String(b.phone ?? '').trim();
        const name = String(b.name ?? '').trim();
        const intl = toIntl(phone, cfg.defaultCC);
        if (!name || !intl) return json({ ok: false, error: 'name and a valid phone required' }, 422);
        const { data: existing } = await sb.from('leads').select('id,phone').eq('archived', false).limit(5000);
        const dup = (existing ?? []).find(l => toIntl(l.phone, cfg.defaultCC) === intl);
        if (dup) return json({ ok: true, lead_id: dup.id, duplicate: true });
        const { data: lead, error } = await sb.from('leads').insert({
          name, restaurant_name: String(b.restaurant_name ?? name), phone: `+${intl}`,
          email: b.email ?? null, source: b.source ?? 'Meta Lead Ads', status: 'New', notes: b.notes ?? '',
          ...(b.consent === true ? { consent_status: 'opted_in', consent_at: now, consent_source: String(b.consent_source ?? b.source ?? 'Lead form opt-in').slice(0, 200) } : {}),
        }).select('id').single();
        if (error) return json({ ok: false, error: error.message }, 500);
        await sb.from('activity_logs').insert({ lead_id: lead.id, event_type: 'Lead Created', description: `Lead created via n8n (${b.source ?? 'Meta Lead Ads'})`, metadata: null });
        return json({ ok: true, lead_id: lead.id });
      }

      case 'booking.status': {
        const allowed = ['Scheduled', 'Confirmed', 'Completed', 'Cancelled', 'No-show'];
        if (!isUuid(b.booking_id) || !allowed.includes(b.status)) return json({ ok: false, error: 'booking_id and valid status required' }, 422);
        const { error } = await sb.from('bookings').update({ status: b.status, updated_at: now }).eq('id', b.booking_id);
        if (error) return json({ ok: false, error: error.message }, 500);
        return json({ ok: true });
      }

      default:
        return json({ ok: false, error: `Unknown event "${b.event}"` }, 422);
    }
  },
};
