// POST /api/regenerate  { approval_id, reviewer_id?, instructions? }
// Asks n8n (AI) for a fresh draft of a pending message. n8n must answer JSON { "content": "..." }.
// On success: old approval -> Regenerated, new message (Pending Approval) + new Pending approval.
// On failure: nothing changes (old approval is restored to Pending).
import { getConfig, json } from './_lib/env.js';
import { admin, isUuid } from './_lib/supabase.js';
import { callN8n } from './_lib/n8n.js';
import { toIntl } from './_lib/phone.js';

export default {
  async fetch(request: Request): Promise<Response> {
    if (request.method !== 'POST') return json({ ok: false, error: 'Method not allowed' }, 405);
    const cfg = getConfig();
    const sb = admin();
    if (!sb || !cfg.regenerateUrl || !cfg.secret) return json({ ok: false, error: 'Server not configured' }, 503);

    let body: { approval_id?: string; reviewer_id?: string; instructions?: string };
    try { body = await request.json(); } catch { return json({ ok: false, error: 'Invalid JSON' }, 400); }
    if (!isUuid(body.approval_id)) return json({ ok: false, error: 'approval_id required' }, 400);
    const reviewer = isUuid(body.reviewer_id) ? body.reviewer_id : null;

    // Atomic claim: only one concurrent request can flip Pending -> Regenerated.
    const { data: claimed } = await sb.from('approvals')
      .update({ status: 'Regenerated', reviewed_by: reviewer, reviewed_at: new Date().toISOString() })
      .eq('id', body.approval_id).eq('status', 'Pending').select('*');
    const approval = claimed?.[0];
    if (!approval) return json({ ok: false, error: 'Approval not found or not pending' }, 409);

    const rollback = () => sb.from('approvals')
      .update({ status: 'Pending', reviewed_by: null, reviewed_at: null }).eq('id', approval.id);

    const { data: message } = await sb.from('messages').select('*').eq('id', approval.message_id).maybeSingle();
    const { data: lead } = message
      ? await sb.from('leads').select('*').eq('id', message.lead_id).maybeSingle()
      : { data: null };
    if (!message || !lead) { await rollback(); return json({ ok: false, error: 'Message or lead not found' }, 404); }

    const result = await callN8n(cfg.regenerateUrl, {
      event: 'message.regenerate',
      approval_id: approval.id,
      message_id: message.id,
      message_type: message.message_type,
      objective: message.objective,
      previous_content: message.content,
      instructions: body.instructions ?? null,
      lead: { id: lead.id, name: lead.name, restaurant_name: lead.restaurant_name, phone: lead.phone, phone_intl: toIntl(lead.phone, cfg.defaultCC), email: lead.email, source: lead.source, status: lead.status },
      callback_url: cfg.callbackUrl || null,
      sent_at: new Date().toISOString(),
    }, 60000); // LLM call — longer timeout

    const content = String(result.data?.content ?? result.data?.text ?? result.data?.output ?? '').trim();
    if (!result.ok || !content) {
      await rollback();
      await sb.from('activity_logs').insert({ lead_id: lead.id, actor_id: reviewer, event_type: 'Message Failed', description: `Regenerate failed: ${result.error ?? 'n8n returned no content'}`, metadata: { messageId: message.id, httpStatus: result.status } });
      return json({ ok: false, error: result.error ?? 'n8n returned no content' }, 502);
    }

    const { data: newMsg, error: mErr } = await sb.from('messages').insert({
      lead_id: lead.id, content, message_type: message.message_type, direction: 'outbound',
      status: 'Pending Approval', objective: message.objective, simulated: false,
    }).select('id').single();
    if (mErr || !newMsg) { await rollback(); return json({ ok: false, error: mErr?.message ?? 'insert failed' }, 500); }

    const { data: newApproval } = await sb.from('approvals').insert({
      message_id: newMsg.id, requested_by: reviewer, status: 'Pending',
    }).select('id').single();

    await sb.from('activity_logs').insert({ lead_id: lead.id, actor_id: reviewer, event_type: 'AI Draft Generated', description: 'Draft regenerated via n8n', metadata: { messageId: newMsg.id, previousMessageId: message.id } });
    return json({ ok: true, content, message_id: newMsg.id, approval_id: newApproval?.id });
  },
};
