// POST /api/wipe-chats  { confirm: 'WIPE', user_id }
// Admin-only. Deletes all chat data (conversations + WhatsApp messages; approvals cascade),
// then tells n8n (res-wipe-all) so it can clear its own chat memory. n8n failure never undoes the DB wipe.
import { getConfig, json } from './_lib/env.js';
import { admin, isUuid } from './_lib/supabase.js';
import { callN8n } from './_lib/n8n.js';

const ALL = '00000000-0000-0000-0000-000000000000'; // PostgREST needs a filter on delete

export default {
  async fetch(request: Request): Promise<Response> {
    if (request.method !== 'POST') return json({ ok: false, error: 'Method not allowed' }, 405);
    const cfg = getConfig();
    const sb = admin();
    if (!sb) return json({ ok: false, error: 'Server not configured (Supabase service key).' }, 503);

    let body: { confirm?: string; user_id?: string };
    try { body = await request.json(); } catch { return json({ ok: false, error: 'Invalid JSON' }, 400); }
    if (body.confirm !== 'WIPE') return json({ ok: false, error: 'Confirmation required' }, 400);
    if (!isUuid(body.user_id)) return json({ ok: false, error: 'user_id required' }, 400);

    const { data: profile } = await sb.from('profiles').select('id, role').eq('id', body.user_id).maybeSingle();
    if (!profile || profile.role !== 'Admin') return json({ ok: false, error: 'Admin only' }, 403);

    const convs = await sb.from('conversations').delete({ count: 'exact' }).neq('id', ALL);
    if (convs.error) return json({ ok: false, error: `conversations: ${convs.error.message}` }, 500);
    const msgs = await sb.from('messages').delete({ count: 'exact' }).eq('message_type', 'whatsapp');
    if (msgs.error) return json({ ok: false, error: `messages: ${msgs.error.message}` }, 500);

    const deleted = { conversations: convs.count ?? 0, messages: msgs.count ?? 0 };
    await sb.from('activity_logs').insert({
      lead_id: null, actor_id: profile.id, event_type: 'Chats Wiped',
      description: `All chats wiped (${deleted.conversations} conversations, ${deleted.messages} WhatsApp messages)`,
      metadata: deleted,
    });

    let n8n: { ok: boolean; error?: string } = { ok: false, error: 'n8n not configured' };
    if (cfg.wipeUrl && cfg.secret) {
      const r = await callN8n(cfg.wipeUrl, { event: 'chats.wipe_all', actor_id: profile.id, deleted, at: new Date().toISOString() }, 15000);
      n8n = { ok: r.ok, error: r.error };
    }
    return json({ ok: true, deleted, n8n });
  },
};
