import js from '@eslint/js'
import globals from 'globals'
import reactHooks from 'eslint-plugin-react-hooks'
import reactRefresh from 'eslint-plugin-react-refresh'
import tseslint from 'typescript-eslint'
import { defineConfig, globalIgnores } from 'eslint/config'

export default defineConfig([
  globalIgnores(['dist']),
  {
    files: ['**/*.{ts,tsx}'],
    extends: [
      js.configs.recommended,
      tseslint.configs.recommended,
      reactHooks.configs.flat.recommended,
      reactRefresh.configs.vite,
    ],
    languageOptions: {
      ecmaVersion: 2020,
      globals: globals.browser,
    },
    rules: {
      // These four are React Compiler checks (eslint-plugin-react-hooks v7). The app does not use
      // React Compiler: Date.now() for relative times and syncing state from props are intentional.
      'react-hooks/purity': 'off',
      'react-hooks/set-state-in-effect': 'off',
      'react-hooks/preserve-manual-memoization': 'off',
      'react-hooks/refs': 'off',
      // Dev-only Fast Refresh hint; shared UI kits export helpers next to components on purpose.
      'react-refresh/only-export-components': 'off',
    },
  },
  {
    // Serverless handlers and the data layer parse untyped JSON (n8n, Supabase realtime rows).
    files: ['api/**/*.ts', 'src/context/AppContext.tsx'],
    rules: { '@typescript-eslint/no-explicit-any': 'off' },
  },
])
