// scripts/deploy-lib.mjs — deploy this project to Vercel using the REST API (no extra deps).
// 1st run  : creates a NEW Vercel project, saves its id in .vercel-project.json, syncs env vars, deploys.
// next runs: reuses the same project (same URL) and just ships a new production deployment.
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, existsSync, readdirSync, statSync } from 'node:fs';
import { join, relative, sep } from 'node:path';

const API = 'https://api.vercel.com';
const STATE_FILE = '.vercel-project.json';
const IGNORE_DIRS = new Set(['node_modules', 'dist', '.git', '.vercel', 'out', '.idea', '.vscode']);
const IGNORE_FILES = new Set([STATE_FILE, '.vite-source-tags.js', '.DS_Store']);
const isIgnoredFile = n => IGNORE_FILES.has(n) || n.startsWith('.env') && n !== '.env.example' || n.endsWith('.local') || n.endsWith('.log');

// env vars pushed to Vercel (only these keys, empty values skipped)
const ENV_KEYS = [
  'VITE_SUPABASE_URL', 'VITE_SUPABASE_PUBLISHABLE_KEY',
  'SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY',
  'N8N_WEBHOOK_BASE', 'N8N_WEBHOOK_SECRET', 'N8N_PATH_APPROVE', 'N8N_PATH_BOOKINGS', 'N8N_PATH_REGENERATE', 'N8N_PATH_WIPE', 'N8N_PATH_CAMPAIGN',
  'DEFAULT_GULF_CC', 'PUBLIC_APP_URL',
];

function walk(root, dir = root, out = []) {
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    const st = statSync(full);
    if (st.isDirectory()) { if (!IGNORE_DIRS.has(name)) walk(root, full, out); }
    else if (!isIgnoredFile(name)) out.push(full);
  }
  return out;
}

async function vercel(token, path, { method = 'GET', body, headers = {}, team } = {}) {
  const url = new URL(API + path);
  if (team) url.searchParams.set('teamId', team);
  // Network failures ("fetch failed") are retried; HTTP errors (401, 404...) are not.
  let res;
  for (let attempt = 1; ; attempt++) {
    try {
      res = await fetch(url, {
        method,
        signal: AbortSignal.timeout(120_000),
        headers: { authorization: `Bearer ${token}`, ...(body && !(body instanceof Buffer) ? { 'content-type': 'application/json' } : {}), ...headers },
        body: body === undefined ? undefined : body instanceof Buffer ? body : JSON.stringify(body),
      });
      break;
    } catch (e) {
      const why = e?.cause?.code || e?.cause?.message || e?.name || 'unknown';
      if (attempt >= 4) {
        const err = new Error(`Cannot reach api.vercel.com (${why}) on ${method} ${path}. This is a NETWORK problem, not your token: check internet / VPN / proxy / firewall / antivirus, or try another network (phone hotspot).`);
        err.network = true;
        throw err;
      }
      await new Promise(r => setTimeout(r, 1500 * attempt));
    }
  }
  const text = await res.text();
  let json = null; try { json = text ? JSON.parse(text) : null; } catch { /* non-json */ }
  if (!res.ok) {
    const err = new Error(json?.error?.message || `Vercel API ${res.status} on ${method} ${path}`);
    err.status = res.status; err.code = json?.error?.code;
    throw err;
  }
  return json;
}

export async function deploy({ root = process.cwd(), env = process.env, log = console.log } = {}) {
  const token = (env.VERCEL_TOKEN || '').trim();
  if (!token) throw new Error('VERCEL_TOKEN is missing. Create one at https://vercel.com/account/tokens and add VERCEL_TOKEN=... to .env.local');
  const team = (env.VERCEL_TEAM_ID || '').trim() || undefined;

  // ---- 1) project: reuse or create -------------------------------------------------
  const statePath = join(root, STATE_FILE);
  let state = existsSync(statePath) ? JSON.parse(readFileSync(statePath, 'utf8')) : null;
  let created = false;

  const base = (env.VERCEL_PROJECT_NAME || JSON.parse(readFileSync(join(root, 'package.json'), 'utf8')).name || 'forkly')
    .toLowerCase().replace(/[^a-z0-9-]/g, '-').slice(0, 90);
  const save = (proj) => {
    state = { projectId: proj.id, name: proj.name, team: team ?? null, createdAt: state?.createdAt ?? new Date().toISOString() };
    writeFileSync(statePath, JSON.stringify(state, null, 2) + '\n');
  };

  if (state?.projectId) {
    // Saved project: ALWAYS reuse it. Never silently create another one.
    try { await vercel(token, `/v9/projects/${state.projectId}`, { team }); log(`Updating existing project "${state.name}"`); }
    catch (e) {
      if (e.status === 404 || e.status === 403) {
        throw new Error(`The saved project "${state.name}" was not found with this token (deleted, or a Team token is missing VERCEL_TEAM_ID). Fix VERCEL_TEAM_ID, or delete ${STATE_FILE} if you really want a brand-new project.`);
      }
      throw e;
    }
  } else {
    // No state file (e.g. folder was re-extracted): reuse a project with our name if it already exists.
    let existing = null;
    try { existing = await vercel(token, `/v9/projects/${encodeURIComponent(base)}`, { team }); } catch (e) { if (e.status !== 404) throw e; }
    if (existing) { save(existing); log(`Found existing project "${existing.name}" — updating it`); }
    else {
      const settings = { framework: 'vite', buildCommand: 'vite build', outputDirectory: 'dist', installCommand: 'npm install' };
      const proj = await vercel(token, '/v11/projects', { method: 'POST', team, body: { name: base, ...settings } });
      save(proj);
      created = true;
      log(`Created NEW Vercel project "${proj.name}"`);
    }
  }

  // ---- 2) env vars (upsert, skip empty) ---------------------------------------------
  const vars = ENV_KEYS.filter(k => (env[k] || '').trim()).map(k => ({
    key: k, value: env[k].trim(), type: 'encrypted', target: ['production', 'preview', 'development'],
  }));
  const bad = vars.find(v => v.key.startsWith('VITE_') && /^sb_secret_|service_role/.test(v.value));
  if (bad) throw new Error(`${bad.key} contains a SECRET key. Put the sb_publishable_ key there (VITE_* is public).`);
  if (vars.length) {
    await vercel(token, `/v10/projects/${state.projectId}/env?upsert=true`, { method: 'POST', team, body: vars });
    log(`Synced ${vars.length} environment variables`);
  }
  if (!(env.VITE_SUPABASE_PUBLISHABLE_KEY || '').trim()) log('⚠ VITE_SUPABASE_PUBLISHABLE_KEY is empty — the deployed site will run on local data until you set it.');

  // ---- 3) upload files --------------------------------------------------------------
  const files = walk(root).map(full => {
    const data = readFileSync(full);
    return { full, data, file: relative(root, full).split(sep).join('/'), sha: createHash('sha1').update(data).digest('hex'), size: data.length };
  });
  log(`Uploading ${files.length} files…`);
  const queue = [...files];
  await Promise.all(Array.from({ length: 3 }, async () => {
    while (queue.length) {
      const f = queue.pop();
      await vercel(token, '/v2/files', { method: 'POST', team, body: f.data, headers: { 'x-vercel-digest': f.sha, 'content-type': 'application/octet-stream', 'content-length': String(f.size) } });
    }
  }));

  // ---- 4) create production deployment ---------------------------------------------
  const dep = await vercel(token, '/v13/deployments?forceNew=1', {
    method: 'POST', team,
    body: {
      name: state.name, project: state.projectId, target: 'production',
      files: files.map(({ file, sha, size }) => ({ file, sha, size })),
      projectSettings: { framework: 'vite', buildCommand: 'vite build', outputDirectory: 'dist', installCommand: 'npm install' },
    },
  });
  log('Building on Vercel…');

  // ---- 5) wait until ready -----------------------------------------------------------
  let d = dep;
  const t0 = Date.now();
  while (!['READY', 'ERROR', 'CANCELED'].includes(d.readyState)) {
    if (Date.now() - t0 > 8 * 60_000) throw new Error('Timed out waiting for the build. Check the Vercel dashboard.');
    await new Promise(r => setTimeout(r, 3000));
    d = await vercel(token, `/v13/deployments/${dep.id}`, { team });
  }
  if (d.readyState !== 'READY') {
    throw new Error(`Build ${d.readyState}${d.errorMessage ? `: ${d.errorMessage}` : ''} — open https://vercel.com/dashboard → ${state.name} → Deployments for the log.`);
  }
  const url = `https://${(d.alias && d.alias[0]) || `${state.name}.vercel.app`}`;
  log(`Live: ${url}`);
  return { url, deploymentUrl: `https://${d.url}`, project: state.name, created };
}
