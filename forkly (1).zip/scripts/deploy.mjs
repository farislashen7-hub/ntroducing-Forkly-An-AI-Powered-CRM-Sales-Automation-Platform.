// npm run deploy — loads .env.local then deploys (creates the project on first run, updates it afterwards)
import { readFileSync, existsSync } from 'node:fs';
import { deploy } from './deploy-lib.mjs';

for (const f of ['.env', '.env.local']) {
  if (!existsSync(f)) continue;
  for (const line of readFileSync(f, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !line.trim().startsWith('#')) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}
try {
  const r = await deploy();
  console.log(r.created ? `\n✔ New project created and deployed: ${r.url}` : `\n✔ Updated: ${r.url}`);
} catch (e) {
  console.error(`\n✖ ${e.message}`);
  process.exit(1);
}
