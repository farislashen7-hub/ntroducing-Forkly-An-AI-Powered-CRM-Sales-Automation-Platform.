// src/App.tsx
import { Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'sonner';
import { AppProvider } from './context/AppContext';
import { Layout } from './components/Layout';
import Overview from './pages/Overview';
import Leads from './pages/Leads';
import LeadProfile from './pages/LeadProfile';
import Pipeline from './pages/Pipeline';
import Offers from './pages/Offers';
import WhatsApp from './pages/WhatsApp';
import Approvals from './pages/Approvals';
import Bookings from './pages/Bookings';
import Activity from './pages/Activity';
import Settings from './pages/Settings';
import Reports from './pages/Reports';
import Templates from './pages/Templates';
import Campaigns from './pages/Campaigns';
import MyDay from './pages/MyDay';
import { ErrorBoundary } from './components/ErrorBoundary';

export default function App() {
  return (
    <AppProvider>
      <Toaster position="top-right" richColors />
      <Routes>
        <Route element={<ErrorBoundary><Layout /></ErrorBoundary>}>
          <Route path="/" element={<Overview />} />
          <Route path="/my-day" element={<MyDay />} />
          <Route path="/leads" element={<Leads />} />
          <Route path="/leads/:id" element={<LeadProfile />} />
          <Route path="/pipeline" element={<Pipeline />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/templates" element={<Templates />} />
          <Route path="/campaigns" element={<Campaigns />} />
          <Route path="/offers" element={<Offers />} />
          <Route path="/whatsapp" element={<WhatsApp />} />
          <Route path="/approvals" element={<Approvals />} />
          <Route path="/bookings" element={<Bookings />} />
          <Route path="/activity" element={<Activity />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </AppProvider>
  );
}
