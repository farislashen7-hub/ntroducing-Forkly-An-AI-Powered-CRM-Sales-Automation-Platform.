// src/components/CommandPalette.tsx — Ctrl/Cmd+K global search: pages, leads, offers, quick actions
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useNavigate } from 'react-router-dom';
import { CornerDownLeft, FileText, LayoutDashboard, Plus, Search, Tag, Users } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Avatar } from './ui/kit';
import { NAV } from './nav';

interface Item { id: string; group: 'Actions' | 'Pages' | 'Leads' | 'Offers'; label: string; hint?: string; to: string; icon: React.ReactNode; avatar?: string }

export function CommandPalette({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { data } = useApp();
  const navigate = useNavigate();
  const [q, setQ] = useState('');
  const [idx, setIdx] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { if (open) { setQ(''); setIdx(0); setTimeout(() => inputRef.current?.focus(), 30); } }, [open]);

  const items = useMemo<Item[]>(() => {
    const needle = q.trim().toLowerCase();
    const match = (...parts: (string | undefined)[]) => !needle || parts.some(p => p?.toLowerCase().includes(needle));
    const actions: Item[] = [
      { id: 'a-lead', group: 'Actions' as const, label: 'Add new lead', hint: 'Leads', to: '/leads?new=1', icon: <Plus size={14} /> },
      { id: 'a-import', group: 'Actions' as const, label: 'Import leads from CSV', hint: 'Leads', to: '/leads?import=1', icon: <FileText size={14} /> },
      { id: 'a-offer', group: 'Actions' as const, label: 'Create offer', hint: 'Offers', to: '/offers', icon: <Tag size={14} /> },
    ].filter(a => match(a.label, a.hint));
    const pages: Item[] = NAV.filter(n => match(n.label)).map(n => ({ id: `p-${n.to}`, group: 'Pages' as const, label: n.label, to: n.to, icon: <LayoutDashboard size={14} /> }));
    const leads: Item[] = needle
      ? data.leads.filter(l => !l.archived && match(l.name, l.restaurant_name, l.phone, l.email)).slice(0, 6)
          .map(l => ({ id: `l-${l.id}`, group: 'Leads' as const, label: l.name, hint: `${l.restaurant_name} · ${l.status}`, to: `/leads/${l.id}`, icon: <Users size={14} />, avatar: l.name }))
      : [];
    const offers: Item[] = needle
      ? data.offers.filter(o => match(o.title, o.description)).slice(0, 4).map(o => ({ id: `o-${o.id}`, group: 'Offers' as const, label: o.title, hint: 'Offer', to: '/offers', icon: <Tag size={14} /> }))
      : [];
    return [...actions, ...leads, ...pages, ...offers];
  }, [q, data.leads, data.offers]);

  useEffect(() => { setIdx(0); }, [q]);

  if (!open) return null;

  const go = (it?: Item) => { if (!it) return; onClose(); navigate(it.to); };
  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setIdx(i => Math.min(items.length - 1, i + 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setIdx(i => Math.max(0, i - 1)); }
    else if (e.key === 'Enter') { e.preventDefault(); go(items[idx]); }
    else if (e.key === 'Escape') onClose();
  };

  let lastGroup = '';
  return createPortal(
    <div className="fixed inset-0 z-[60] flex items-start justify-center p-4 pt-[12vh]" role="dialog" aria-label="Search">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-xl overflow-hidden rounded-2xl border border-white/10 bg-[#0d1333] shadow-2xl shadow-black/60" onKeyDown={onKey}>
        <div className="flex items-center gap-3 border-b border-white/10 px-4">
          <Search size={16} className="text-slate-500" />
          <input ref={inputRef} value={q} onChange={e => setQ(e.target.value)} placeholder="Search leads, offers, pages or actions…" className="h-12 flex-1 bg-transparent text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none" />
          <kbd className="rounded-md border border-white/10 px-1.5 py-0.5 text-[10px] text-slate-400">Esc</kbd>
        </div>
        <div className="max-h-[50vh] overflow-y-auto p-2">
          {items.length === 0 && <p className="py-8 text-center text-xs text-slate-500">No results for “{q}”.</p>}
          {items.map((it, i) => {
            const header = it.group !== lastGroup ? it.group : null;
            lastGroup = it.group;
            return (
              <React.Fragment key={it.id}>
                {header && <div className="px-3 pb-1 pt-2 text-[10px] font-medium uppercase tracking-wider text-slate-500">{header}</div>}
                <button onMouseEnter={() => setIdx(i)} onClick={() => go(it)} className={`flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left ${i === idx ? 'bg-blue-500/20' : 'hover:bg-white/[0.05]'}`}>
                  {it.avatar ? <Avatar name={it.avatar} size={26} /> : <span className="flex h-[26px] w-[26px] items-center justify-center rounded-lg bg-white/[0.06] text-blue-300">{it.icon}</span>}
                  <span className="min-w-0 flex-1"><span className="block truncate text-sm text-white">{it.label}</span>{it.hint && <span className="block truncate text-[10px] text-slate-400">{it.hint}</span>}</span>
                  {i === idx && <CornerDownLeft size={12} className="text-slate-400" />}
                </button>
              </React.Fragment>
            );
          })}
        </div>
      </div>
    </div>,
    document.body,
  );
}
