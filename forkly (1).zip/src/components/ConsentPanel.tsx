// src/components/ConsentPanel.tsx — marketing consent + interest tags for one lead. Every change is written to the activity log.
import React, { useState } from 'react';
import { ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import { useApp } from '../context/AppContext';
import { Card, CardBody, CardHeader } from './ui/Card';
import { Button } from './ui/Button';
import { Input, Select } from './ui/Input';
import { Badge } from './ui/Badge';
import { usePermissions } from '../lib/permissions';
import { CONSENT_LABEL, consentOf, interestsOf } from '../lib/segments';
import type { ConsentStatus, Lead } from '../lib/types';

const BADGE = { opted_in: 'green', opted_out: 'red', unknown: 'gray' } as const;

export function ConsentPanel({ lead }: { lead: Lead }) {
  const { updateLead, logActivity, currentUser } = useApp();
  const { can } = usePermissions();
  const canEdit = can('lead.write');
  const [status, setStatus] = useState<ConsentStatus>(consentOf(lead));
  const [source, setSource] = useState(lead.consent_source ?? '');
  const [tags, setTags] = useState(interestsOf(lead).join(', '));

  const save = () => {
    if (status === 'opted_in' && !source.trim()) { toast.error('Write where the opt-in came from (form, WhatsApp reply, signed paper…)'); return; }
    const interests = [...new Set(tags.split(/[,،\n]/).map(t => t.trim()).filter(Boolean))];
    const changed = status !== consentOf(lead);
    updateLead(lead.id, {
      interests,
      consent_status: status,
      consent_source: status === 'unknown' ? null : source.trim() || lead.consent_source || null,
      consent_at: changed ? new Date().toISOString() : lead.consent_at ?? null,
    });
    if (changed) logActivity({ lead_id: lead.id, actor_id: currentUser.id, event_type: 'Consent Updated', description: `Marketing consent: ${CONSENT_LABEL[status]}${source.trim() ? ` (${source.trim()})` : ''}`, metadata: { status, source: source.trim() } });
    toast.success('Saved');
  };

  const cur = consentOf(lead);
  return (
    <Card>
      <CardHeader>
        <h3 className="flex items-center gap-2 text-sm font-semibold"><ShieldCheck size={14} /> Marketing consent & interests</h3>
      </CardHeader>
      <CardBody className="space-y-3">
        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
          <Badge color={BADGE[cur]}>{CONSENT_LABEL[cur]}</Badge>
          {lead.consent_at && <span>since {new Date(lead.consent_at).toLocaleDateString()}</span>}
          {lead.consent_source && <span>· {lead.consent_source}</span>}
        </div>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          <Select label="Consent to marketing messages" value={status} disabled={!canEdit} onChange={e => setStatus(e.target.value as ConsentStatus)}>
            <option value="unknown">No consent on file</option>
            <option value="opted_in">Opted in</option>
            <option value="opted_out">Opted out</option>
          </Select>
          <Input label="Source of consent" placeholder="e.g. website form, WhatsApp reply, signed form" value={source} disabled={!canEdit || status === 'unknown'} onChange={e => setSource(e.target.value)} />
        </div>
        <Input label="Interested in (services, comma separated)" placeholder="e.g. dental, laser, skin care" value={tags} disabled={!canEdit} onChange={e => setTags(e.target.value)} />
        <p className="text-[11px] text-slate-500">Only record “Opted in” when the customer actually agreed to receive marketing messages. Campaigns and win-back messages skip everyone else.</p>
        {canEdit && <Button size="sm" onClick={save}>Save</Button>}
      </CardBody>
    </Card>
  );
}
