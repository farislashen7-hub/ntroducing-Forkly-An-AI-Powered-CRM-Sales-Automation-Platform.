// src/components/ErrorBoundary.tsx — a crash in one page shows a recoverable screen instead of a blank app
import React from 'react';

interface State { error: Error | null }

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  state: State = { error: null };
  static getDerivedStateFromError(error: Error): State { return { error }; }
  componentDidCatch(error: Error, info: React.ErrorInfo) { console.error('[ui]', error, info.componentStack); }
  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#060919] p-6 text-slate-100">
        <div className="w-full max-w-md rounded-2xl border border-white/10 bg-white/[0.04] p-6 text-center">
          <h1 className="text-lg font-semibold text-white">Something went wrong</h1>
          <p className="mt-2 break-words text-xs text-slate-400">{this.state.error.message}</p>
          <div className="mt-5 flex justify-center gap-2">
            <button onClick={() => this.setState({ error: null })} className="h-9 rounded-xl border border-white/10 bg-white/[0.06] px-4 text-xs text-slate-200 hover:bg-white/10">Try again</button>
            <button onClick={() => { window.location.href = '/'; }} className="h-9 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-500 px-4 text-xs font-semibold text-white">Go to Overview</button>
          </div>
        </div>
      </div>
    );
  }
}
