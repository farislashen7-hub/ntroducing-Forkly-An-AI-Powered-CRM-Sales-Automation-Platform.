// src/components/Layout.tsx — dark glass shell (Nexora style)
import React from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { Search, ChevronDown, Menu, X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { NAV as nav } from './nav';
import { CommandPalette } from './CommandPalette';
import { NotificationBell } from './Notifications';
import { overdueCount } from '../lib/workload';

export function Layout() {
  const { currentUser, setCurrentUser, data } = useApp();
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [paletteOpen, setPaletteOpen] = React.useState(false);
  React.useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setPaletteOpen(o => !o); }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, []);
  const pendingApprovals = data.approvals.filter(a => a.status === 'Pending').length;
  const myOverdue = overdueCount(data, currentUser.id);
  const pendingCampaigns = data.campaigns.filter(c => c.status === 'Pending Approval').length;
  const overdue = data.follow_up_tasks.filter(t => t.status === 'Pending' && new Date(t.due_at).getTime() < Date.now()).length;
  const initials = currentUser.full_name.split(' ').map(n => n[0]).join('');

  return (
    <div className="flex h-screen overflow-hidden bg-[#060919] text-slate-100">
      {/* Sidebar */}
      <aside className={`fixed md:static z-40 inset-y-0 left-0 w-64 bg-[#080d26]/95 backdrop-blur-xl border-r border-white/10 text-slate-300 flex flex-col transform transition-transform ${mobileOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}`}>
        <div className="h-16 flex items-center px-5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-sky-400 to-blue-600 flex items-center justify-center text-white font-bold shadow-lg shadow-blue-500/30">M</div>
            <span className="text-lg font-semibold text-white">Forkly</span>
          </div>
          <button className="md:hidden ml-auto text-slate-400" onClick={() => setMobileOpen(false)} aria-label="Close menu"><X size={18} /></button>
        </div>
        <nav className="flex-1 px-3 py-3 space-y-1 overflow-y-auto">
          {nav.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              onClick={() => setMobileOpen(false)}
              className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-colors ${isActive ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/25' : 'text-slate-400 hover:bg-white/[0.06] hover:text-white'}`}
            >
              <item.icon size={17} />
              <span className="flex-1">{item.label}</span>
              {item.to === '/approvals' && pendingApprovals > 0 && (
                <span className="text-[10px] bg-amber-500 text-white rounded-full px-1.5 py-0.5">{pendingApprovals}</span>
              )}
              {item.to === '/my-day' && myOverdue > 0 && (
                <span className="text-[10px] bg-red-500 text-white rounded-full px-1.5 py-0.5">{myOverdue}</span>
              )}
              {item.to === '/campaigns' && pendingCampaigns > 0 && (
                <span className="text-[10px] bg-amber-500 text-white rounded-full px-1.5 py-0.5">{pendingCampaigns}</span>
              )}
              {item.to === '/bookings' && overdue > 0 && (
                <span className="text-[10px] bg-red-500 text-white rounded-full px-1.5 py-0.5">{overdue}</span>
              )}
            </NavLink>
          ))}
        </nav>
        <div className="p-3 border-t border-white/10">
          <div className="flex items-center gap-2 px-2 py-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-indigo-700 flex items-center justify-center text-xs text-white">{initials}</div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-medium text-white truncate">{currentUser.full_name}</div>
              <div className="text-[10px] text-slate-400 truncate">{currentUser.role}</div>
            </div>
            <select
              className="bg-white/[0.06] text-slate-200 text-xs rounded-lg px-1 py-1 border border-white/10"
              value={currentUser.id}
              onChange={e => setCurrentUser(e.target.value)}
              aria-label="Switch user"
            >
              {data.profiles.map(p => <option key={p.id} value={p.id}>{p.full_name}</option>)}
            </select>
          </div>
        </div>
      </aside>
      {mobileOpen && <div className="fixed inset-0 z-30 bg-black/60 md:hidden" onClick={() => setMobileOpen(false)} />}

      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} />

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="relative z-40 h-16 bg-[#080d26]/80 backdrop-blur-xl border-b border-white/10 flex items-center px-4 md:px-6 gap-3">
          <button className="md:hidden text-slate-400" onClick={() => setMobileOpen(true)} aria-label="Open menu"><Menu size={20} /></button>
          <button onClick={() => setPaletteOpen(true)} className="relative flex h-10 max-w-md flex-1 items-center gap-2 rounded-full border border-white/10 bg-white/[0.05] pl-9 pr-3 text-left text-sm text-slate-500 hover:bg-white/[0.08]" aria-label="Search">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <span className="flex-1">Search leads, offers, pages…</span>
            <kbd className="hidden rounded-md border border-white/10 px-1.5 py-0.5 text-[10px] text-slate-400 sm:block">Ctrl K</kbd>
          </button>
          <div className="ml-auto flex items-center gap-3">
            <NotificationBell />
            <div className="flex items-center gap-2 pl-3 border-l border-white/10">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-indigo-700 flex items-center justify-center text-xs text-white">{initials}</div>
              <ChevronDown size={14} className="text-slate-400" />
            </div>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-[radial-gradient(ellipse_at_top_left,#1b2a7a_0%,transparent_45%),radial-gradient(ellipse_at_bottom_right,#10206b_0%,transparent_40%),linear-gradient(180deg,#0a0f2c,#060919)]">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
