// src/components/Notifications.tsx — bell dropdown: everything that needs attention, derived live from data
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, Bell, CalendarClock, CheckCircle2, Flame, Hourglass } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { buildScores, isHot } from '../lib/leadInsights';
import { loadAutomation, staleLeads } from '../lib/automation';

interface Note { id: string; icon: React.ReactNode; tone: string; title: string; sub: string; to: string }

export function useNotifications(): Note[] {
  const { data } = useApp();
  return useMemo(() => {
    const out: Note[] = [];
    const today = new Date().toISOString().slice(0, 10);
    const name = (id: string) => data.leads.find(l => l.id === id)?.name ?? 'Lead';
    for (const a of data.approvals.filter(x => x.status === 'Pending').slice(0, 5)) {
      const m = data.messages.find(x => x.id === a.message_id);
      out.push({ id: `ap-${a.id}`, icon: <CheckCircle2 size={14} />, tone: 'text-amber-300', title: 'Message awaiting approval', sub: m ? name(m.lead_id) : '', to: '/approvals' });
    }
    for (const c of data.campaigns.filter(x => x.status === 'Pending Approval').slice(0, 3)) {
      out.push({ id: `c-${c.id}`, icon: <CheckCircle2 size={14} />, tone: 'text-amber-300', title: 'Campaign awaiting approval', sub: c.name, to: '/campaigns' });
    }
    for (const t of data.follow_up_tasks.filter(x => x.status === 'Pending' && new Date(x.due_at).getTime() < Date.now()).slice(0, 5)) {
      out.push({ id: `t-${t.id}`, icon: <AlertTriangle size={14} />, tone: 'text-rose-300', title: `Overdue: ${t.title}`, sub: name(t.lead_id), to: '/bookings' });
    }
    for (const b of data.bookings.filter(x => x.booking_date === today && ['Scheduled', 'Confirmed'].includes(x.status))) {
      out.push({ id: `b-${b.id}`, icon: <CalendarClock size={14} />, tone: 'text-sky-300', title: `Demo today at ${b.booking_time}`, sub: name(b.lead_id), to: '/bookings' });
    }
    const scores = buildScores(data);
    for (const l of data.leads.filter(x => !x.archived && isHot(x, scores) && !x.next_follow_up_at).slice(0, 3)) {
      out.push({ id: `h-${l.id}`, icon: <Flame size={14} />, tone: 'text-orange-300', title: 'Hot lead has no follow-up', sub: l.name, to: `/leads/${l.id}` });
    }
    const stale = staleLeads(data, loadAutomation().staleDays);
    if (stale.length) out.push({ id: 'stale', icon: <Hourglass size={14} />, tone: 'text-slate-300', title: `${stale.length} stale lead${stale.length === 1 ? '' : 's'}`, sub: 'No contact for a while', to: '/leads' });
    return out;
  }, [data]);
}

export function NotificationBell() {
  const notes = useNotifications();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);
  return (
    <div className="relative" ref={ref}>
      <button onClick={() => setOpen(o => !o)} className="relative rounded-full border border-white/10 bg-white/[0.05] p-2 text-slate-300 hover:text-white" aria-label="Notifications">
        <Bell size={17} />
        {notes.length > 0 && <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 text-[9px] text-white">{notes.length}</span>}
      </button>
      {open && (
        <div className="absolute right-0 z-50 mt-2 w-80 max-w-[calc(100vw-2rem)] overflow-hidden rounded-2xl border border-white/10 bg-[#0d1333] shadow-2xl shadow-black/60">
          <div className="border-b border-white/10 px-4 py-3 text-sm font-semibold text-white">Needs attention <span className="text-xs font-normal text-slate-400">({notes.length})</span></div>
          <ul className="max-h-96 overflow-y-auto p-1.5">
            {notes.length === 0 && <li className="py-8 text-center text-xs text-slate-500">You are all caught up.</li>}
            {notes.map(n => (
              <li key={n.id}>
                <Link to={n.to} onClick={() => setOpen(false)} className="flex items-start gap-3 rounded-xl px-3 py-2 hover:bg-white/[0.05]">
                  <span className={`mt-0.5 ${n.tone}`}>{n.icon}</span>
                  <span className="min-w-0"><span className="block truncate text-xs font-medium text-white">{n.title}</span><span className="block truncate text-[10px] text-slate-400">{n.sub}</span></span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
