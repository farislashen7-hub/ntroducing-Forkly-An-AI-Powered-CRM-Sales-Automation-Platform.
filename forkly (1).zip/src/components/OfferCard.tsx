// src/components/OfferCard.tsx — offer card + WhatsApp preview (English / LTR)
import React from 'react';
import { ImageOff, Plus, Tag, Users } from 'lucide-react';
import type { OfferTheme } from '../lib/types';
import { cn } from '../lib/utils';

export const OFFER_THEMES: Record<OfferTheme, { label: string; dot: string; soft: string; btn: string; price: string }> = {
  green:  { label: 'Classic', dot: '#0f9d7a', soft: 'bg-emerald-500/15', btn: 'bg-blue-500',   price: 'text-teal-300' },
  amber:  { label: 'Gold',   dot: '#f59e0b', soft: 'bg-amber-500/15',   btn: 'bg-amber-500',  price: 'text-amber-300' },
  purple: { label: 'Purple', dot: '#9333ea', soft: 'bg-violet-500/15',  btn: 'bg-purple-600', price: 'text-violet-300' },
  rose:   { label: 'Rose',   dot: '#e11d48', soft: 'bg-rose-500/15',    btn: 'bg-rose-600',   price: 'text-rose-400' },
};
export const themeOf = (t: string) => OFFER_THEMES[t as OfferTheme] ?? OFFER_THEMES.purple;

export interface OfferView {
  title: string;
  description: string;
  price: string;
  original_price: string;
  valid_until: string | null;
  theme: OfferTheme;
  active?: boolean;
  image_url?: string | null;
  message?: string;
  discount_label?: string;
}

export function formatPrice(p: string): string {
  const v = (p || '').trim();
  if (!v || Number(v) === 0) return 'Free';
  return /^\d+(\.\d+)?$/.test(v) ? `${v} SAR` : v;
}

const fmtDate = (d: string) => new Date(d + 'T00:00:00').toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' });

const BOOKING_URL = (import.meta.env.VITE_BOOKING_URL as string | undefined)?.trim();

/** Message generated from the offer data (WhatsApp formatting: *bold*, ~strike~). */
export function buildAutoMessage(o: OfferView): string {
  const lines = [
    '🔥 *New Offer* 🔥',
    '',
    `*${o.title || 'Offer title'}*`,
    o.description?.trim() || '',
    '',
    `💰 Price: *${formatPrice(o.price)}*${o.original_price?.trim() ? ` ~${formatPrice(o.original_price)}~` : ''}`,
    o.valid_until ? `⏳ Valid until: ${fmtDate(o.valid_until)}` : '',
    BOOKING_URL ? `📅 Book now: ${BOOKING_URL}` : '',
    '',
    '— Forkly',
  ];
  return lines.filter((l, i) => l !== '' || (lines[i - 1] !== '' && i > 0)).join('\n').replace(/\n{3,}/g, '\n\n');
}

export function offerToText(o: OfferView): string {
  return o.message?.trim() || buildAutoMessage(o);
}

export function OfferCard({ offer, className, children }: { offer: OfferView; className?: string; children?: React.ReactNode }) {
  const t = themeOf(offer.theme);
  const expired = offer.valid_until ? new Date(offer.valid_until + 'T23:59:59').getTime() < Date.now() : false;
  return (
    <div className={cn('bg-white/[0.04] backdrop-blur-md border border-white/10 rounded-2xl shadow-[0_8px_30px_rgba(0,0,0,0.25)] overflow-hidden flex flex-col', offer.active === false && 'opacity-60', className)}>
      <div className={cn('relative h-44 flex items-center justify-center', t.soft)}>
        {offer.image_url
          ? <img src={offer.image_url} alt="" className="w-full h-full object-cover" />
          : <ImageOff size={40} className="opacity-40" style={{ color: t.dot }} />}
        <span className="absolute top-3 right-3 inline-flex items-center gap-1 bg-blue-500 text-white text-xs font-medium px-3 py-1.5 rounded-full"><Tag size={12} /> Offer</span>
        {offer.active === false && <span className="absolute top-3 left-3 bg-black/60 text-white text-[11px] px-2 py-1 rounded-full">Paused</span>}
      </div>
      <div className="p-5 flex flex-col gap-3">
        <h3 className="text-lg font-bold text-white leading-snug">{offer.title || 'Offer title'}</h3>
        {offer.description && <p className="text-sm text-slate-400 whitespace-pre-wrap">{offer.description}</p>}
        <div className="flex items-baseline gap-2">
          <span className={cn('text-2xl font-extrabold', t.price)}>{formatPrice(offer.price)}</span>
          {offer.original_price?.trim() && <span className="text-sm text-slate-500 line-through">{formatPrice(offer.original_price)}</span>}
        </div>
        {offer.valid_until && <div className={cn('text-xs', expired ? 'text-rose-400' : 'text-slate-400')}>{expired ? 'Expired on' : 'Valid until'} {fmtDate(offer.valid_until)}</div>}
        <div><span className={cn('inline-flex items-center gap-1.5 text-white text-sm font-medium px-4 py-2 rounded-xl', t.btn)}><Plus size={14} /> Book now</span></div>
        {children && <div className="pt-3 border-t border-white/10 flex flex-wrap gap-2">{children}</div>}
      </div>
    </div>
  );
}

/** WhatsApp-style renderer: *bold* and ~strike~ like the real app. */
function renderWa(text: string): React.ReactNode[] {
  return text.split(/(\*[^*\n]+\*|~[^~\n]+~)/g).map((part, i) => {
    if (/^\*[^*\n]+\*$/.test(part)) return <strong key={i}>{part.slice(1, -1)}</strong>;
    if (/^~[^~\n]+~$/.test(part)) return <s key={i}>{part.slice(1, -1)}</s>;
    return <React.Fragment key={i}>{part}</React.Fragment>;
  });
}

export function WhatsAppPreview({ text, recipients, business = 'Forkly', caption }: { text: string; recipients: number; business?: string; caption?: string }) {
  return (
    <div>
      <div className="flex items-center gap-2 text-sm text-slate-300 mb-2"><Users size={15} /> {caption ?? `Will reach ${recipients} past client${recipients === 1 ? '' : 's'}`}</div>
      <div className="rounded-2xl overflow-hidden border border-white/10 shadow-sm">
        <div className="bg-[#075e54] text-white px-4 py-3 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-emerald-100 text-[#075e54] flex items-center justify-center font-bold">{business.slice(0, 1)}</div>
          <div><div className="font-semibold leading-tight">{business}</div><div className="text-xs text-white/70">Business account</div></div>
        </div>
        <div className="bg-[#ece5dd] p-4">
          <div className="bg-white rounded-2xl rounded-tl-sm shadow-sm px-4 py-3 text-sm text-slate-900 whitespace-pre-wrap leading-7">
            {renderWa(text)}
            <div className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">Now <span className="text-sky-500">✓✓</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}
