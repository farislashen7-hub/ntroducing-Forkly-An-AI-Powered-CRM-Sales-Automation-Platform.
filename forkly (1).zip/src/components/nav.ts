// src/components/nav.ts — single source of truth for sidebar + command palette
import { LayoutDashboard, Users, Kanban, Tag, MessageCircle, CheckCircle, Calendar, Activity, Settings, BarChart3, FileText, Megaphone, ListChecks } from 'lucide-react';

export const NAV = [
  { to: '/', label: 'Overview', icon: LayoutDashboard },
  { to: '/my-day', label: 'My Tasks', icon: ListChecks },
  { to: '/leads', label: 'Leads', icon: Users },
  { to: '/pipeline', label: 'Sales Pipeline', icon: Kanban },
  { to: '/reports', label: 'Reports', icon: BarChart3 },
  { to: '/offers', label: 'Offers', icon: Tag },
  { to: '/campaigns', label: 'Campaigns', icon: Megaphone },
  { to: '/templates', label: 'Templates', icon: FileText },
  { to: '/whatsapp', label: 'WhatsApp', icon: MessageCircle },
  { to: '/approvals', label: 'Approvals', icon: CheckCircle },
  { to: '/bookings', label: 'Bookings & Follow-ups', icon: Calendar },
  { to: '/activity', label: 'Activity & Errors', icon: Activity },
  { to: '/settings', label: 'Settings', icon: Settings },
];
