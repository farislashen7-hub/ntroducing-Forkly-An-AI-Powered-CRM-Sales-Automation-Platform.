// src/components/ui/Badge.tsx — dark chips
import React from 'react';
import { cn } from '../../lib/utils';

type Color = 'gray' | 'indigo' | 'green' | 'amber' | 'red' | 'blue' | 'purple';

const colors: Record<Color, string> = {
  gray: 'bg-white/[0.06] text-slate-300 border-white/15',
  indigo: 'bg-indigo-500/15 text-indigo-300 border-indigo-400/30',
  green: 'bg-emerald-500/15 text-emerald-300 border-emerald-400/30',
  amber: 'bg-amber-500/15 text-amber-300 border-amber-400/30',
  red: 'bg-rose-500/15 text-rose-300 border-rose-400/30',
  blue: 'bg-sky-500/15 text-sky-300 border-sky-400/30',
  purple: 'bg-violet-500/15 text-violet-300 border-violet-400/30',
};

interface Props {
  color?: Color;
  children: React.ReactNode;
  className?: string;
}

export function Badge({ color = 'gray', children, className }: Props) {
  return (
    <span className={cn('inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium border', colors[color], className)}>
      {children}
    </span>
  );
}

export function statusColor(status: string): Color {
  const map: Record<string, Color> = {
    'New': 'blue',
    'Contacted': 'indigo',
    'Interested': 'purple',
    'Demo Booked': 'amber',
    'Trial': 'amber',
    'Converted': 'green',
    'Lost': 'red',
    'Pending': 'amber',
    'Completed': 'green',
    'Cancelled': 'gray',
    'Scheduled': 'blue',
    'Confirmed': 'indigo',
    'No-show': 'red',
    'Drafted': 'gray',
    'Pending Approval': 'amber',
    'Approved': 'green',
    'Sending': 'blue',
    'Accepted by Provider': 'indigo',
    'Delivered': 'green',
    'Sent': 'green',
    'Failed': 'red',
    'Rejected': 'red',
    'Regenerated': 'purple',
    'Low': 'gray',
    'Medium': 'blue',
    'High': 'amber',
    'Urgent': 'red',
  };
  return map[status] || 'gray';
}
