// src/components/ui/Card.tsx — glass panel (Nexora style)
import React from 'react';
import { cn } from '../../lib/utils';

export const GLASS = 'rounded-2xl border border-white/10 bg-white/[0.04] backdrop-blur-md shadow-[0_8px_30px_rgba(0,0,0,0.25)]';

export function Card({ className, children, ...rest }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn(GLASS, 'text-slate-100', className)} {...rest}>
      {children}
    </div>
  );
}

export function CardHeader({ className, children }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('px-4 pt-4 pb-0 [&_h3]:flex [&_h3]:items-center [&_h3]:gap-2 [&_h3]:text-sm [&_h3]:font-semibold [&_h3]:text-white [&_h3_svg]:text-blue-300', className)}>{children}</div>;
}

export function CardBody({ className, children }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('p-4', className)}>{children}</div>;
}
