// src/components/ui/Input.tsx
import React from 'react';
import { cn } from '../../lib/utils';

interface Props extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export function Input({ label, error, className, ...rest }: Props) {
  return (
    <div className="flex flex-col gap-1">
      {label && <label className="text-xs font-medium text-slate-400">{label}</label>}
      <input
        className={cn('h-9 px-3 rounded-xl border border-white/10 bg-white/[0.05] text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-400', error && 'border-rose-500', className)}
        {...rest}
      />
      {error && <span className="text-xs text-rose-400">{error}</span>}
    </div>
  );
}

export function Textarea({ label, error, className, ...rest }: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { label?: string; error?: string }) {
  return (
    <div className="flex flex-col gap-1">
      {label && <label className="text-xs font-medium text-slate-400">{label}</label>}
      <textarea
        className={cn('px-3 py-2 rounded-xl border border-white/10 bg-white/[0.05] text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-400 min-h-[80px]', error && 'border-rose-500', className)}
        {...rest}
      />
      {error && <span className="text-xs text-rose-400">{error}</span>}
    </div>
  );
}

export function Select({ label, error, className, children, ...rest }: React.SelectHTMLAttributes<HTMLSelectElement> & { label?: string; error?: string }) {
  return (
    <div className="flex flex-col gap-1">
      {label && <label className="text-xs font-medium text-slate-400">{label}</label>}
      <select
        className={cn('h-9 px-3 rounded-xl border border-white/10 bg-white/[0.05] text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-400', error && 'border-rose-500', className)}
        {...rest}
      >
        {children}
      </select>
      {error && <span className="text-xs text-rose-400">{error}</span>}
    </div>
  );
}
