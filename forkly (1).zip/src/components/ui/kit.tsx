// src/components/ui/kit.tsx — shared "Leads page" look: header, KPI tiles, panel titles, pill tabs, avatar, score bar, table classes
import React from 'react';
import { Link } from 'react-router-dom';
import { avatarGradient, initials } from '../../lib/leadInsights';
import { cn } from '../../lib/utils';
import type { LeadStatus } from '../../lib/types';

export const glass = 'rounded-2xl border border-white/10 bg-white/[0.04] backdrop-blur-md shadow-[0_8px_30px_rgba(0,0,0,0.25)]';
export const darkField = 'h-9 rounded-xl border border-white/10 bg-white/[0.05] px-3 text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/50';
export const gradientBtn = 'inline-flex h-9 items-center gap-1.5 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-500 px-4 text-xs font-semibold text-white shadow-lg shadow-blue-500/30 hover:brightness-110 disabled:opacity-50';
export const softBtn = 'inline-flex h-9 items-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.05] px-3 text-xs text-slate-200 hover:bg-white/10 disabled:opacity-40';
export const toolbar = 'mb-3 flex flex-wrap items-center gap-2 rounded-xl border border-white/10 bg-black/20 p-2';

/** Table wrapper + head/row classes, same as the Leads table. */
export const tableWrap = 'overflow-x-auto rounded-xl border border-white/10';
export const thead = 'bg-white/[0.04] text-[11px] text-slate-400';
export const th = 'whitespace-nowrap px-3 py-3 text-left font-medium';
export const tr = 'border-t border-white/10 hover:bg-white/[0.04]';
export const td = 'whitespace-nowrap px-3 py-3';

export const STATUS_CHIP: Record<LeadStatus, string> = {
  New: 'bg-sky-500/15 text-sky-300 border-sky-400/30',
  Contacted: 'bg-indigo-500/15 text-indigo-300 border-indigo-400/30',
  Interested: 'bg-violet-500/15 text-violet-300 border-violet-400/30',
  'Demo Booked': 'bg-amber-500/15 text-amber-300 border-amber-400/30',
  Trial: 'bg-orange-500/15 text-orange-300 border-orange-400/30',
  Converted: 'bg-emerald-500/15 text-emerald-300 border-emerald-400/30',
  Lost: 'bg-rose-500/15 text-rose-300 border-rose-400/30',
};

export const fmtShort = (iso: string | null | undefined) =>
  iso ? new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '—';

export function StatusChip({ status }: { status: LeadStatus }) {
  return <span className={`inline-flex rounded-full border px-2.5 py-0.5 text-[11px] font-medium ${STATUS_CHIP[status]}`}>{status}</span>;
}

export function Avatar({ name, size = 32 }: { name: string; size?: number }) {
  return (
    <span className={`inline-flex shrink-0 items-center justify-center rounded-full bg-gradient-to-br ${avatarGradient(name)} text-[11px] font-semibold text-white`} style={{ width: size, height: size }}>
      {initials(name)}
    </span>
  );
}

export function ScoreBar({ score, wide, label = 'Score' }: { score: number; wide?: boolean; label?: string }) {
  return (
    <div className={wide ? 'w-full' : 'w-28'}>
      <div className="flex items-center justify-between text-[10px] text-slate-400"><span>{label}</span><span className="font-semibold text-slate-200">{score}</span></div>
      <div className="mt-1 h-1.5 rounded-full bg-white/10"><div className="h-full rounded-full bg-gradient-to-r from-blue-500 to-violet-500" style={{ width: `${Math.max(0, Math.min(100, score))}%` }} /></div>
    </div>
  );
}

export function Kpi({ value, label, sub, accent, icon }: { value: React.ReactNode; label: string; sub?: string; accent?: string; icon?: React.ReactNode }) {
  return (
    <div className={`${glass} px-4 py-3`}>
      <div className="flex items-baseline gap-2">
        {icon && <span className="self-center text-blue-300">{icon}</span>}
        <span className="text-2xl font-semibold text-white">{value}</span>
        <span className="text-[11px] text-slate-300">{label}</span>
      </div>
      {sub && <div className={`mt-1 text-[10px] ${accent ?? 'text-slate-500'}`}>{sub}</div>}
    </div>
  );
}

export function KpiGrid({ children, cols = 6 }: { children: React.ReactNode; cols?: 3 | 4 | 5 | 6 }) {
  const map = { 3: 'md:grid-cols-3', 4: 'md:grid-cols-4', 5: 'md:grid-cols-3 xl:grid-cols-5', 6: 'md:grid-cols-3 xl:grid-cols-6' } as const;
  return <div className={cn('mb-5 grid grid-cols-2 gap-3', map[cols])}>{children}</div>;
}

export function PageHeader({ title, subtitle, children }: { title: string; subtitle?: string; children?: React.ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-semibold text-white">{title}</h1>
        {subtitle && <p className="text-xs text-slate-400">{subtitle}</p>}
      </div>
      {children && <div className="flex flex-wrap items-center gap-2">{children}</div>}
    </div>
  );
}

export function PanelTitle({ icon, title, to, linkLabel = 'View all', right }: { icon?: React.ReactNode; title: string; to?: string; linkLabel?: string; right?: React.ReactNode }) {
  return (
    <div className="mb-3 flex items-center justify-between gap-2">
      <h3 className="flex items-center gap-2 text-sm font-semibold text-white">{icon && <span className="text-blue-300">{icon}</span>}{title}</h3>
      {right}
      {to && <Link to={to} className="rounded-lg border border-white/10 px-2 py-1 text-[10px] text-slate-300 hover:bg-white/10">{linkLabel}</Link>}
    </div>
  );
}

/** Glass panel with built-in title row. */
export function Panel({ title, icon, to, linkLabel, right, className, children }: {
  title?: string; icon?: React.ReactNode; to?: string; linkLabel?: string; right?: React.ReactNode; className?: string; children: React.ReactNode;
}) {
  return (
    <div className={cn(glass, 'p-4', className)}>
      {title && <PanelTitle icon={icon} title={title} to={to} linkLabel={linkLabel} right={right} />}
      {children}
    </div>
  );
}

export function PillTabs<T extends string>({ tabs, value, onChange }: { tabs: { v: T; l: string; n?: number }[]; value: T; onChange: (v: T) => void }) {
  return (
    <div className="mb-5 flex flex-wrap gap-2">
      {tabs.map(t => (
        <button key={t.v || 'all'} onClick={() => onChange(t.v)}
          className={`rounded-full border px-4 py-2 text-xs font-medium transition-colors ${value === t.v ? 'border-blue-400/60 bg-blue-500/20 text-white' : 'border-white/10 bg-white/[0.03] text-slate-300 hover:bg-white/[0.07]'}`}>
          {t.l}{t.n !== undefined && <span className="text-slate-400"> ({t.n})</span>}
        </button>
      ))}
    </div>
  );
}

export function Empty({ children }: { children: React.ReactNode }) {
  return <p className="py-6 text-center text-xs text-slate-500">{children}</p>;
}

/** Small label/value tile used in detail grids. */
export function InfoTile({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-white/10 bg-black/20 px-3 py-2">
      <div className="text-[10px] text-slate-500">{label}</div>
      <div className="truncate text-xs font-medium text-slate-100">{value}</div>
    </div>
  );
}

export const DONUT = ['#3b82f6', '#38bdf8', '#818cf8', '#a78bfa', '#64748b'];
export const CHART_AXIS = { fontSize: 10, fill: '#94a3b8' };
export const CHART_TIP = {
  contentStyle: { background: '#0d1333', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 12, color: '#f1f5f9', fontSize: 12 },
  labelStyle: { color: '#cbd5e1' }, itemStyle: { color: '#f1f5f9' }, cursor: { fill: 'rgba(255,255,255,0.05)' },
};
