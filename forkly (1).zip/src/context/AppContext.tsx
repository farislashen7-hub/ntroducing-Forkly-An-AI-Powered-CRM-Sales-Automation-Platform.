// src/context/AppContext.tsx
import React, { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react';
import type {
  AppData, Profile, Lead, Message, Approval, Booking, FollowUpTask, ActivityLog, Conversation, Offer, Campaign,
} from '../lib/types';
import { buildSeedData } from '../lib/seed';
import { uid, nowISO } from '../lib/utils';
import { supabaseEnabled } from '../lib/supabase';
import { db, fetchAll, setDbErrorHandler } from '../lib/db';
import { supabase } from '../lib/supabase';
import { notifyBooking } from '../lib/api';
import { SEED_PROFILES } from '../lib/seed';
import { toast } from 'sonner';
import type { RealtimePostgresChangesPayload } from '@supabase/supabase-js';

const STORAGE_KEY = 'forkly_data_v3';

/** '' -> null for nullable date/uuid columns so Postgres accepts the row */
function clean<T extends object>(row: T): T {
  const out: Record<string, unknown> = { ...(row as Record<string, unknown>) };
  for (const k of Object.keys(out)) {
    if (out[k] === '' && (k.endsWith('_at') || k.endsWith('_to') || k === 'valid_until' || k === 'provider_message_id' || k === 'offer_id' || k === 'campaign_id')) out[k] = null;
  }
  return out as T;
}

function fixOffer(o: Offer): Offer {
  return { ...o, theme: ((o.theme as string) === 'indigo' ? 'purple' : o.theme), image_url: o.image_url ?? null, message: o.message ?? '', discount_label: o.discount_label ?? '' };
}

function fixCampaign(c: Campaign): Campaign {
  return { ...c, audience_lead_ids: c.audience_lead_ids ?? [], message: c.message ?? '', template_language: c.template_language ?? 'ar', include_optout: c.include_optout ?? true };
}

function normalize(raw: Record<string, unknown[]>): AppData {
  const seed = buildSeedData();
  const leads = (raw.leads as Lead[]).map(l => ({ ...l, email: l.email ?? '', notes: l.notes ?? '' }));
  const bookings = (raw.bookings as Booking[]).map(b => ({ ...b, booking_time: String(b.booking_time).slice(0, 5), notes: b.notes ?? '' }));
  const follow_up_tasks = (raw.follow_up_tasks as FollowUpTask[]).map(t => ({ ...t, description: t.description ?? '' }));
  const profiles = (raw.profiles as Profile[]).length ? (raw.profiles as Profile[]) : seed.profiles;
  return {
    profiles, leads, bookings, follow_up_tasks,
    messages: raw.messages as Message[],
    approvals: raw.approvals as Approval[],
    activity_logs: raw.activity_logs as ActivityLog[],
    conversations: raw.conversations as Conversation[],
    offers: (raw.offers as Offer[]).map(fixOffer),
    campaigns: ((raw.campaigns as Campaign[] | undefined) ?? []).map(fixCampaign),
  };
}

const LIVE_TABLES = ['profiles', 'leads', 'messages', 'approvals', 'bookings', 'follow_up_tasks', 'activity_logs', 'conversations', 'offers', 'campaigns'] as const;
type LiveTable = typeof LIVE_TABLES[number];

/** same cleanup as normalize(), but for a single realtime row */
function normRow(table: LiveTable, row: any): any {
  switch (table) {
    case 'leads': return { ...row, email: row.email ?? '', notes: row.notes ?? '' };
    case 'bookings': return { ...row, booking_time: String(row.booking_time).slice(0, 5), notes: row.notes ?? '' };
    case 'follow_up_tasks': return { ...row, description: row.description ?? '' };
    case 'offers': return fixOffer(row);
    case 'campaigns': return fixCampaign(row);
    default: return row;
  }
}

interface AppContextValue {
  data: AppData;
  currentUser: Profile;
  setCurrentUser: (id: string) => void;
  // Leads
  addLead: (lead: Omit<Lead, 'id' | 'created_at' | 'updated_at'>) => Lead;
  updateLead: (id: string, patch: Partial<Lead>) => void;
  archiveLead: (id: string) => void;
  assignLead: (id: string, profileId: string | null) => void;
  // Messages
  addMessage: (m: Omit<Message, 'id' | 'created_at' | 'updated_at'>) => Message;
  updateMessage: (id: string, patch: Partial<Message>) => void;
  // Approvals
  addApproval: (a: Omit<Approval, 'id' | 'created_at'>) => Approval;
  updateApproval: (id: string, patch: Partial<Approval>) => void;
  // Bookings
  addBooking: (b: Omit<Booking, 'id' | 'created_at' | 'updated_at'>) => Booking;
  updateBooking: (id: string, patch: Partial<Booking>) => void;
  // Tasks
  addTask: (t: Omit<FollowUpTask, 'id' | 'created_at' | 'updated_at'>) => FollowUpTask;
  updateTask: (id: string, patch: Partial<FollowUpTask>) => void;
  // Activity
  logActivity: (e: Omit<ActivityLog, 'id' | 'created_at'>) => void;
  // Conversations
  addConversation: (c: Omit<Conversation, 'id' | 'created_at'>) => void;
  wipeChatsLocal: () => void;
  // Offers
  addOffer: (o: Omit<Offer, 'id' | 'created_at' | 'updated_at'>) => Offer;
  updateOffer: (id: string, patch: Partial<Offer>) => void;
  deleteOffer: (id: string) => void;
  // Campaigns
  addCampaign: (c: Omit<Campaign, 'id' | 'created_at' | 'updated_at'>) => Campaign;
  updateCampaign: (id: string, patch: Partial<Campaign>) => void;
  deleteCampaign: (id: string) => void;
  // Helpers
  getProfile: (id: string | null) => Profile | undefined;
  getLead: (id: string) => Lead | undefined;
  // Sync
  refresh: () => Promise<void>;
  syncState: 'local' | 'loading' | 'synced' | 'error';
}

const AppContext = createContext<AppContextValue | null>(null);

function loadInitial(): AppData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as AppData;
      if (parsed && parsed.leads) return { ...buildSeedData(), ...parsed, offers: (parsed.offers || []).map(fixOffer), campaigns: (parsed.campaigns || []).map(fixCampaign) };
    }
  } catch { /* corrupt or unavailable storage: fall back to seed */ }
  return buildSeedData();
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(loadInitial);
  const [currentUserId, setCurrentUserId] = useState<string>(SEED_PROFILES[0].id);
  const [syncState, setSyncState] = useState<'local' | 'loading' | 'synced' | 'error'>(supabaseEnabled ? 'loading' : 'local');

  const refresh = useCallback(async () => {
    if (!supabaseEnabled) return;
    try {
      await db.flush();
      const raw = await fetchAll();
      if (raw) { setData(normalize(raw)); setSyncState('synced'); }
    } catch (e) {
      console.error('[sync]', e);
      setSyncState('error');
    }
  }, []);

  // initial load + seed team profiles if DB is empty + realtime
  useEffect(() => {
    if (!supabase) return;
    let lastErr = 0;
    setDbErrorHandler(msg => { if (Date.now() - lastErr > 4000) { lastErr = Date.now(); toast.error(`Supabase: ${msg}`); } });
    (async () => {
      try {
        const raw = await fetchAll();
        if (raw && (raw.profiles as Profile[]).length === 0) {
          db.upsert('profiles', SEED_PROFILES);
          await db.flush();
        }
        if (raw) setData(normalize({ ...raw, profiles: (raw.profiles as Profile[]).length ? raw.profiles : SEED_PROFILES }));
        setSyncState('synced');
      } catch (e) {
        console.error('[sync]', e);
        setSyncState('error');
        const msg = (e as Error).message;
        if (/Failed to fetch|NetworkError|Load failed/i.test(msg)) {
          let host = 'your Supabase URL';
          try { host = new URL(String(import.meta.env.VITE_SUPABASE_URL)).host; } catch { /* keep default */ }
          toast.error(`Cannot reach ${host}. Most common causes: (1) project PAUSED -> supabase.com/dashboard -> Restore project; (2) wrong/deleted project ref in VITE_SUPABASE_URL (restart \`npm run dev\` after editing .env.local); (3) internet/VPN/DNS or ad-blocker. DevTools > Network shows the exact error.`, { duration: 20000 });
        } else {
          toast.error(`Could not load from Supabase: ${msg.slice(0, 220)}`, { duration: 15000 });
        }
      }
    })();
    // Apply each INSERT/UPDATE/DELETE straight to state (instant, no refetch). Idempotent by id,
    // so our own optimistic writes echoing back never duplicate.
    const applyChange = (p: RealtimePostgresChangesPayload<any>) => {
      const table = p.table as LiveTable;
      if (!(LIVE_TABLES as readonly string[]).includes(table)) return;
      setData(prev => {
        const list = prev[table] as any[];
        if (p.eventType === 'DELETE') {
          const id = (p.old as any)?.id;
          return id ? { ...prev, [table]: list.filter(r => r.id !== id) } : prev;
        }
        const row = normRow(table, p.new);
        const i = list.findIndex(r => r.id === row.id);
        const next = i >= 0 ? list.map((r, k) => (k === i ? { ...r, ...row } : r)) : [row, ...list];
        return { ...prev, [table]: next };
      });
    };

    let poll: ReturnType<typeof setInterval> | undefined;
    const stopPoll = () => { if (poll) { clearInterval(poll); poll = undefined; } };
    const startPoll = () => { if (!poll) poll = setInterval(() => { refresh(); }, 10000); }; // safety net only while disconnected

    const ch = supabase.channel('crm-sync')
      .on('postgres_changes', { event: '*', schema: 'public' }, applyChange)
      .subscribe(status => {
        if (status === 'SUBSCRIBED') { stopPoll(); refresh(); }            // catch anything missed while offline
        else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') startPoll();
      });

    const onVisible = () => { if (document.visibilityState === 'visible') refresh(); };
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('online', onVisible);

    return () => {
      stopPoll();
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('online', onVisible);
      supabase!.removeChannel(ch);
    };
  }, [refresh]);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); } catch { /* storage full or blocked */ }
  }, [data]);

  const currentUser = data.profiles.find(p => p.id === currentUserId) || data.profiles[0];

  const getProfile = useCallback((id: string | null) => (id ? data.profiles.find(p => p.id === id) : undefined), [data.profiles]);
  const getLead = useCallback((id: string) => data.leads.find(l => l.id === id), [data.leads]);

  const logActivity = useCallback((e: Omit<ActivityLog, 'id' | 'created_at'>) => {
    const row: ActivityLog = { id: uid(), created_at: nowISO(), ...e };
    setData(prev => ({ ...prev, activity_logs: [row, ...prev.activity_logs] }));
    db.insert('activity_logs', clean(row));
  }, []);

  const addLead = useCallback((lead: Omit<Lead, 'id' | 'created_at' | 'updated_at'>) => {
    const now = nowISO();
    const newLead: Lead = { ...lead, id: uid(), created_at: now, updated_at: now };
    setData(prev => ({ ...prev, leads: [newLead, ...prev.leads] }));
    db.insert('leads', clean(newLead));
    return newLead;
  }, []);

  const updateLead = useCallback((id: string, patch: Partial<Lead>) => {
    db.update('leads', id, clean({ ...patch, updated_at: nowISO() }));
    setData(prev => ({
      ...prev,
      leads: prev.leads.map(l => l.id === id ? { ...l, ...patch, updated_at: nowISO() } : l),
    }));
  }, []);

  const archiveLead = useCallback((id: string) => {
    db.update('leads', id, { archived: true, updated_at: nowISO() });
    setData(prev => ({
      ...prev,
      leads: prev.leads.map(l => l.id === id ? { ...l, archived: true, updated_at: nowISO() } : l),
    }));
  }, []);

  const assignLead = useCallback((id: string, profileId: string | null) => {
    db.update('leads', id, { assigned_to: profileId, updated_at: nowISO() });
    setData(prev => ({
      ...prev,
      leads: prev.leads.map(l => l.id === id ? { ...l, assigned_to: profileId, updated_at: nowISO() } : l),
    }));
  }, []);

  const addMessage = useCallback((m: Omit<Message, 'id' | 'created_at' | 'updated_at'>) => {
    const now = nowISO();
    const msg: Message = { ...m, id: uid(), created_at: now, updated_at: now };
    setData(prev => ({ ...prev, messages: [msg, ...prev.messages] }));
    db.insert('messages', clean(msg));
    return msg;
  }, []);

  const updateMessage = useCallback((id: string, patch: Partial<Message>) => {
    db.update('messages', id, clean({ ...patch, updated_at: nowISO() }));
    setData(prev => ({
      ...prev,
      messages: prev.messages.map(m => m.id === id ? { ...m, ...patch, updated_at: nowISO() } : m),
    }));
  }, []);

  const addApproval = useCallback((a: Omit<Approval, 'id' | 'created_at'>) => {
    const ap: Approval = { ...a, id: uid(), created_at: nowISO() };
    setData(prev => ({ ...prev, approvals: [ap, ...prev.approvals] }));
    db.insert('approvals', clean(ap));
    return ap;
  }, []);

  const updateApproval = useCallback((id: string, patch: Partial<Approval>) => {
    db.update('approvals', id, clean(patch));
    setData(prev => ({
      ...prev,
      approvals: prev.approvals.map(a => a.id === id ? { ...a, ...patch } : a),
    }));
  }, []);

  const addBooking = useCallback((b: Omit<Booking, 'id' | 'created_at' | 'updated_at'>) => {
    const now = nowISO();
    const bk: Booking = { ...b, id: uid(), created_at: now, updated_at: now };
    setData(prev => ({ ...prev, bookings: [bk, ...prev.bookings] }));
    db.insert('bookings', clean(bk), () => notifyBooking(bk.id, 'created')); // -> n8n after the row exists
    return bk;
  }, []);

  const updateBooking = useCallback((id: string, patch: Partial<Booking>) => {
    db.update('bookings', id, clean({ ...patch, updated_at: nowISO() }), () => notifyBooking(id, patch.status === 'Cancelled' ? 'cancelled' : 'updated'));
    setData(prev => ({
      ...prev,
      bookings: prev.bookings.map(b => b.id === id ? { ...b, ...patch, updated_at: nowISO() } : b),
    }));
  }, []);

  const addTask = useCallback((t: Omit<FollowUpTask, 'id' | 'created_at' | 'updated_at'>) => {
    const now = nowISO();
    const tk: FollowUpTask = { ...t, id: uid(), created_at: now, updated_at: now };
    setData(prev => ({ ...prev, follow_up_tasks: [tk, ...prev.follow_up_tasks] }));
    db.insert('follow_up_tasks', clean(tk));
    return tk;
  }, []);

  const updateTask = useCallback((id: string, patch: Partial<FollowUpTask>) => {
    db.update('follow_up_tasks', id, clean({ ...patch, updated_at: nowISO() }));
    setData(prev => ({
      ...prev,
      follow_up_tasks: prev.follow_up_tasks.map(t => t.id === id ? { ...t, ...patch, updated_at: nowISO() } : t),
    }));
  }, []);

  const addConversation = useCallback((c: Omit<Conversation, 'id' | 'created_at'>) => {
    const conv: Conversation = { ...c, id: uid(), created_at: nowISO() };
    setData(prev => ({ ...prev, conversations: [conv, ...prev.conversations] }));
    db.insert('conversations', clean(conv));
  }, []);

  /** Clears chat data from local state only (server already deleted it when Supabase is on). */
  const wipeChatsLocal = useCallback(() => {
    setData(prev => {
      const waIds = new Set(prev.messages.filter(m => m.message_type === 'whatsapp').map(m => m.id));
      return {
        ...prev,
        conversations: [],
        messages: prev.messages.filter(m => !waIds.has(m.id)),
        approvals: prev.approvals.filter(a => !waIds.has(a.message_id)),
      };
    });
  }, []);

  const addOffer = useCallback((o: Omit<Offer, 'id' | 'created_at' | 'updated_at'>) => {
    const now = nowISO();
    const offer: Offer = { ...o, id: uid(), created_at: now, updated_at: now };
    setData(prev => ({ ...prev, offers: [offer, ...prev.offers] }));
    db.insert('offers', clean(offer));
    return offer;
  }, []);

  const updateOffer = useCallback((id: string, patch: Partial<Offer>) => {
    db.update('offers', id, clean({ ...patch, updated_at: nowISO() }));
    setData(prev => ({
      ...prev,
      offers: prev.offers.map(o => o.id === id ? { ...o, ...patch, updated_at: nowISO() } : o),
    }));
  }, []);

  const deleteOffer = useCallback((id: string) => {
    db.remove('offers', id);
    setData(prev => ({ ...prev, offers: prev.offers.filter(o => o.id !== id) }));
  }, []);

  const addCampaign = useCallback((c: Omit<Campaign, 'id' | 'created_at' | 'updated_at'>) => {
    const now = nowISO();
    const camp: Campaign = { ...c, id: uid(), created_at: now, updated_at: now };
    setData(prev => ({ ...prev, campaigns: [camp, ...prev.campaigns] }));
    db.insert('campaigns', clean(camp));
    return camp;
  }, []);

  const updateCampaign = useCallback((id: string, patch: Partial<Campaign>) => {
    db.update('campaigns', id, clean({ ...patch, updated_at: nowISO() }));
    setData(prev => ({
      ...prev,
      campaigns: prev.campaigns.map(c => c.id === id ? { ...c, ...patch, updated_at: nowISO() } : c),
    }));
  }, []);

  const deleteCampaign = useCallback((id: string) => {
    db.remove('campaigns', id);
    setData(prev => ({ ...prev, campaigns: prev.campaigns.filter(c => c.id !== id) }));
  }, []);

  const setCurrentUser = useCallback((id: string) => setCurrentUserId(id), []);

  const value: AppContextValue = {
    data, currentUser, setCurrentUser,
    addLead, updateLead, archiveLead, assignLead,
    addMessage, updateMessage,
    addApproval, updateApproval,
    addBooking, updateBooking,
    addTask, updateTask,
    logActivity, addConversation, wipeChatsLocal,
    addOffer, updateOffer, deleteOffer,
    addCampaign, updateCampaign, deleteCampaign,
    getProfile, getLead,
    refresh, syncState,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
