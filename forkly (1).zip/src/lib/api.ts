// src/lib/api.ts — calls to our own server functions (api/*), which talk to n8n.
// The browser never sees the n8n URL or the webhook secret.
export interface ApproveResult {
  ok: boolean;
  status?: string;
  provider_message_id?: string | null;
  simulated?: boolean;
  error?: string;
  not_configured?: boolean;
}

async function post<T>(path: string, body: unknown): Promise<T & { _http: number }> {
  const r = await fetch(path, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  const json = await r.json().catch(() => ({}));
  return { ...(json as T), _http: r.status };
}

export async function approveViaServer(approval_id: string, edited_content?: string, reviewer_id?: string): Promise<ApproveResult> {
  try {
    const r = await post<ApproveResult>('/api/approve', { approval_id, edited_content, reviewer_id });
    if (r._http === 503) return { ok: false, not_configured: true, error: r.error };
    return r;
  } catch (e) {
    return { ok: false, error: (e as Error).message };
  }
}

export interface RegenerateResult {
  ok: boolean;
  content?: string;
  message_id?: string;
  approval_id?: string;
  error?: string;
  not_configured?: boolean;
}
export async function regenerateViaServer(approval_id: string, reviewer_id?: string, instructions?: string): Promise<RegenerateResult> {
  try {
    const r = await post<RegenerateResult>('/api/regenerate', { approval_id, reviewer_id, instructions });
    if (r._http === 503) return { ok: false, not_configured: true, error: r.error };
    return r;
  } catch (e) {
    return { ok: false, error: (e as Error).message };
  }
}

export type BookingAction = 'created' | 'updated' | 'cancelled';
export function notifyBooking(booking_id: string, action: BookingAction) {
  // fire-and-forget; failures are logged server-side
  post('/api/bookings', { booking_id, action }).catch(() => {});
}

export interface Health {
  supabase_server: boolean;
  n8n: boolean;
  n8n_base_host: string | null;
  paths: { approve: string; bookings: string; regenerate: string; campaign?: string };
  secret_set: boolean;
}
export async function getHealth(): Promise<Health | null> {
  try { const r = await fetch('/api/health'); return r.ok ? await r.json() : null; } catch { return null; }
}

export interface WipeResult {
  ok: boolean;
  deleted?: { conversations: number; messages: number };
  n8n?: { ok: boolean; error?: string };
  error?: string;
}
export async function wipeChatsViaServer(user_id: string): Promise<WipeResult> {
  try { return await post<WipeResult>('/api/wipe-chats', { confirm: 'WIPE', user_id }); }
  catch (e) { return { ok: false, error: (e as Error).message }; }
}

export interface CampaignActionResult {
  ok: boolean;
  status?: string;
  sent?: number;
  skipped?: number;
  error?: string;
  not_configured?: boolean;
}
/** approve = send now (or schedule if the date is in the future); also used to retry a Failed campaign. cancel = stop it. */
export async function campaignActionViaServer(campaign_id: string, action: 'approve' | 'cancel', reviewer_id?: string): Promise<CampaignActionResult> {
  try {
    const r = await post<CampaignActionResult>('/api/campaign-send', { campaign_id, action, reviewer_id });
    if (r._http === 503) return { ok: false, not_configured: true, error: r.error };
    return r;
  } catch (e) {
    return { ok: false, error: (e as Error).message };
  }
}
