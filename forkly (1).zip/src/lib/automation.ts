// src/lib/automation.ts — workflow rules stored in the browser (localStorage). Applied when leads are created/imported.
import type { AppData, FollowUpTask, Lead } from './types';

export interface AutomationSettings {
  autoAssign: boolean;      // round-robin new leads to the salesperson with the fewest open leads
  autoFollowUp: boolean;    // create a follow-up task for every new lead
  followUpHours: number;    // hours after creation the task is due
  staleDays: number;        // open lead with no contact for N days = stale
}

export const DEFAULT_AUTOMATION: AutomationSettings = { autoAssign: true, autoFollowUp: true, followUpHours: 24, staleDays: 7 };
const KEY = 'forkly_automation_v1';

export function loadAutomation(): AutomationSettings {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...DEFAULT_AUTOMATION, ...(JSON.parse(raw) as Partial<AutomationSettings>) };
  } catch { /* ignore */ }
  return DEFAULT_AUTOMATION;
}

export function saveAutomation(s: AutomationSettings) {
  try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* ignore */ }
}

const CLOSED = new Set(['Converted', 'Lost']);

/** Salesperson (or manager) with the fewest open leads. Viewers and admins are skipped. */
export function pickAssignee(data: AppData, extraLoad: Record<string, number> = {}): string | null {
  const reps = data.profiles.filter(p => p.role === 'Salesperson' || p.role === 'Sales Manager');
  if (!reps.length) return null;
  const load = (id: string) => data.leads.filter(l => !l.archived && !CLOSED.has(l.status) && l.assigned_to === id).length + (extraLoad[id] ?? 0);
  return [...reps].sort((a, b) => load(a.id) - load(b.id))[0].id;
}

export function followUpTaskFor(lead: Pick<Lead, 'id' | 'name' | 'assigned_to'>, hours: number, fallbackUser: string): Omit<FollowUpTask, 'id' | 'created_at' | 'updated_at'> {
  return {
    lead_id: lead.id,
    title: `First contact: ${lead.name}`,
    description: 'Auto-created for a new lead. Reach out and qualify.',
    priority: 'High',
    due_at: new Date(Date.now() + hours * 3600000).toISOString(),
    status: 'Pending',
    assigned_to: lead.assigned_to ?? fallbackUser,
  };
}

/** Open leads with no contact (or no creation activity) for `days`. */
export function staleLeads(data: AppData, days: number): Lead[] {
  const cutoff = Date.now() - days * 86400000;
  return data.leads.filter(l => !l.archived && !CLOSED.has(l.status) && new Date(l.last_contact_at ?? l.created_at).getTime() < cutoff);
}
