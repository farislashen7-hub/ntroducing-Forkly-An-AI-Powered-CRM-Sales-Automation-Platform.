// src/lib/campaignStats.ts — campaign results derived from messages, replies and bookings (no extra tables).
//
// Attribution (shown in the UI too):
//   reply    = the lead wrote back within REPLY_WINDOW_DAYS after our message was sent
//   interested = replied AND the lead is now Interested / Demo Booked / Trial / Converted
//   booking  = a non-cancelled booking created within BOOKING_WINDOW_DAYS after the message was sent
import type { AppData, Message } from './types';
import { QUALIFIED_STATUSES } from './leadInsights';
import { DAY } from './segments';

export const REPLY_WINDOW_DAYS = 7;
export const BOOKING_WINDOW_DAYS = 14;

export interface CampaignStats {
  recipients: number;    // distinct leads we created a message for
  sent: number;          // accepted by the provider (includes delivered)
  delivered: number;
  failed: number;
  replies: number;       // distinct leads
  interested: number;    // distinct leads
  bookings: number;
  simulated: number;     // messages that were simulated (no real provider)
  deliveryRate: number;  // % of sent
  replyRate: number;     // % of sent
  bookingRate: number;   // % of sent
}

const pct = (a: number, b: number) => (b ? Math.round((a / b) * 1000) / 10 : 0);
const SENT: Message['status'][] = ['Accepted by Provider', 'Delivered'];

export function computeStats(data: AppData, messages: Message[]): CampaignStats {
  const out = messages.filter(m => m.direction === 'outbound');
  const sentMsgs = out.filter(m => SENT.includes(m.status));
  const firstSent = new Map<string, number>(); // lead -> first send time
  for (const m of sentMsgs) {
    const t = new Date(m.created_at).getTime();
    if (t < (firstSent.get(m.lead_id) ?? Infinity)) firstSent.set(m.lead_id, t);
  }

  const replied = new Set<string>();
  for (const c of data.conversations) {
    if (c.direction !== 'inbound') continue;
    const t0 = firstSent.get(c.lead_id);
    if (t0 === undefined) continue;
    const t = new Date(c.created_at).getTime();
    if (t > t0 && t - t0 <= REPLY_WINDOW_DAYS * DAY) replied.add(c.lead_id);
  }
  const interested = [...replied].filter(id => {
    const l = data.leads.find(x => x.id === id);
    return !!l && (QUALIFIED_STATUSES.includes(l.status) || l.status === 'Converted');
  }).length;

  let bookings = 0;
  for (const b of data.bookings) {
    if (b.status === 'Cancelled') continue;
    const t0 = firstSent.get(b.lead_id);
    if (t0 === undefined) continue;
    const t = new Date(b.created_at).getTime();
    if (t > t0 && t - t0 <= BOOKING_WINDOW_DAYS * DAY) bookings++;
  }

  const sent = sentMsgs.length;
  const delivered = out.filter(m => m.status === 'Delivered').length;
  return {
    recipients: new Set(out.map(m => m.lead_id)).size,
    sent, delivered,
    failed: out.filter(m => m.status === 'Failed').length,
    replies: replied.size, interested, bookings,
    simulated: out.filter(m => m.simulated).length,
    deliveryRate: pct(delivered, sent), replyRate: pct(replied.size, sent), bookingRate: pct(bookings, sent),
  };
}

export const statsForCampaign = (data: AppData, campaignId: string) => computeStats(data, data.messages.filter(m => m.campaign_id === campaignId));
export const winBackMessages = (data: AppData) => data.messages.filter(m => !m.campaign_id && /win-?back/i.test(m.objective ?? ''));
export const statsForWinBack = (data: AppData) => computeStats(data, winBackMessages(data));
export const statsForAll = (data: AppData) => computeStats(data, data.messages.filter(m => Boolean(m.campaign_id) || /win-?back/i.test(m.objective ?? '')));
