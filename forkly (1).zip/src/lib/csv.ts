// src/lib/csv.ts — tiny RFC-4180 CSV parser + lead row mapper for imports
import type { Lead, LeadSource, LeadStatus } from './types';

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [], cell = '', quoted = false;
  const src = text.replace(/^\uFEFF/, '');
  for (let i = 0; i < src.length; i++) {
    const c = src[i];
    if (quoted) {
      if (c === '"' && src[i + 1] === '"') { cell += '"'; i++; }
      else if (c === '"') quoted = false;
      else cell += c;
    } else if (c === '"') quoted = true;
    else if (c === ',' || c === ';') { row.push(cell); cell = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && src[i + 1] === '\n') i++;
      row.push(cell); cell = '';
      if (row.some(x => x.trim() !== '')) rows.push(row);
      row = [];
    } else cell += c;
  }
  row.push(cell);
  if (row.some(x => x.trim() !== '')) rows.push(row);
  return rows;
}

const SOURCES: LeadSource[] = ['Meta Lead Ads', 'WhatsApp', 'Website', 'Referral', 'Cold Outreach', 'Google Ads', 'Event', 'Partner'];
const STATUSES: LeadStatus[] = ['New', 'Contacted', 'Interested', 'Demo Booked', 'Trial', 'Converted', 'Lost'];

const ALIASES: Record<string, string[]> = {
  name: ['name', 'full name', 'lead', 'contact', 'lead name'],
  restaurant_name: ['restaurant', 'restaurant name', 'company', 'business'],
  phone: ['phone', 'mobile', 'tel', 'whatsapp', 'phone number'],
  email: ['email', 'e-mail', 'mail'],
  source: ['source', 'channel'],
  status: ['status', 'stage'],
  notes: ['notes', 'note', 'comment'],
};

export interface ImportRow { line: number; lead: Pick<Lead, 'name' | 'restaurant_name' | 'phone' | 'email' | 'source' | 'status' | 'notes'>; error?: string; duplicate?: boolean }

const pick = <T extends string>(v: string, list: T[], fallback: T): T => list.find(x => x.toLowerCase() === v.trim().toLowerCase()) ?? fallback;

export function mapLeadRows(rows: string[][], existing: Pick<Lead, 'phone' | 'email'>[]): ImportRow[] {
  if (rows.length < 2) return [];
  const head = rows[0].map(h => h.trim().toLowerCase());
  const col = (key: string) => head.findIndex(h => ALIASES[key].includes(h));
  const idx = Object.fromEntries(Object.keys(ALIASES).map(k => [k, col(k)])) as Record<string, number>;
  const phones = new Set(existing.map(l => l.phone.replace(/\D/g, '')).filter(Boolean));
  const emails = new Set(existing.map(l => l.email.toLowerCase()).filter(Boolean));
  const get = (r: string[], k: string) => (idx[k] >= 0 ? (r[idx[k]] ?? '').trim() : '');
  const out: ImportRow[] = [];
  rows.slice(1).forEach((r, i) => {
    const lead = {
      name: get(r, 'name'), restaurant_name: get(r, 'restaurant_name'), phone: get(r, 'phone'), email: get(r, 'email'),
      source: pick(get(r, 'source'), SOURCES, 'Website'), status: pick(get(r, 'status'), STATUSES, 'New'), notes: get(r, 'notes'),
    };
    const digits = lead.phone.replace(/\D/g, '');
    let error: string | undefined;
    if (!lead.name) error = 'Name missing';
    else if (!lead.restaurant_name) error = 'Restaurant missing';
    else if (!/^\+?[\d\s().-]{7,}$/.test(lead.phone)) error = 'Invalid phone';
    else if (lead.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(lead.email)) error = 'Invalid email';
    const duplicate = !error && (phones.has(digits) || (!!lead.email && emails.has(lead.email.toLowerCase())));
    if (!error && !duplicate) { phones.add(digits); if (lead.email) emails.add(lead.email.toLowerCase()); }
    out.push({ line: i + 2, lead, error, duplicate });
  });
  return out;
}

export const CSV_TEMPLATE = 'name,restaurant,phone,email,source,status,notes\nJane Doe,Blue Fork,+1 555 123 4567,jane@bluefork.com,Website,New,Met at expo\n';
