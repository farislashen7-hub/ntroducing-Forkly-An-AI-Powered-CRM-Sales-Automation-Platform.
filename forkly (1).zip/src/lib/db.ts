// src/lib/db.ts — write-through helpers. Operations run strictly in order
// (FK safety: lead -> message -> approval) and never block the UI.
import { supabase } from './supabase';

type Table =
  | 'profiles' | 'leads' | 'messages' | 'approvals' | 'bookings'
  | 'follow_up_tasks' | 'activity_logs' | 'conversations' | 'offers' | 'campaigns';

let chain: Promise<unknown> = Promise.resolve();
let onError: (msg: string) => void = () => {};
export function setDbErrorHandler(fn: (msg: string) => void) { onError = fn; }

function enqueue(label: string, fn: () => PromiseLike<{ error: { message: string } | null }>, after?: () => void) {
  if (!supabase) return;
  chain = chain.then(async () => {
    try {
      const { error } = await fn();
      if (error) { console.error(`[db] ${label}:`, error.message); onError(`${label}: ${error.message}`); return; }
      after?.();
    } catch (e) {
      console.error(`[db] ${label}:`, e);
      onError(`${label}: ${(e as Error).message}`);
    }
  });
}

export const db = {
  insert(table: Table, row: object, after?: () => void) {
    enqueue(`insert ${table}`, () => supabase!.from(table).insert(row), after);
  },
  update(table: Table, id: string, patch: object, after?: () => void) {
    enqueue(`update ${table}`, () => supabase!.from(table).update(patch).eq('id', id), after);
  },
  remove(table: Table, id: string) {
    enqueue(`delete ${table}`, () => supabase!.from(table).delete().eq('id', id));
  },
  upsert(table: Table, rows: object[]) {
    enqueue(`upsert ${table}`, () => supabase!.from(table).upsert(rows, { onConflict: 'id', ignoreDuplicates: true }));
  },
  /** run something after all queued writes are flushed */
  flush(): Promise<unknown> { return chain; },
};

// Tables added after the first release. If their migration has not been run yet the app keeps working without them.
const OPTIONAL: Table[] = ['campaigns'];
let missing: string[] = [];
/** optional tables the database does not have yet (run supabase/migrations/005_campaigns.sql) */
export const getMissingTables = () => missing;

export async function fetchAll() {
  if (!supabase) return null;
  const tables: Table[] = ['profiles', 'leads', 'messages', 'approvals', 'bookings', 'follow_up_tasks', 'activity_logs', 'conversations', 'offers', 'campaigns'];
  const res = await Promise.all(
    tables.map(t => supabase!.from(t).select('*').order('created_at', { ascending: false }).limit(5000)),
  );
  const out: Record<string, unknown[]> = {};
  const failed: string[] = [];
  const miss: string[] = [];
  for (let i = 0; i < tables.length; i++) {
    if (res[i].error) {
      if (OPTIONAL.includes(tables[i])) miss.push(tables[i]);
      else failed.push(`${tables[i]}: ${res[i].error!.message}`);
    }
    out[tables[i]] = res[i].data ?? [];
  }
  missing = miss;
  if (failed.length) throw new Error(failed.join(' | '));
  return out;
}
