// src/lib/leadInsights.ts — derived lead metrics (score, hot leads, sources, response time). No DB changes needed.
import type { AppData, Lead, LeadSource, LeadStatus } from './types';

export const QUALIFIED_STATUSES: LeadStatus[] = ['Interested', 'Demo Booked', 'Trial'];
export const HOT_THRESHOLD = 80;

const BASE: Record<LeadStatus, number> = {
  New: 30, Contacted: 45, Interested: 65, 'Demo Booked': 78, Trial: 88, Converted: 100, Lost: 5,
};
const SOURCE_BONUS: Record<LeadSource, number> = {
  Referral: 6, Partner: 4, Event: 3, Website: 2, WhatsApp: 2, 'Google Ads': 1, 'Meta Lead Ads': 0, 'Cold Outreach': -2,
};

const DAY = 86400000;

/** Score 5-99 per lead (Converted = 100, Lost = 5), built from status, source, replies, bookings and follow-up health. */
export function buildScores(data: AppData): Map<string, number> {
  const inbound = new Map<string, number>();
  for (const c of data.conversations) if (c.direction === 'inbound') inbound.set(c.lead_id, (inbound.get(c.lead_id) ?? 0) + 1);
  const booked = new Set(data.bookings.filter(b => b.status !== 'Cancelled' && b.status !== 'No-show').map(b => b.lead_id));
  const now = Date.now();
  const out = new Map<string, number>();
  for (const l of data.leads) {
    if (l.status === 'Converted') { out.set(l.id, 100); continue; }
    if (l.status === 'Lost') { out.set(l.id, 5); continue; }
    let s = BASE[l.status] + (SOURCE_BONUS[l.source] ?? 0);
    s += Math.min((inbound.get(l.id) ?? 0) * 3, 9);
    if (booked.has(l.id)) s += 5;
    if (l.last_contact_at && now - new Date(l.last_contact_at).getTime() < 7 * DAY) s += 4;
    if (l.next_follow_up_at && new Date(l.next_follow_up_at).getTime() < now) s -= 6;
    out.set(l.id, Math.max(5, Math.min(99, Math.round(s))));
  }
  return out;
}

export const isHot = (l: Lead, scores: Map<string, number>) =>
  l.status !== 'Converted' && l.status !== 'Lost' && (scores.get(l.id) ?? 0) >= HOT_THRESHOLD;

/** Average hours between a lead's first inbound message and our next outbound reply. null = no data. */
export function avgResponseHours(data: AppData, leadIds: Set<string>): number | null {
  const byLead = new Map<string, typeof data.conversations>();
  for (const c of data.conversations) {
    if (!leadIds.has(c.lead_id)) continue;
    const arr = byLead.get(c.lead_id) ?? [];
    arr.push(c);
    byLead.set(c.lead_id, arr);
  }
  const diffs: number[] = [];
  for (const arr of byLead.values()) {
    arr.sort((a, b) => a.created_at.localeCompare(b.created_at));
    const firstIn = arr.find(c => c.direction === 'inbound');
    if (!firstIn) continue;
    const reply = arr.find(c => c.direction === 'outbound' && c.created_at > firstIn.created_at);
    if (reply) diffs.push((new Date(reply.created_at).getTime() - new Date(firstIn.created_at).getTime()) / 3600000);
  }
  if (!diffs.length) return null;
  return diffs.reduce((a, b) => a + b, 0) / diffs.length;
}

export function formatHours(h: number | null): { value: string; unit: string } {
  if (h === null) return { value: '—', unit: '' };
  if (h < 1) return { value: String(Math.max(1, Math.round(h * 60))), unit: 'min' };
  return { value: h.toFixed(1), unit: 'hours' };
}

export interface ShareRow { label: string; value: number; pct: number }

/** Count by key, sorted desc, with percentage of total. */
export function shareBy<T>(items: T[], key: (i: T) => string): ShareRow[] {
  const m = new Map<string, number>();
  for (const i of items) m.set(key(i), (m.get(key(i)) ?? 0) + 1);
  const total = items.length || 1;
  return [...m.entries()].sort((a, b) => b[1] - a[1]).map(([label, value]) => ({ label, value, pct: Math.round((value / total) * 100) }));
}

export function relativeDay(iso: string): string {
  const d = new Date(iso);
  const start = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const n = Math.round((start(new Date()) - start(d)) / DAY);
  if (n <= 0) return 'Today';
  if (n === 1) return 'Yesterday';
  return `${n} days ago`;
}

export function initials(name: string): string {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map(p => p[0]?.toUpperCase()).join('') || '?';
}

const AVATAR_GRADIENTS = [
  'from-sky-500 to-blue-700', 'from-violet-500 to-indigo-700', 'from-emerald-500 to-teal-700',
  'from-amber-500 to-orange-700', 'from-rose-500 to-pink-700', 'from-cyan-500 to-blue-600',
];
export function avatarGradient(seed: string): string {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return AVATAR_GRADIENTS[h % AVATAR_GRADIENTS.length];
}
