// src/lib/permissions.ts — role-based permissions (UI-level; enforce with RLS server-side for real security)
import { useApp } from '../context/AppContext';
import type { Role } from './types';

export type Action =
  | 'lead.write' | 'lead.archive' | 'lead.import' | 'lead.bulk'
  | 'pipeline.move' | 'approval.review' | 'offer.write' | 'booking.write'
  | 'settings.admin' | 'chat.wipe' | 'campaign.write' | 'campaign.approve' | 'report.team';

const MATRIX: Record<Role, Action[]> = {
  Admin: ['lead.write', 'lead.archive', 'lead.import', 'lead.bulk', 'pipeline.move', 'approval.review', 'offer.write', 'booking.write', 'settings.admin', 'chat.wipe', 'campaign.write', 'campaign.approve', 'report.team'],
  'Sales Manager': ['lead.write', 'lead.archive', 'lead.import', 'lead.bulk', 'pipeline.move', 'approval.review', 'offer.write', 'booking.write', 'campaign.write', 'campaign.approve', 'report.team'],
  Salesperson: ['lead.write', 'pipeline.move', 'booking.write', 'campaign.write'],
  Viewer: [],
};

export const can = (role: Role, action: Action) => MATRIX[role]?.includes(action) ?? false;

/** const { can } = usePermissions(); can('lead.write') */
export function usePermissions() {
  const { currentUser } = useApp();
  return { role: currentUser.role, can: (a: Action) => can(currentUser.role, a) };
}
