// src/lib/seed.ts
import type { AppData, Profile } from './types';

// Team members only. No demo leads / messages / bookings.
export const SEED_PROFILES: Profile[] = [
  { id: '00000000-0000-4000-8000-000000000001', full_name: 'Alex Rivera', email: 'alex@forkly.com', role: 'Admin', created_at: '2026-01-01T00:00:00Z' },
  { id: '00000000-0000-4000-8000-000000000002', full_name: 'Jordan Lee', email: 'jordan@forkly.com', role: 'Sales Manager', created_at: '2026-01-02T00:00:00Z' },
  { id: '00000000-0000-4000-8000-000000000003', full_name: 'Sam Chen', email: 'sam@forkly.com', role: 'Salesperson', created_at: '2026-01-03T00:00:00Z' },
  { id: '00000000-0000-4000-8000-000000000004', full_name: 'Taylor Brooks', email: 'taylor@forkly.com', role: 'Salesperson', created_at: '2026-01-04T00:00:00Z' },
];

export function buildSeedData(): AppData {
  return {
    profiles: SEED_PROFILES,
    leads: [],
    messages: [],
    approvals: [],
    bookings: [],
    follow_up_tasks: [],
    activity_logs: [],
    conversations: [],
    offers: [],
    campaigns: [],
  };
}
