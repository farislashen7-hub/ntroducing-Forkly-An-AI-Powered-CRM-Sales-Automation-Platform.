// src/lib/segments.ts — customer segments, marketing eligibility (consent + WhatsApp rules) and win-back detection.
// Pure functions over AppData. No DB access, so the same rules can be shown live in the UI.
// The server (api/_lib/campaign.ts) re-checks consent / window / frequency at send time. Never trust the UI alone.
import type { AppData, CampaignChannel, ConsentStatus, Lead, LeadStatus, Message, SegmentKey } from './types';
import { renderTemplate } from './templates';

export const DAY = 86400000;
export const HOUR = 3600000;
export const WINDOW_HOURS = 24;          // WhatsApp customer-service window: free-form only if the customer wrote in the last 24h
export const FREQUENCY_CAP_DAYS = 7;     // max one marketing message per contact per N days
export const BUSINESS_NAME = 'Forkly';

export const consentOf = (l: Lead): ConsentStatus => l.consent_status ?? 'unknown';
export const interestsOf = (l: Lead): string[] => l.interests ?? [];

export const CONSENT_LABEL: Record<ConsentStatus, string> = { opted_in: 'Opted in', opted_out: 'Opted out', unknown: 'No consent on file' };

export const isArabic = (s: string) => /[\u0600-\u06FF]/.test(s);

// ---------------------------------------------------------------- segments

export interface SegmentDef { key: SegmentKey; label: string; description: string; param?: 'days' | 'interest' }

export const SEGMENTS: SegmentDef[] = [
  { key: 'interested_not_booked', label: 'Interested, not booked', description: 'Stage is Interested and there is no active booking.' },
  { key: 'demo_not_bought', label: 'Booked a demo, did not buy', description: 'Has a demo booking (not cancelled) and is not Converted.' },
  { key: 'past_clients', label: 'Past clients', description: 'Converted customers.' },
  { key: 'unresponsive', label: 'No reply for a while', description: 'We contacted them, but they have not written back for N days.', param: 'days' },
  { key: 'interested_service', label: 'Interested in a service', description: 'Leads tagged with a specific service / interest.', param: 'interest' },
];
export const DEFAULT_UNRESPONSIVE_DAYS = 14;
export const segmentLabel = (k: SegmentKey) => SEGMENTS.find(s => s.key === k)?.label ?? k;

export interface Ctx {
  now: number;
  lastInbound: Map<string, number>;      // lead -> ms of last inbound reply
  activeBooking: Set<string>;            // leads with a non-cancelled booking
  lastBookingAt: Map<string, number>;    // lead -> latest booking date (ms)
  lastMarketing: Map<string, number>;    // lead -> ms of last marketing message (campaign or win-back) that is live or sent
}

const LIVE_MARKETING: Message['status'][] = ['Pending Approval', 'Approved', 'Sending', 'Accepted by Provider', 'Delivered'];
export const isMarketingMessage = (m: Pick<Message, 'campaign_id' | 'objective'>) => Boolean(m.campaign_id) || /win-?back|campaign/i.test(m.objective ?? '');

export function buildCtx(data: AppData, now = Date.now()): Ctx {
  const lastInbound = new Map<string, number>();
  for (const c of data.conversations) {
    if (c.direction !== 'inbound') continue;
    const t = new Date(c.created_at).getTime();
    if (t > (lastInbound.get(c.lead_id) ?? 0)) lastInbound.set(c.lead_id, t);
  }
  const activeBooking = new Set<string>();
  const lastBookingAt = new Map<string, number>();
  for (const b of data.bookings) {
    if (b.status === 'Cancelled') continue;
    activeBooking.add(b.lead_id);
    const t = new Date(`${b.booking_date}T${b.booking_time || '00:00'}`).getTime();
    if (!Number.isNaN(t) && t > (lastBookingAt.get(b.lead_id) ?? 0)) lastBookingAt.set(b.lead_id, t);
  }
  const lastMarketing = new Map<string, number>();
  for (const m of data.messages) {
    if (m.direction !== 'outbound' || !isMarketingMessage(m) || !LIVE_MARKETING.includes(m.status)) continue;
    const t = new Date(m.created_at).getTime();
    if (t > (lastMarketing.get(m.lead_id) ?? 0)) lastMarketing.set(m.lead_id, t);
  }
  return { now, lastInbound, activeBooking, lastBookingAt, lastMarketing };
}

const CLOSED: LeadStatus[] = ['Converted', 'Lost'];

export function inSegment(l: Lead, key: SegmentKey, param: string | null, ctx: Ctx): boolean {
  if (l.archived) return false;
  switch (key) {
    case 'interested_not_booked':
      return l.status === 'Interested' && !ctx.activeBooking.has(l.id);
    case 'demo_not_bought':
      return ctx.activeBooking.has(l.id) && l.status !== 'Converted';
    case 'past_clients':
      return l.status === 'Converted';
    case 'unresponsive': {
      if (CLOSED.includes(l.status) || !l.last_contact_at) return false;
      const days = Math.max(1, Number(param) || DEFAULT_UNRESPONSIVE_DAYS);
      const heard = Math.max(ctx.lastInbound.get(l.id) ?? 0, new Date(l.created_at).getTime());
      return ctx.now - heard >= days * DAY;
    }
    case 'interested_service': {
      const want = (param ?? '').trim().toLowerCase();
      return !!want && interestsOf(l).some(t => t.trim().toLowerCase() === want);
    }
  }
}

export function segmentLeads(data: AppData, key: SegmentKey, param: string | null, ctx = buildCtx(data)): Lead[] {
  return data.leads.filter(l => inSegment(l, key, param, ctx));
}

/** every distinct interest tag across leads, most used first */
export function allInterests(data: AppData): string[] {
  const m = new Map<string, number>();
  for (const l of data.leads) if (!l.archived) for (const t of interestsOf(l)) { const k = t.trim(); if (k) m.set(k, (m.get(k) ?? 0) + 1); }
  return [...m.entries()].sort((a, b) => b[1] - a[1]).map(([t]) => t);
}

// ---------------------------------------------------------------- eligibility (consent + policy)

export type BlockReason = 'no_consent' | 'opted_out' | 'no_contact' | 'needs_template' | 'frequency_cap';
export const BLOCK_LABEL: Record<BlockReason, string> = {
  no_consent: 'No marketing consent on file',
  opted_out: 'Opted out',
  no_contact: 'No phone / email for this channel',
  needs_template: 'Outside the 24h window: needs an approved WhatsApp template',
  frequency_cap: `Already messaged in the last ${FREQUENCY_CAP_DAYS} days`,
};

export interface EligibilityOpts { channel: CampaignChannel; hasTemplate: boolean; ignoreFrequency?: boolean }

const hasContact = (l: Lead, ch: CampaignChannel) => (ch === 'email' ? /\S+@\S+\.\S+/.test(l.email ?? '') : (l.phone ?? '').replace(/\D/g, '').length >= 7);
export const inServiceWindow = (leadId: string, ctx: Ctx) => ctx.now - (ctx.lastInbound.get(leadId) ?? 0) < WINDOW_HOURS * HOUR;

/** null = OK to send a marketing message. Order matters: the first failing rule is the reported reason. */
export function blockReason(l: Lead, o: EligibilityOpts, ctx: Ctx): BlockReason | null {
  const c = consentOf(l);
  if (c === 'opted_out') return 'opted_out';
  if (c !== 'opted_in') return 'no_consent';
  if (!hasContact(l, o.channel)) return 'no_contact';
  if (o.channel === 'whatsapp' && !o.hasTemplate && !inServiceWindow(l.id, ctx)) return 'needs_template';
  if (!o.ignoreFrequency && ctx.now - (ctx.lastMarketing.get(l.id) ?? 0) < FREQUENCY_CAP_DAYS * DAY) return 'frequency_cap';
  return null;
}

export interface AudienceStats { members: Lead[]; eligible: Lead[]; blocked: { lead: Lead; reason: BlockReason }[]; byReason: Record<BlockReason, number> }

export function audienceStats(members: Lead[], o: EligibilityOpts, ctx: Ctx): AudienceStats {
  const eligible: Lead[] = [];
  const blocked: { lead: Lead; reason: BlockReason }[] = [];
  const byReason: Record<BlockReason, number> = { no_consent: 0, opted_out: 0, no_contact: 0, needs_template: 0, frequency_cap: 0 };
  for (const l of members) {
    const r = blockReason(l, o, ctx);
    if (r) { blocked.push({ lead: l, reason: r }); byReason[r]++; } else eligible.push(l);
  }
  return { members, eligible, blocked, byReason };
}

/** Guard for single messages (e.g. win-back approvals). Returns a human sentence, or null when the send is allowed. */
export function marketingBlock(data: AppData, msg: Message, lead: Lead | undefined, ctx = buildCtx(data)): string | null {
  if (!isMarketingMessage(msg) || !lead) return null;
  const c = consentOf(lead);
  if (c === 'opted_out') return `${lead.name} opted out of marketing messages.`;
  if (c !== 'opted_in') return `${lead.name} has no marketing consent on file. Record consent first.`;
  if (msg.message_type === 'whatsapp' && !msg.template_name && !inServiceWindow(lead.id, ctx))
    return `${lead.name} has not written in the last ${WINDOW_HOURS}h. WhatsApp requires an approved template for this message.`;
  return null;
}

// ---------------------------------------------------------------- opt-out

const OPT_OUT_RE = /^\s*(stop|stop all|unsubscribe|cancel|opt\s?out|ايقاف|إيقاف|وقف|الغاء|إلغاء|الغاء الاشتراك|إلغاء الاشتراك|لا ارغب|لا أرغب)\s*[.!؟?]*\s*$/i;
export const isOptOutText = (t: string) => OPT_OUT_RE.test(t);
export const optOutFooter = (body: string) => (isArabic(body) ? 'لإيقاف الرسائل الترويجية أرسل "إيقاف".' : 'Reply STOP to unsubscribe.');
export const withOptOut = (body: string, on: boolean) => (on ? `${body.trimEnd()}\n\n${optOutFooter(body)}` : body);

/** Text a recipient would receive for a campaign body. */
export function renderCampaignText(body: string, lead: Pick<Lead, 'name' | 'restaurant_name' | 'phone'> | null, owner: string, optOut: boolean): string {
  return withOptOut(renderTemplate(body, lead, owner), optOut);
}

// ---------------------------------------------------------------- win-back

export interface WinBackCandidate { lead: Lead; idleDays: number; lastTouch: number; reason: string; block: BlockReason | null }
export const WINBACK_STATUSES: LeadStatus[] = ['Interested', 'Demo Booked', 'Trial'];

/** Leads that showed interest, then went quiet for `idleDays`. `block` says why a message may not be prepared. */
export function winBackCandidates(data: AppData, idleDays: number, o: EligibilityOpts, ctx = buildCtx(data)): WinBackCandidate[] {
  const out: WinBackCandidate[] = [];
  for (const l of data.leads) {
    if (l.archived || !WINBACK_STATUSES.includes(l.status)) continue;
    const touch = Math.max(
      l.last_contact_at ? new Date(l.last_contact_at).getTime() : 0,
      ctx.lastInbound.get(l.id) ?? 0,
      ctx.lastBookingAt.get(l.id) ?? 0,
      new Date(l.created_at).getTime(),
    );
    const idle = Math.floor((ctx.now - touch) / DAY);
    if (idle < idleDays) continue;
    out.push({ lead: l, idleDays: idle, lastTouch: touch, reason: `${l.status}, no activity for ${idle} days`, block: blockReason(l, o, ctx) });
  }
  return out.sort((a, b) => b.idleDays - a.idleDays);
}

export type WinBackLang = 'ar' | 'en';

/** Personalised win-back text. Short, no pressure, one clear next step. Staff review and can edit before anything is sent. */
export function buildWinBackMessage(lead: Lead, idleDays: number, lang: WinBackLang, owner: string, extra = ''): string {
  const first = lead.name.split(/\s+/)[0] || lead.name;
  const rest = lead.restaurant_name;
  const weeks = Math.max(1, Math.round(idleDays / 7));
  const ar: Record<string, string> = {
    Interested: `أهلاً ${first}، معك ${owner} من ${BUSINESS_NAME}. قبل فترة كنت مهتماً بخدماتنا لـ ${rest} ولم نكمل الحديث. هل ما زال الموضوع يهمك؟ يسعدني أن أجيب على أي سؤال.`,
    'Demo Booked': `أهلاً ${first}، معك ${owner} من ${BUSINESS_NAME}. بعد العرض التجريبي الذي رتبناه لـ ${rest}، حبيت أطمئن إن كان لديك أي سؤال أو ملاحظة. هل نحدد خطوة تالية مناسبة لك؟`,
    Trial: `أهلاً ${first}، معك ${owner} من ${BUSINESS_NAME}. لاحظت أن تجربة ${rest} توقفت منذ فترة. هل واجهتك أي صعوبة؟ أستطيع مساعدتك لتكمل بسهولة.`,
  };
  const en: Record<string, string> = {
    Interested: `Hi ${first}, this is ${owner} from ${BUSINESS_NAME}. About ${weeks} week${weeks === 1 ? '' : 's'} ago you were interested in what we can do for ${rest}, and we never finished the conversation. Is this still on your mind? Happy to answer any questions.`,
    'Demo Booked': `Hi ${first}, this is ${owner} from ${BUSINESS_NAME}. Following up on the demo we arranged for ${rest}. Do you have any questions or feedback? Happy to suggest a next step that suits you.`,
    Trial: `Hi ${first}, this is ${owner} from ${BUSINESS_NAME}. I noticed the trial for ${rest} has been quiet for a while. Did anything get in the way? I can help you pick it back up.`,
  };
  const base = (lang === 'ar' ? ar : en)[lead.status] ?? (lang === 'ar' ? ar : en).Interested;
  return [base, extra.trim()].filter(Boolean).join('\n\n');
}
