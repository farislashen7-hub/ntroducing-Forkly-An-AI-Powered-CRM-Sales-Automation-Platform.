// src/lib/supabase.ts — browser Supabase client (publishable/anon key ONLY)
import { createClient, type SupabaseClient } from '@supabase/supabase-js';

const url = (import.meta.env.VITE_SUPABASE_URL as string | undefined)?.trim();
const key = (
  (import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined) ||
  (import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined)
)?.trim();

function isSecretKey(k: string): boolean {
  if (k.startsWith('sb_secret_')) return true;
  // legacy service_role JWT
  try {
    const payload = JSON.parse(atob(k.split('.')[1] || ''));
    return payload?.role === 'service_role';
  } catch {
    return false;
  }
}

export type SupabaseStatus =
  | { ok: true }
  | { ok: false; reason: 'missing' | 'bad_url' | 'secret_key_in_browser' };

function evaluate(): SupabaseStatus {
  if (!url || !key) return { ok: false, reason: 'missing' };
  if (!/^https:\/\/[a-z0-9]+\.supabase\.co\/?$/i.test(url)) return { ok: false, reason: 'bad_url' };
  if (isSecretKey(key)) return { ok: false, reason: 'secret_key_in_browser' };
  return { ok: true };
}

export const supabaseStatus = evaluate();

if (!supabaseStatus.ok && supabaseStatus.reason !== 'missing') {
  console.error(
    supabaseStatus.reason === 'secret_key_in_browser'
      ? '[supabase] A SECRET / service_role key was found in VITE_* env. Refusing to use it in the browser. Use the sb_publishable_... key instead.'
      : '[supabase] VITE_SUPABASE_URL is malformed. Expected https://<project-ref>.supabase.co',
  );
}

export const supabase: SupabaseClient | null = supabaseStatus.ok
  ? createClient(url!, key!, { auth: { persistSession: false } })
  : null;

export const supabaseEnabled = supabase !== null;
