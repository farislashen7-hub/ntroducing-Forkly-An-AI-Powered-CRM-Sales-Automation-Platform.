// src/lib/templates.ts — reusable WhatsApp/email message templates with {{variables}} (browser storage)
import type { Lead } from './types';

export interface Template { id: string; name: string; category: string; body: string }
const KEY = 'forkly_templates_v1';

export const TEMPLATE_VARS = ['name', 'first_name', 'restaurant', 'phone', 'owner'] as const;

export const DEFAULT_TEMPLATES: Template[] = [
  { id: 't-intro', name: 'First contact', category: 'Outreach', body: 'Hi {{first_name}}, this is {{owner}} from Forkly. I saw {{restaurant}} and would love to show you how we can streamline your ordering. Do you have 15 minutes this week?' },
  { id: 't-follow', name: 'Gentle follow-up', category: 'Follow-up', body: 'Hi {{first_name}}, just following up on my last message about {{restaurant}}. Happy to answer any questions — is now a good time?' },
  { id: 't-demo', name: 'Demo reminder', category: 'Booking', body: 'Hi {{first_name}}, a quick reminder about our demo for {{restaurant}}. Reply here if you need to reschedule.' },
  { id: 't-thanks', name: 'Thank you', category: 'Closing', body: 'Thank you {{first_name}}! Great speaking with you. I will send over the next steps for {{restaurant}} shortly.' },
];

export function loadTemplates(): Template[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) { const t = JSON.parse(raw) as Template[]; if (Array.isArray(t)) return t; }
  } catch { /* ignore */ }
  return DEFAULT_TEMPLATES;
}
export function saveTemplates(t: Template[]) { try { localStorage.setItem(KEY, JSON.stringify(t)); } catch { /* ignore */ } }

export function renderTemplate(body: string, lead: Pick<Lead, 'name' | 'restaurant_name' | 'phone'> | null, owner: string): string {
  const v: Record<string, string> = {
    name: lead?.name ?? 'there', first_name: lead?.name.split(/\s+/)[0] ?? 'there',
    restaurant: lead?.restaurant_name ?? 'your restaurant', phone: lead?.phone ?? '', owner,
  };
  return body.replace(/\{\{\s*(\w+)\s*\}\}/g, (_, k: string) => v[k] ?? `{{${k}}}`);
}
