// src/lib/types.ts

export type Role = 'Admin' | 'Sales Manager' | 'Salesperson' | 'Viewer';

export interface Profile {
  id: string;
  full_name: string;
  email: string;
  role: Role;
  created_at: string;
}

export type LeadSource =
  | 'Meta Lead Ads'
  | 'WhatsApp'
  | 'Website'
  | 'Referral'
  | 'Cold Outreach'
  | 'Google Ads'
  | 'Event'
  | 'Partner';

export type LeadStatus =
  | 'New'
  | 'Contacted'
  | 'Interested'
  | 'Demo Booked'
  | 'Trial'
  | 'Converted'
  | 'Lost';

export type ConsentStatus = 'opted_in' | 'opted_out' | 'unknown';

export interface Lead {
  id: string;
  name: string;
  restaurant_name: string;
  phone: string;
  email: string;
  source: LeadSource;
  status: LeadStatus;
  assigned_to: string | null; // profile id
  notes: string;
  last_contact_at: string | null;
  next_follow_up_at: string | null;
  created_at: string;
  updated_at: string;
  archived: boolean;
  // marketing consent + interests (migration 005). Optional so older rows/forms keep working.
  consent_status?: ConsentStatus;
  consent_at?: string | null;
  consent_source?: string | null;
  interests?: string[];
}

export type MessageType = 'whatsapp' | 'email' | 'sms';
export type MessageDirection = 'outbound' | 'inbound';
export type MessageStatus =
  | 'Drafted'
  | 'Pending Approval'
  | 'Approved'
  | 'Sending'
  | 'Accepted by Provider'
  | 'Delivered'
  | 'Failed';

export interface Message {
  id: string;
  lead_id: string;
  content: string;
  message_type: MessageType;
  direction: MessageDirection;
  status: MessageStatus;
  provider_message_id: string | null;
  objective: string | null;
  created_at: string;
  updated_at: string;
  simulated: boolean;
  // marketing (migration 005)
  campaign_id?: string | null;
  template_name?: string | null;      // approved WhatsApp template used for this send
  template_language?: string | null;
}

export type ApprovalStatus = 'Pending' | 'Approved' | 'Rejected' | 'Regenerated';

export interface Approval {
  id: string;
  message_id: string;
  requested_by: string | null;
  reviewed_by: string | null;
  status: ApprovalStatus;
  approved_content: string | null;
  reviewed_at: string | null;
  created_at: string;
}

export type BookingStatus = 'Scheduled' | 'Confirmed' | 'Completed' | 'Cancelled' | 'No-show';

export interface Booking {
  id: string;
  lead_id: string;
  booking_date: string; // YYYY-MM-DD
  booking_time: string; // HH:mm
  timezone: string;
  status: BookingStatus;
  assigned_to: string | null;
  notes: string;
  created_at: string;
  updated_at: string;
}

export type TaskPriority = 'Low' | 'Medium' | 'High' | 'Urgent';
export type TaskStatus = 'Pending' | 'Completed' | 'Cancelled';

export interface FollowUpTask {
  id: string;
  lead_id: string;
  title: string;
  description: string;
  priority: TaskPriority;
  due_at: string; // ISO
  status: TaskStatus;
  assigned_to: string | null;
  created_at: string;
  updated_at: string;
}

export type ActivityEventType =
  | 'Lead Created'
  | 'Lead Updated'
  | 'Status Changed'
  | 'Pipeline Stage Changed'
  | 'AI Draft Generated'
  | 'Draft Edited'
  | 'Message Approved'
  | 'Message Rejected'
  | 'Message Sent'
  | 'Message Failed'
  | 'Chats Wiped'
  | 'Booking Created'
  | 'Booking Rescheduled'
  | 'Booking Cancelled'
  | 'Follow-up Created'
  | 'Follow-up Completed'
  | 'Note Added'
  | 'Assignment Changed'
  | 'Consent Updated'
  | 'Campaign Created'
  | 'Campaign Approved'
  | 'Campaign Sent'
  | 'Campaign Cancelled'
  | 'Win-back Drafted';

export interface ActivityLog {
  id: string;
  lead_id: string | null;
  actor_id: string | null;
  event_type: ActivityEventType;
  description: string;
  metadata: Record<string, unknown> | null;
  created_at: string;
}

export interface Conversation {
  id: string;
  lead_id: string;
  direction: 'inbound' | 'outbound';
  content: string;
  created_at: string;
}

export type OfferTheme = 'green' | 'amber' | 'purple' | 'rose';

export interface Offer {
  id: string;
  title: string;
  description: string;
  discount_label: string; // e.g. "20% OFF"
  price: string; // e.g. "$49 / month"
  original_price: string; // e.g. "$79 / month"
  valid_until: string | null; // YYYY-MM-DD
  theme: OfferTheme;
  active: boolean;
  image_url: string | null;
  message: string; // custom WhatsApp text; empty = auto-generated from the offer
  created_at: string;
  updated_at: string;
}

export type CampaignChannel = 'whatsapp' | 'sms' | 'email';
export type CampaignStatus = 'Draft' | 'Pending Approval' | 'Scheduled' | 'Sending' | 'Sent' | 'Failed' | 'Cancelled';
export type SegmentKey = 'interested_not_booked' | 'demo_not_bought' | 'past_clients' | 'unresponsive' | 'interested_service';
export type CampaignOfferType = 'discount' | 'free_trial' | 'package' | 'reminder' | 'announcement';

export interface Campaign {
  id: string;
  name: string;
  segment_key: SegmentKey;
  segment_param: string | null;      // days (unresponsive) or interest tag (interested_service)
  offer_type: CampaignOfferType;
  offer_id: string | null;
  message: string;                   // may contain {{variables}}; rendered per recipient at send time
  channel: CampaignChannel;
  template_name: string | null;      // approved WhatsApp template (required outside the 24h window)
  template_language: string;
  attachment_url: string | null;
  attachment_name: string | null;
  attachment_type: 'image' | 'file' | null;
  include_optout: boolean;
  scheduled_at: string | null;       // null = send as soon as approved
  status: CampaignStatus;
  audience_lead_ids: string[];       // frozen when submitted for approval
  last_error: string | null;
  created_by: string | null;
  approved_by: string | null;
  sent_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface AppData {
  profiles: Profile[];
  leads: Lead[];
  messages: Message[];
  approvals: Approval[];
  bookings: Booking[];
  follow_up_tasks: FollowUpTask[];
  activity_logs: ActivityLog[];
  conversations: Conversation[];
  offers: Offer[];
  campaigns: Campaign[];
}
