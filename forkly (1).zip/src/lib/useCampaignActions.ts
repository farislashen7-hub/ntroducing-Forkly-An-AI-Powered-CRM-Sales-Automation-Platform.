// src/lib/useCampaignActions.ts — create / submit / approve / cancel campaigns.
// Real path: POST /api/campaign-send (server re-checks consent, 24h window, frequency, then n8n sends).
// Fallback (no Supabase service key / n8n): the same rules run in the browser and the send is SIMULATED.
import { useState } from 'react';
import { toast } from 'sonner';
import { useApp } from '../context/AppContext';
import { campaignActionViaServer } from './api';
import { db } from './db';
import { supabaseEnabled } from './supabase';
import { audienceStats, blockReason, buildCtx, renderCampaignText, segmentLeads } from './segments';
import type { Campaign } from './types';

export type CampaignDraft = Omit<Campaign, 'id' | 'created_at' | 'updated_at'>;

export const emptyCampaign = (createdBy: string | null): CampaignDraft => ({
  name: '', segment_key: 'interested_not_booked', segment_param: null, offer_type: 'announcement', offer_id: null,
  message: '', channel: 'whatsapp', template_name: null, template_language: 'ar',
  attachment_url: null, attachment_name: null, attachment_type: null, include_optout: true,
  scheduled_at: null, status: 'Draft', audience_lead_ids: [], last_error: null,
  created_by: createdBy, approved_by: null, sent_at: null,
});

export function useCampaignActions() {
  const { data, currentUser, addCampaign, updateCampaign, deleteCampaign, addMessage, updateLead, logActivity, refresh } = useApp();
  const [busy, setBusy] = useState<string | null>(null);

  const snapshot = (c: Pick<Campaign, 'segment_key' | 'segment_param' | 'channel' | 'template_name'>) => {
    const ctx = buildCtx(data);
    return audienceStats(segmentLeads(data, c.segment_key, c.segment_param, ctx), { channel: c.channel, hasTemplate: !!c.template_name?.trim() }, ctx);
  };

  /** null = ok, otherwise the sentence to show the user */
  const validate = (c: Pick<Campaign, 'name' | 'message' | 'scheduled_at'>): string | null => {
    if (!c.name.trim()) return 'Give the campaign a name.';
    if (!c.message.trim()) return 'Write the message.';
    if (c.scheduled_at && new Date(c.scheduled_at).getTime() < Date.now() - 60_000) return 'The send time is in the past. Pick a future time, or choose "send when approved".';
    return null;
  };

  /** Draft -> Pending Approval, freezing the audience that the approver will see. */
  const submit = (c: Campaign): boolean => {
    const problem = validate(c);
    if (problem) { toast.error(problem); return false; }
    const stats = snapshot(c);
    if (!stats.eligible.length) { toast.error('No eligible recipients. Check consent and the template (see the audience panel).'); return false; }
    updateCampaign(c.id, { status: 'Pending Approval', audience_lead_ids: stats.eligible.map(l => l.id), last_error: null });
    logActivity({ lead_id: null, actor_id: currentUser.id, event_type: 'Campaign Created', description: `Campaign "${c.name}" submitted for approval (${stats.eligible.length} recipients)`, metadata: { campaignId: c.id } });
    toast.success(`Submitted for approval: ${stats.eligible.length} recipients`);
    return true;
  };

  const simulateDispatch = (c: Campaign) => {
    const ctx = buildCtx(data);
    const ids = new Set(c.audience_lead_ids);
    const already = new Set(data.messages.filter(m => m.campaign_id === c.id && m.status !== 'Failed').map(m => m.lead_id));
    const now = new Date().toISOString();
    let sent = 0, skipped = 0;
    for (const l of data.leads.filter(x => ids.has(x.id))) {
      if (already.has(l.id) || blockReason(l, { channel: c.channel, hasTemplate: !!c.template_name?.trim() }, ctx)) { skipped++; continue; }
      const owner = data.profiles.find(p => p.id === l.assigned_to)?.full_name ?? 'Forkly';
      addMessage({
        lead_id: l.id, content: renderCampaignText(c.message, l, owner, c.include_optout), message_type: c.channel, direction: 'outbound',
        status: 'Accepted by Provider', provider_message_id: `sim-${Date.now()}-${sent}`, objective: `Campaign: ${c.name}`, simulated: true,
        campaign_id: c.id, template_name: c.template_name || null, template_language: c.template_name ? c.template_language : null,
      });
      updateLead(l.id, { last_contact_at: now });
      sent++;
    }
    updateCampaign(c.id, sent ? { status: 'Sent', sent_at: now, last_error: null } : { status: 'Failed', last_error: 'No eligible recipients (consent, 24h window or frequency cap).' });
    logActivity({ lead_id: null, actor_id: currentUser.id, event_type: 'Campaign Sent', description: `Campaign "${c.name}" sent (simulated): ${sent} recipients, ${skipped} skipped`, metadata: { campaignId: c.id, simulated: true } });
    if (sent) toast.success(`Sent (simulated) to ${sent} recipients${skipped ? `, ${skipped} skipped` : ''}`);
    else toast.error('Nobody was eligible at send time');
  };

  /** Manager action: approve, then send now or schedule. Also retries a Failed campaign. */
  const approve = async (c: Campaign) => {
    setBusy(c.id);
    try {
      if (supabaseEnabled) {
        await db.flush(); // the campaign row and its frozen audience must exist before the server reads them
        const r = await campaignActionViaServer(c.id, 'approve', currentUser.id);
        if (r.ok) {
          await refresh();
          toast.success(r.status === 'Scheduled' ? 'Approved and scheduled' : `Handed to n8n: ${r.sent ?? 0} recipients${r.skipped ? `, ${r.skipped} skipped` : ''}`);
          return;
        }
        if (!r.not_configured) { await refresh(); toast.error(r.error || 'Send failed. You can retry.'); return; }
        toast.message('n8n / service key not configured: simulating the send');
      }
      logActivity({ lead_id: null, actor_id: currentUser.id, event_type: 'Campaign Approved', description: `Campaign "${c.name}" approved by ${currentUser.full_name}`, metadata: { campaignId: c.id } });
      if (c.scheduled_at && new Date(c.scheduled_at).getTime() > Date.now() + 60_000) {
        updateCampaign(c.id, { status: 'Scheduled', approved_by: currentUser.id, last_error: null });
        toast.success('Approved and scheduled (simulation mode runs it while this page is open)');
        return;
      }
      updateCampaign(c.id, { status: 'Sending', approved_by: currentUser.id });
      simulateDispatch(c);
    } finally { setBusy(null); }
  };

  const cancel = async (c: Campaign) => {
    setBusy(c.id);
    try {
      if (supabaseEnabled) {
        await db.flush();
        const r = await campaignActionViaServer(c.id, 'cancel', currentUser.id);
        if (r.ok) { await refresh(); toast.success('Campaign cancelled'); return; }
        if (!r.not_configured) { await refresh(); toast.error(r.error || 'Could not cancel'); return; }
      }
      updateCampaign(c.id, { status: 'Cancelled' });
      logActivity({ lead_id: null, actor_id: currentUser.id, event_type: 'Campaign Cancelled', description: `Campaign "${c.name}" cancelled`, metadata: { campaignId: c.id } });
      toast.success('Campaign cancelled');
    } finally { setBusy(null); }
  };

  const duplicate = (c: Campaign) => {
    const { id: _id, created_at: _c, updated_at: _u, ...rest } = c;
    void _id; void _c; void _u;
    addCampaign({ ...rest, name: `${c.name} (copy)`, status: 'Draft', audience_lead_ids: [], scheduled_at: null, sent_at: null, approved_by: null, last_error: null, created_by: currentUser.id });
    toast.success('Duplicated as a draft');
  };

  return { busy, snapshot, validate, submit, approve, cancel, duplicate, remove: deleteCampaign, simulateDispatch, addCampaign, updateCampaign, data };
}
