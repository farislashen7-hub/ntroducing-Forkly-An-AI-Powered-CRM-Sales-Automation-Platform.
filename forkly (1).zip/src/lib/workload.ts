// src/lib/workload.ts — "My day" for one salesperson (or the whole team): today's follow-ups, overdue, upcoming appointments, completed.
// Pure functions over AppData.
import type { AppData, Booking, FollowUpTask, Lead, TaskPriority } from './types';

export interface WorkItem {
  key: string;
  kind: 'task' | 'lead';            // a follow-up task, or a lead whose "next follow-up" date has come
  id: string;                       // task id or lead id
  lead: Lead;
  title: string;
  detail: string;
  due: string;                      // ISO
  priority: TaskPriority;
}

export interface Workday {
  today: WorkItem[];
  overdue: WorkItem[];
  appointments: { booking: Booking; lead: Lead; when: number }[];   // next 14 days, incl. today
  completed: { task: FollowUpTask; lead: Lead | undefined }[];      // newest first
  completedToday: number;
}

const CLOSED = ['Converted', 'Lost'];
const startOfDay = (d = new Date()) => { const x = new Date(d); x.setHours(0, 0, 0, 0); return x.getTime(); };

/** userId = null -> whole team. A task belongs to its assignee, or to the lead's owner when unassigned. */
export function buildWorkday(data: AppData, userId: string | null, now = new Date()): Workday {
  const leadById = new Map(data.leads.map(l => [l.id, l]));
  const ownerOfTask = (t: FollowUpTask) => t.assigned_to ?? leadById.get(t.lead_id)?.assigned_to ?? null;
  const mine = (owner: string | null) => userId === null || owner === userId;

  const dayStart = startOfDay(now);
  const dayEnd = dayStart + 86400000 - 1;
  const items: WorkItem[] = [];

  const pendingTaskLeads = new Set<string>();
  for (const t of data.follow_up_tasks) {
    if (t.status !== 'Pending') continue;
    const lead = leadById.get(t.lead_id);
    if (!lead || lead.archived || !mine(ownerOfTask(t))) continue;
    pendingTaskLeads.add(lead.id);
    items.push({ key: `t-${t.id}`, kind: 'task', id: t.id, lead, title: t.title, detail: t.description, due: t.due_at, priority: t.priority });
  }
  // A lead's own "next follow-up" date counts too, unless a pending task already covers that lead (avoids duplicates).
  for (const l of data.leads) {
    if (l.archived || CLOSED.includes(l.status) || !l.next_follow_up_at || pendingTaskLeads.has(l.id) || !mine(l.assigned_to)) continue;
    items.push({ key: `l-${l.id}`, kind: 'lead', id: l.id, lead: l, title: `Follow up with ${l.name}`, detail: `${l.restaurant_name} · ${l.status}`, due: l.next_follow_up_at, priority: l.status === 'Interested' || l.status === 'Demo Booked' || l.status === 'Trial' ? 'High' : 'Medium' });
  }

  const t = (i: WorkItem) => new Date(i.due).getTime();
  const today = items.filter(i => t(i) >= dayStart && t(i) <= dayEnd).sort((a, b) => t(a) - t(b));
  const overdue = items.filter(i => t(i) < dayStart).sort((a, b) => t(a) - t(b));

  const horizon = dayStart + 15 * 86400000;
  const appointments = data.bookings
    .filter(b => ['Scheduled', 'Confirmed'].includes(b.status))
    .map(b => ({ booking: b, lead: leadById.get(b.lead_id), when: new Date(`${b.booking_date}T${b.booking_time || '00:00'}`).getTime() }))
    .filter((x): x is { booking: Booking; lead: Lead; when: number } => !!x.lead && !x.lead.archived && mine(x.booking.assigned_to ?? x.lead.assigned_to) && x.when >= dayStart && x.when < horizon)
    .sort((a, b) => a.when - b.when);

  const done = data.follow_up_tasks
    .filter(x => x.status === 'Completed' && mine(ownerOfTask(x)))
    .sort((a, b) => b.updated_at.localeCompare(a.updated_at));
  const completedToday = done.filter(x => new Date(x.updated_at).getTime() >= dayStart).length;

  return { today, overdue, appointments, completed: done.slice(0, 50).map(task => ({ task, lead: leadById.get(task.lead_id) })), completedToday };
}

/** how many overdue items a user has (for the sidebar badge) */
export const overdueCount = (data: AppData, userId: string) => buildWorkday(data, userId).overdue.length;
