// src/pages/Activity.tsx — Leads-style activity log: KPIs, type tabs, searchable timeline
import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Activity as ActivityIcon, AlertTriangle, CalendarDays, Search, ShieldCheck, Users } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Avatar, Empty, Kpi, KpiGrid, PageHeader, Panel, PillTabs, darkField } from '../components/ui/kit';
import { Badge, statusColor } from '../components/ui/Badge';
import { relativeDay } from '../lib/leadInsights';

const isError = (t: string) => /fail|error|reject/i.test(t);

export default function Activity() {
  const { data } = useApp();
  const [tab, setTab] = useState<'all' | 'errors' | 'messages' | 'leads'>('all');
  const [search, setSearch] = useState('');

  const logs = useMemo(() => [...data.activity_logs].sort((a, b) => b.created_at.localeCompare(a.created_at)), [data.activity_logs]);
  const kind = (t: string): 'errors' | 'messages' | 'leads' | 'other' =>
    isError(t) ? 'errors' : /message|draft|ai/i.test(t) ? 'messages' : /lead|pipeline|note/i.test(t) ? 'leads' : 'other';

  const counts = useMemo(() => ({
    all: logs.length,
    errors: logs.filter(l => kind(l.event_type) === 'errors').length,
    messages: logs.filter(l => kind(l.event_type) === 'messages').length,
    leads: logs.filter(l => kind(l.event_type) === 'leads').length,
  }), [logs]);

  const shown = logs.filter(l => {
    if (tab !== 'all' && kind(l.event_type) !== tab) return false;
    if (search && !`${l.description} ${l.event_type}`.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });
  const today = logs.filter(l => relativeDay(l.created_at) === 'Today').length;

  return (
    <div className="text-slate-100">
      <PageHeader title="Activity & Errors" subtitle="Timeline of everything that happened in your workspace" />

      <KpiGrid cols={4}>
        <Kpi icon={<ActivityIcon size={14} />} value={counts.all} label="Total Events" sub="All time" />
        <Kpi icon={<CalendarDays size={14} />} value={today} label="Today" sub="Events today" accent="text-emerald-400" />
        <Kpi icon={<AlertTriangle size={14} />} value={counts.errors} label="Errors" sub="Failed or rejected" accent={counts.errors ? 'text-rose-300' : undefined} />
        <Kpi icon={<Users size={14} />} value={counts.leads} label="Lead Events" sub="Created, updated, moved" />
      </KpiGrid>

      <PillTabs value={tab} onChange={setTab} tabs={[
        { v: 'all', l: 'All', n: counts.all }, { v: 'errors', l: 'Errors', n: counts.errors },
        { v: 'messages', l: 'Messages', n: counts.messages }, { v: 'leads', l: 'Leads', n: counts.leads },
      ]} />

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_340px]">
        <Panel title="Activity Timeline" icon={<ActivityIcon size={15} />}>
          <div className="relative mb-3 rounded-xl border border-white/10 bg-black/20 p-2">
            <Search size={14} className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-500" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search activity…" className={`${darkField} w-full pl-9 placeholder:text-slate-500`} />
          </div>
          {shown.length === 0 ? <Empty>No events match.</Empty> : (
            <ol className="max-h-[620px] space-y-4 overflow-y-auto pr-1">
              {shown.map(a => {
                const lead = a.lead_id ? data.leads.find(l => l.id === a.lead_id) : null;
                const actor = a.actor_id ? data.profiles.find(p => p.id === a.actor_id) : null;
                return (
                  <li key={a.id} className="flex gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-3">
                    <Avatar name={actor?.full_name ?? 'System'} size={32} />
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge color={isError(a.event_type) ? 'red' : 'indigo'}>{a.event_type}</Badge>
                        {lead && <Link to={`/leads/${lead.id}`} className="text-xs text-blue-300 hover:underline">{lead.name}</Link>}
                      </div>
                      <div className="mt-1 text-sm text-white">{a.description}</div>
                      <div className="mt-1 text-[11px] text-slate-400">{actor?.full_name || 'System'} · {relativeDay(a.created_at)} · {new Date(a.created_at).toLocaleString()}</div>
                    </div>
                  </li>
                );
              })}
            </ol>
          )}
        </Panel>

        <Panel title="Message State Reference" icon={<ShieldCheck size={15} />}>
          <div className="flex flex-wrap gap-2">
            {['Drafted', 'Pending Approval', 'Approved', 'Sending', 'Accepted by Provider', 'Delivered', 'Failed'].map(s => (
              <Badge key={s} color={statusColor(s)}>{s}</Badge>
            ))}
          </div>
          <p className="mt-3 text-xs text-slate-400">Provider acceptance is not proof of delivery. Simulated messages are never shown as delivered.</p>
        </Panel>
      </div>
    </div>
  );
}
