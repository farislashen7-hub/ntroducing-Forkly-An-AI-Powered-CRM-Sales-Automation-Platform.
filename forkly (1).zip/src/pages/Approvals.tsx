// src/pages/Approvals.tsx
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Avatar, Empty, InfoTile, Kpi, KpiGrid, PageHeader, Panel, PillTabs } from '../components/ui/kit';
import { Badge, statusColor } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Textarea } from '../components/ui/Input';
import { Modal } from '../components/ui/Modal';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { CheckCircle, XCircle, RefreshCw, Eye, Clock, History, Send, ShieldCheck } from 'lucide-react';
import { approveViaServer, regenerateViaServer } from '../lib/api';
import { supabaseEnabled } from '../lib/supabase';
import { db } from '../lib/db';
import { usePermissions } from '../lib/permissions';
import { CONSENT_LABEL, consentOf, isMarketingMessage, marketingBlock } from '../lib/segments';

export default function Approvals() {
  const { data, updateMessage, updateApproval, addMessage, addApproval, logActivity, currentUser, refresh } = useApp();
  const { can } = usePermissions();
  const canReview = can('approval.review');
  const [editingApproval, setEditingApproval] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');
  const [sending, setSending] = useState<string | null>(null);

  const pending = data.approvals.filter(a => a.status === 'Pending');
  const history = data.approvals.filter(a => a.status !== 'Pending');

  const approveAndSend = async (approvalId: string) => {
    const approval = data.approvals.find(a => a.id === approvalId);
    if (!approval) return;
    const msg = data.messages.find(m => m.id === approval.message_id);
    if (!msg) return;
    // idempotency: if already sent/accepted, block
    if (['Sending', 'Accepted by Provider', 'Delivered', 'Approved'].includes(msg.status) && msg.status !== 'Approved') {
      // already in flight
    }
    if (msg.status === 'Accepted by Provider' || msg.status === 'Delivered' || msg.status === 'Sending') {
      toast.error('Message already sent (idempotency guard)');
      return;
    }
    // marketing messages (win-back / campaign): consent + WhatsApp template rules, same as the server
    const block = marketingBlock(data, msg, data.leads.find(l => l.id === msg.lead_id));
    if (block) { toast.error(block); return; }
    setSending(approvalId);

    // 1) Real path: server -> n8n -> WhatsApp (needs Supabase + n8n configured)
    if (supabaseEnabled) {
      await db.flush(); // make sure any edited draft is saved before the server reads it
      const r = await approveViaServer(approvalId, undefined, currentUser.id);
      if (r.ok) {
        await refresh();
        toast.success(r.status === 'Delivered' ? 'Message delivered' : 'Sent via n8n');
        setSending(null);
        return;
      }
      if (!r.not_configured) {
        await refresh();
        toast.error(r.error || 'Send failed — you can retry');
        setSending(null);
        return;
      }
      // n8n / service key not configured on the server -> fall through to simulation
      toast.message('n8n not configured — simulating send');
    }

    // 2) Fallback: local simulation (no n8n)
    updateApproval(approvalId, { status: 'Approved', reviewed_by: currentUser.id, reviewed_at: new Date().toISOString(), approved_content: msg.content });
    updateMessage(msg.id, { status: 'Approved' });
    logActivity({ lead_id: msg.lead_id, actor_id: currentUser.id, event_type: 'Message Approved', description: `Message approved by ${currentUser.full_name}`, metadata: { messageId: msg.id } });
    updateMessage(msg.id, { status: 'Sending' });
    await new Promise(r => setTimeout(r, 700));
    updateMessage(msg.id, { status: 'Accepted by Provider', provider_message_id: `prov-${Date.now()}`, simulated: true });
    logActivity({ lead_id: msg.lead_id, actor_id: currentUser.id, event_type: 'Message Sent', description: `Message accepted by provider (simulated)`, metadata: { messageId: msg.id } });
    toast.success('Message sent (simulated)');
    setSending(null);
  };

  const reject = (approvalId: string) => {
    const approval = data.approvals.find(a => a.id === approvalId);
    if (!approval) return;
    const msg = data.messages.find(m => m.id === approval.message_id);
    updateApproval(approvalId, { status: 'Rejected', reviewed_by: currentUser.id, reviewed_at: new Date().toISOString() });
    if (msg) updateMessage(msg.id, { status: 'Drafted' });
    if (msg) logActivity({ lead_id: msg.lead_id, actor_id: currentUser.id, event_type: 'Message Rejected', description: `Message rejected`, metadata: { messageId: msg.id } });
    toast.success('Rejected');
  };

  const openEdit = (approvalId: string) => {
    const approval = data.approvals.find(a => a.id === approvalId);
    const msg = approval ? data.messages.find(m => m.id === approval.message_id) : null;
    setEditingApproval(approvalId);
    setEditContent(msg?.content || '');
  };

  const saveEdit = () => {
    const approval = data.approvals.find(a => a.id === editingApproval);
    if (!approval) return;
    const msg = data.messages.find(m => m.id === approval.message_id);
    if (msg) {
      updateMessage(msg.id, { content: editContent });
      logActivity({ lead_id: msg.lead_id, actor_id: currentUser.id, event_type: 'Draft Edited', description: `Draft edited before approval`, metadata: { messageId: msg.id } });
    }
    setEditingApproval(null);
    toast.success('Draft updated');
  };

  const [regenerating, setRegenerating] = useState<string | null>(null);

  const regenerate = async (approvalId: string) => {
    const approval = data.approvals.find(a => a.id === approvalId);
    if (!approval) return;
    const msg = data.messages.find(m => m.id === approval.message_id);
    if (!msg) return;
    setRegenerating(approvalId);

    // 1) Real path: server -> n8n (AI) -> new draft + new pending approval
    if (supabaseEnabled) {
      await db.flush();
      const r = await regenerateViaServer(approvalId, currentUser.id);
      if (r.ok) {
        await refresh();
        toast.success('Regenerated draft created');
        setRegenerating(null);
        return;
      }
      if (!r.not_configured) {
        await refresh();
        toast.error(r.error || 'Regenerate failed — try again');
        setRegenerating(null);
        return;
      }
      toast.message('n8n not configured — local regenerate');
    }

    // 2) Fallback: local simulation (no n8n)
    updateApproval(approvalId, { status: 'Regenerated' });
    const newMsg = addMessage({ lead_id: msg.lead_id, content: msg.content + ' (regenerated)', message_type: msg.message_type, direction: 'outbound', status: 'Pending Approval', provider_message_id: null, objective: msg.objective, simulated: msg.simulated });
    addApproval({ message_id: newMsg.id, requested_by: currentUser.id, reviewed_by: null, status: 'Pending', approved_content: null, reviewed_at: null });
    logActivity({ lead_id: msg.lead_id, actor_id: currentUser.id, event_type: 'AI Draft Generated', description: `Draft regenerated`, metadata: { messageId: newMsg.id } });
    toast.success('Regenerated draft created');
    setRegenerating(null);
  };

  const approvedCount = history.filter(a => a.status === 'Approved').length;
  const rejectedCount = history.filter(a => a.status === 'Rejected').length;
  const [tab, setTab] = useState<'pending' | 'history'>('pending');

  return (
    <div className="text-slate-100">
      <PageHeader title="Approval Center" subtitle="Review and approve AI-generated messages before sending" />

      <KpiGrid cols={4}>
        <Kpi icon={<Clock size={14} />} value={pending.length} label="Pending" sub="Awaiting your review" accent={pending.length ? 'text-amber-300' : undefined} />
        <Kpi icon={<CheckCircle size={14} />} value={approvedCount} label="Approved" sub="Sent to leads" accent="text-emerald-400" />
        <Kpi icon={<XCircle size={14} />} value={rejectedCount} label="Rejected" sub="Sent back to draft" accent={rejectedCount ? 'text-rose-300' : undefined} />
        <Kpi icon={<ShieldCheck size={14} />} value={data.approvals.length} label="Total Reviews" sub="All time" />
      </KpiGrid>

      <PillTabs value={tab} onChange={setTab} tabs={[{ v: 'pending', l: 'Pending', n: pending.length }, { v: 'history', l: 'History', n: history.length }]} />

      {tab === 'pending' && (
        <Panel title={`Pending Approvals (${pending.length})`} icon={<Send size={15} />}>
          {pending.length === 0 && <Empty>No pending approvals.</Empty>}
          <div className="space-y-4">
            {pending.map(ap => {
              const msg = data.messages.find(m => m.id === ap.message_id);
              const lead = msg ? data.leads.find(l => l.id === msg.lead_id) : null;
              return (
                <div key={ap.id} className="rounded-xl border border-white/10 bg-white/[0.03] p-4">
                  <div className="mb-3 flex items-center justify-between gap-3">
                    <div className="flex min-w-0 items-center gap-3">
                      <Avatar name={lead?.name ?? '?'} size={36} />
                      <div className="min-w-0">
                        <div className="truncate text-sm font-semibold text-white">{lead?.name} <span className="text-xs font-normal text-slate-400">· {lead?.restaurant_name}</span></div>
                        <div className="text-[11px] text-slate-400">{msg?.objective} · {msg?.message_type}</div>
                      </div>
                    </div>
                    <Badge color={statusColor(msg?.status || 'Pending Approval')}>{msg?.status}</Badge>
                  </div>
                  <p className="whitespace-pre-wrap rounded-xl border border-white/10 bg-black/20 p-3 text-sm text-slate-100">{msg?.content}</p>
                  <div className="mt-3 grid grid-cols-2 gap-2 md:grid-cols-4">
                    <InfoTile label="Phone" value={lead?.phone || '—'} />
                    <InfoTile label="Email" value={lead?.email || '—'} />
                    <InfoTile label="Source" value={lead?.source || '—'} />
                    <InfoTile label="Stage" value={lead?.status || '—'} />
                    <InfoTile label="Salesperson" value={data.profiles.find(p => p.id === lead?.assigned_to)?.full_name || 'Unassigned'} />
                    <InfoTile label="Requested by" value={data.profiles.find(p => p.id === ap.requested_by)?.full_name || '—'} />
                    <InfoTile label="Created" value={msg ? new Date(msg.created_at).toLocaleString() : '—'} />
                    <InfoTile label="Message type" value={`${msg?.message_type || '—'} · ${msg?.direction || '—'}`} />
                    <InfoTile label="Objective" value={msg?.objective || '—'} />
                    <InfoTile label="Approval created" value={new Date(ap.created_at).toLocaleString()} />
                    <InfoTile label="Simulated" value={msg?.simulated ? 'Yes' : 'No'} />
                    {msg && lead && isMarketingMessage(msg) && <InfoTile label="Marketing consent" value={CONSENT_LABEL[consentOf(lead)]} />}
                    {msg?.template_name && <InfoTile label="WhatsApp template" value={msg.template_name} />}
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {!canReview && <span className="self-center text-[11px] text-amber-300">Only managers and admins can review.</span>}
                    {canReview && <><Button size="sm" onClick={() => approveAndSend(ap.id)} loading={sending === ap.id} disabled={!!sending}>
                      <CheckCircle size={14} /> Approve & Send
                    </Button>
                    <Button size="sm" variant="secondary" onClick={() => openEdit(ap.id)}><Eye size={14} /> Edit</Button>
                    <Button size="sm" variant="secondary" disabled={regenerating === ap.id} onClick={() => regenerate(ap.id)}><RefreshCw size={14} className={regenerating === ap.id ? 'animate-spin' : ''} /> Regenerate</Button>
                    <Button size="sm" variant="danger" onClick={() => reject(ap.id)}><XCircle size={14} /> Reject</Button></>}
                    {lead && <Link to={`/leads/${lead.id}`}><Button size="sm" variant="ghost">View Lead</Button></Link>}
                  </div>
                </div>
              );
            })}
          </div>
        </Panel>
      )}

      {tab === 'history' && (
        <Panel title="History" icon={<History size={15} />}>
          {history.length === 0 && <Empty>No history.</Empty>}
          <div className="space-y-2">
            {history.map(ap => {
              const msg = data.messages.find(m => m.id === ap.message_id);
              const lead = msg ? data.leads.find(l => l.id === msg.lead_id) : null;
              return (
                <div key={ap.id} className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-3 text-sm hover:bg-white/[0.05]">
                  <div className="flex min-w-0 flex-1 items-center gap-3">
                    <Avatar name={lead?.name ?? '?'} size={32} />
                    <div className="min-w-0 flex-1">
                      <div className="font-medium text-white">{lead?.name} <span className="text-xs font-normal text-slate-400">· {ap.status}</span></div>
                      <div className="truncate text-xs text-slate-400">{msg?.content}</div>
                      {msg && <div className="mt-1 text-[10px] text-slate-500">{msg.objective} · {msg.message_type} · {new Date(msg.created_at).toLocaleString()} · {msg.simulated ? 'simulated' : 'live'}</div>}
                    </div>
                  </div>
                  <Badge color={statusColor(msg?.status || 'Drafted')}>{msg?.status}</Badge>
                </div>
              );
            })}
          </div>
        </Panel>
      )}

      <Modal open={!!editingApproval} onClose={() => setEditingApproval(null)} title="Edit Draft">
        <Textarea value={editContent} onChange={e => setEditContent(e.target.value)} className="min-h-[140px]" />
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setEditingApproval(null)}>Cancel</Button>
          <Button onClick={saveEdit}>Save</Button>
        </div>
      </Modal>
    </div>
  );
}
