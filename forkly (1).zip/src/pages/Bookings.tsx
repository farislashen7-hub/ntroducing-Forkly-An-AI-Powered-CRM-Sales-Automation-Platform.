// src/pages/Bookings.tsx
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Avatar, Empty, Kpi, KpiGrid, PageHeader, Panel, PillTabs, gradientBtn, tableWrap, td, th, thead, tr } from '../components/ui/kit';
import { Badge, statusColor } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Input, Select, Textarea } from '../components/ui/Input';
import { Modal } from '../components/ui/Modal';
import { toast } from 'sonner';
import { Plus, Calendar, Clock, CheckCircle2, XCircle, RotateCcw, AlertTriangle, ListChecks, Pencil } from 'lucide-react';
import type { BookingStatus, TaskStatus, TaskPriority } from '../lib/types';

export default function Bookings() {
  const { data, addBooking, updateBooking, addTask, updateTask, logActivity, currentUser } = useApp();
  const [tab, setTab] = useState<'bookings' | 'tasks'>('bookings');
  const [bookingModal, setBookingModal] = useState(false);
  const [editingBooking, setEditingBooking] = useState<string | null>(null);
  const [bookingForm, setBookingForm] = useState({ lead_id: '', booking_date: '', booking_time: '10:00', timezone: 'America/New_York', status: 'Scheduled' as BookingStatus, notes: '' });
  const [taskModal, setTaskModal] = useState(false);
  const [taskForm, setTaskForm] = useState({ lead_id: '', title: '', description: '', priority: 'Medium' as TaskPriority, due_at: '', status: 'Pending' as TaskStatus });

  const resetBookingForm = () => setBookingForm({ lead_id: '', booking_date: '', booking_time: '10:00', timezone: 'America/New_York', status: 'Scheduled', notes: '' });

  const openCreateBooking = () => { setEditingBooking(null); resetBookingForm(); setBookingModal(true); };
  const openEditBooking = (id: string) => {
    const b = data.bookings.find(x => x.id === id);
    if (!b) return;
    setEditingBooking(id);
    setBookingForm({ lead_id: b.lead_id, booking_date: b.booking_date, booking_time: b.booking_time, timezone: b.timezone, status: b.status, notes: b.notes });
    setBookingModal(true);
  };

  const saveBooking = () => {
    if (!bookingForm.lead_id || !bookingForm.booking_date) { toast.error('Lead and date required'); return; }
    if (editingBooking) {
      updateBooking(editingBooking, { ...bookingForm });
      logActivity({ lead_id: bookingForm.lead_id, actor_id: currentUser.id, event_type: 'Booking Created', description: `Booking updated`, metadata: null });
      toast.success('Booking updated');
    } else {
      const bk = addBooking({ lead_id: bookingForm.lead_id, booking_date: bookingForm.booking_date, booking_time: bookingForm.booking_time, timezone: bookingForm.timezone, status: bookingForm.status, assigned_to: currentUser.id, notes: bookingForm.notes });
      logActivity({ lead_id: bookingForm.lead_id, actor_id: currentUser.id, event_type: 'Booking Created', description: `Demo booked`, metadata: { bookingId: bk.id } });
      toast.success('Booking created');
    }
    setBookingModal(false);
  };

  const cancelBooking = (id: string) => {
    if (!confirm('Cancel booking?')) return;
    const b = data.bookings.find(x => x.id === id);
    updateBooking(id, { status: 'Cancelled' });
    if (b) logActivity({ lead_id: b.lead_id, actor_id: currentUser.id, event_type: 'Booking Cancelled', description: `Booking cancelled`, metadata: null });
    toast.success('Cancelled');
  };

  const completeBooking = (id: string) => {
    updateBooking(id, { status: 'Completed' });
    toast.success('Marked completed');
  };

  // Tasks
  const dayStart = new Date(); dayStart.setHours(0, 0, 0, 0);
  const dayEnd = new Date(); dayEnd.setHours(23, 59, 59, 999);
  const dueToday = data.follow_up_tasks.filter(t => t.status === 'Pending' && new Date(t.due_at).getTime() >= dayStart.getTime() && new Date(t.due_at).getTime() <= dayEnd.getTime());
  const overdue = data.follow_up_tasks.filter(t => t.status === 'Pending' && new Date(t.due_at).getTime() < dayStart.getTime());
  const upcoming = data.follow_up_tasks.filter(t => t.status === 'Pending' && new Date(t.due_at).getTime() > dayEnd.getTime());
  const needsAttention = data.follow_up_tasks.filter(t => t.status === 'Pending' && t.priority === 'Urgent');
  const completed = data.follow_up_tasks.filter(t => t.status === 'Completed');

  const openCreateTask = () => {
    setTaskForm({ lead_id: '', title: '', description: '', priority: 'Medium', due_at: '', status: 'Pending' });
    setTaskModal(true);
  };

  const saveTask = () => {
    if (!taskForm.lead_id || !taskForm.title || !taskForm.due_at) { toast.error('Lead, title, due date required'); return; }
    addTask({ lead_id: taskForm.lead_id, title: taskForm.title, description: taskForm.description, priority: taskForm.priority, due_at: new Date(taskForm.due_at).toISOString(), status: taskForm.status, assigned_to: currentUser.id });
    logActivity({ lead_id: taskForm.lead_id, actor_id: currentUser.id, event_type: 'Follow-up Created', description: `Follow-up: ${taskForm.title}`, metadata: null });
    setTaskModal(false);
    toast.success('Task created');
  };

  const renderTask = (t: typeof data.follow_up_tasks[0]) => {
    const lead = data.leads.find(l => l.id === t.lead_id);
    return (
      <div key={t.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-3 text-sm hover:bg-white/[0.05]">
        <div className="flex min-w-0 flex-1 items-center gap-3">
          <Avatar name={lead?.name ?? '?'} size={32} />
          <div className="min-w-0">
            <div className="truncate font-medium text-white">{t.title} <span className="text-xs font-normal text-slate-400">· {lead?.name}</span></div>
            <div className="truncate text-[11px] text-slate-400">{t.description} · Due {new Date(t.due_at).toLocaleString()}</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge color={statusColor(t.priority)}>{t.priority}</Badge>
          <Badge color={statusColor(t.status)}>{t.status}</Badge>
          {t.status === 'Pending' && (
            <>
              <Button size="sm" variant="ghost" title="Complete" onClick={() => { updateTask(t.id, { status: 'Completed' }); toast.success('Completed'); }}><CheckCircle2 size={14} /></Button>
              <Button size="sm" variant="ghost" title="Reschedule" onClick={() => { const d = prompt('New due date (YYYY-MM-DDTHH:mm)', t.due_at.slice(0,16)); if (d) { updateTask(t.id, { due_at: new Date(d).toISOString() }); toast.success('Rescheduled'); } }}><RotateCcw size={14} /></Button>
              <Button size="sm" variant="ghost" title="Cancel" onClick={() => { updateTask(t.id, { status: 'Cancelled' }); toast.success('Cancelled'); }}><XCircle size={14} /></Button>
            </>
          )}
        </div>
      </div>
    );
  };

  const upcomingBookings = data.bookings.filter(b => ['Scheduled', 'Confirmed'].includes(b.status)).length;

  return (
    <div className="text-slate-100">
      <PageHeader title="Bookings & Follow-ups" subtitle="Manage demos and follow-up tasks">
        <button onClick={tab === 'bookings' ? openCreateBooking : openCreateTask} className={gradientBtn}><Plus size={14} /> {tab === 'bookings' ? 'New Booking' : 'New Task'}</button>
      </PageHeader>

      <KpiGrid cols={4}>
        <Kpi icon={<Calendar size={14} />} value={data.bookings.length} label="Demo Bookings" sub={`${upcomingBookings} scheduled or confirmed`} />
        <Kpi icon={<AlertTriangle size={14} />} value={overdue.length} label="Overdue" sub="Past due tasks" accent={overdue.length ? 'text-rose-300' : undefined} />
        <Kpi icon={<Clock size={14} />} value={dueToday.length} label="Due Today" sub="Pending today" accent="text-amber-300" />
        <Kpi icon={<ListChecks size={14} />} value={completed.length} label="Completed" sub="Finished tasks" accent="text-emerald-400" />
      </KpiGrid>

      <PillTabs value={tab} onChange={setTab} tabs={[
        { v: 'bookings', l: 'Demo Bookings', n: data.bookings.length },
        { v: 'tasks', l: 'Follow-up Tasks', n: data.follow_up_tasks.length },
      ]} />

      {tab === 'bookings' && (
        <Panel title="Demo Bookings" icon={<Calendar size={15} />}>
          <div className={tableWrap}>
            <table className="w-full min-w-[820px] text-sm">
              <thead className={thead}>
                <tr>{['Lead', 'Restaurant', 'Date', 'Time', 'Timezone', 'Status', 'Salesperson', 'Notes', ''].map((h, i) => <th key={i} className={th}>{h}</th>)}</tr>
              </thead>
              <tbody>
                {data.bookings.map(b => {
                  const lead = data.leads.find(l => l.id === b.lead_id);
                  const prof = data.profiles.find(p => p.id === b.assigned_to);
                  return (
                    <tr key={b.id} className={tr}>
                      <td className={td}><span className="flex items-center gap-2.5 font-medium text-white"><Avatar name={lead?.name ?? '?'} />{lead?.name}</span></td>
                      <td className={`${td} text-slate-300`}>{lead?.restaurant_name}</td>
                      <td className={`${td} text-xs text-slate-300`}>{b.booking_date}</td>
                      <td className={`${td} text-xs text-slate-300`}>{b.booking_time}</td>
                      <td className={`${td} text-xs text-slate-400`}>{b.timezone}</td>
                      <td className={td}><Badge color={statusColor(b.status)}>{b.status}</Badge></td>
                      <td className={`${td} text-xs text-slate-300`}>{prof?.full_name || '—'}</td>
                      <td className={`${td} max-w-[160px] truncate text-xs text-slate-400`}>{b.notes}</td>
                      <td className={td}>
                        <div className="flex gap-1">
                          <Button size="sm" variant="ghost" title="Edit" onClick={() => openEditBooking(b.id)}><Pencil size={13} /></Button>
                          <Button size="sm" variant="ghost" title="Complete" onClick={() => completeBooking(b.id)}><CheckCircle2 size={13} /></Button>
                          <Button size="sm" variant="ghost" title="Cancel" onClick={() => cancelBooking(b.id)}><XCircle size={13} /></Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
                {data.bookings.length === 0 && <tr><td colSpan={9} className="px-4 py-10 text-center text-sm text-slate-400">No bookings.</td></tr>}
              </tbody>
            </table>
          </div>
        </Panel>
      )}

      {tab === 'tasks' && (
        <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
          {[
            { title: 'Overdue', items: overdue },
            { title: 'Due Today', items: dueToday },
            { title: 'Needs Attention (Urgent)', items: needsAttention },
            { title: 'Upcoming', items: upcoming },
            { title: 'Completed', items: completed },
          ].map(section => (
            <Panel key={section.title} title={`${section.title} (${section.items.length})`} icon={<ListChecks size={15} />}>
              {section.items.length === 0 ? <Empty>None.</Empty> : <div className="space-y-2">{section.items.map(renderTask)}</div>}
            </Panel>
          ))}
        </div>
      )}

      <Modal open={bookingModal} onClose={() => setBookingModal(false)} title={editingBooking ? 'Edit Booking' : 'New Booking'}>
        <div className="space-y-3">
          <Select label="Lead" value={bookingForm.lead_id} onChange={e => setBookingForm({ ...bookingForm, lead_id: e.target.value })}>
            <option value="">Select lead</option>
            {data.leads.filter(l => !l.archived).map(l => <option key={l.id} value={l.id}>{l.name} — {l.restaurant_name}</option>)}
          </Select>
          <Input label="Date" type="date" value={bookingForm.booking_date} onChange={e => setBookingForm({ ...bookingForm, booking_date: e.target.value })} />
          <Input label="Time" type="time" value={bookingForm.booking_time} onChange={e => setBookingForm({ ...bookingForm, booking_time: e.target.value })} />
          <Select label="Timezone" value={bookingForm.timezone} onChange={e => setBookingForm({ ...bookingForm, timezone: e.target.value })}>
            <option value="America/New_York">America/New_York</option>
            <option value="America/Chicago">America/Chicago</option>
            <option value="America/Los_Angeles">America/Los_Angeles</option>
            <option value="Europe/London">Europe/London</option>
          </Select>
          <Select label="Status" value={bookingForm.status} onChange={e => setBookingForm({ ...bookingForm, status: e.target.value as BookingStatus })}>
            {(['Scheduled', 'Confirmed', 'Completed', 'Cancelled', 'No-show'] as BookingStatus[]).map(s => <option key={s} value={s}>{s}</option>)}
          </Select>
          <Textarea label="Notes" value={bookingForm.notes} onChange={e => setBookingForm({ ...bookingForm, notes: e.target.value })} />
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setBookingModal(false)}>Cancel</Button>
          <Button onClick={saveBooking}>Save</Button>
        </div>
      </Modal>

      <Modal open={taskModal} onClose={() => setTaskModal(false)} title="New Follow-up Task">
        <div className="space-y-3">
          <Select label="Lead" value={taskForm.lead_id} onChange={e => setTaskForm({ ...taskForm, lead_id: e.target.value })}>
            <option value="">Select lead</option>
            {data.leads.filter(l => !l.archived).map(l => <option key={l.id} value={l.id}>{l.name} — {l.restaurant_name}</option>)}
          </Select>
          <Input label="Title" value={taskForm.title} onChange={e => setTaskForm({ ...taskForm, title: e.target.value })} />
          <Textarea label="Description" value={taskForm.description} onChange={e => setTaskForm({ ...taskForm, description: e.target.value })} />
          <Select label="Priority" value={taskForm.priority} onChange={e => setTaskForm({ ...taskForm, priority: e.target.value as TaskPriority })}>
            {(['Low', 'Medium', 'High', 'Urgent'] as TaskPriority[]).map(p => <option key={p} value={p}>{p}</option>)}
          </Select>
          <Input label="Due" type="datetime-local" value={taskForm.due_at} onChange={e => setTaskForm({ ...taskForm, due_at: e.target.value })} />
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setTaskModal(false)}>Cancel</Button>
          <Button onClick={saveTask}>Create</Button>
        </div>
      </Modal>
    </div>
  );
}
