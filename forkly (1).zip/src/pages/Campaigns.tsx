// src/pages/Campaigns.tsx — marketing campaigns: list + builder, customer segments, win-back, analytics
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { AlertTriangle, CheckCircle, Copy, Megaphone, Pencil, Plus, RotateCcw, Send, Trash2, XCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Badge, statusColor } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Empty, Kpi, KpiGrid, PageHeader, Panel, PillTabs, gradientBtn, tableWrap, td, th, thead, tr } from '../components/ui/kit';
import { CampaignBuilder } from './campaigns/CampaignBuilder';
import { SegmentsTab } from './campaigns/SegmentsTab';
import { WinBackTab } from './campaigns/WinBackTab';
import { AnalyticsTab } from './campaigns/AnalyticsTab';
import { usePermissions } from '../lib/permissions';
import { useCampaignActions } from '../lib/useCampaignActions';
import { statsForCampaign } from '../lib/campaignStats';
import { segmentLabel } from '../lib/segments';
import { getMissingTables } from '../lib/db';
import { getHealth } from '../lib/api';
import { supabaseEnabled } from '../lib/supabase';
import { formatDateTime } from '../lib/utils';
import type { Campaign, SegmentKey } from '../lib/types';

type Tab = 'campaigns' | 'new' | 'segments' | 'winback' | 'analytics';
const TABS: Tab[] = ['campaigns', 'new', 'segments', 'winback', 'analytics'];

export default function Campaigns() {
  const { data, syncState } = useApp();
  const { can } = usePermissions();
  const A = useCampaignActions();
  const [params, setParams] = useSearchParams();
  const tabParam = params.get('tab') as Tab | null;
  const [tab, setTab] = useState<Tab>(tabParam && TABS.includes(tabParam) ? tabParam : 'campaigns');
  const [editingId, setEditingId] = useState<string | null>(null);

  // tab <-> URL (so "Create campaign" buttons elsewhere can deep-link)
  useEffect(() => { if (tabParam && TABS.includes(tabParam) && tabParam !== tab) setTab(tabParam); }, [tabParam]); // eslint-disable-line react-hooks/exhaustive-deps
  const go = (t: Tab) => { setTab(t); setEditingId(null); setParams(t === 'campaigns' ? {} : { tab: t }, { replace: true }); };

  const campaigns = data.campaigns;
  const pending = campaigns.filter(c => c.status === 'Pending Approval').length;
  const scheduled = campaigns.filter(c => c.status === 'Scheduled').length;
  const sent = campaigns.filter(c => c.status === 'Sent').length;
  const missing = supabaseEnabled && syncState !== 'loading' ? getMissingTables().includes('campaigns') : false;
  const editing = editingId ? campaigns.find(c => c.id === editingId) ?? null : null;

  // Simulation mode only (no server / n8n): run due scheduled campaigns while this page is open.
  // With the server configured, POST /api/campaigns-run does it (README).
  const [serverReady, setServerReady] = useState<boolean | null>(null);
  useEffect(() => { let on = true; getHealth().then(h => { if (on) setServerReady(Boolean(h?.supabase_server && h?.n8n)); }); return () => { on = false; }; }, []);
  const ran = useRef(new Set<string>());
  const actions = useRef(A);
  useEffect(() => { actions.current = A; }); // always the latest data inside the interval
  useEffect(() => {
    if (serverReady !== false) return;
    const t = setInterval(() => {
      for (const c of data.campaigns) {
        if (c.status === 'Scheduled' && c.scheduled_at && new Date(c.scheduled_at).getTime() <= Date.now() && !ran.current.has(c.id)) {
          ran.current.add(c.id);
          actions.current.simulateDispatch(c);
        }
      }
    }, 20000);
    return () => clearInterval(t);
  }, [serverReady, data.campaigns]);

  const preset = useMemo(() => ({
    segment: (params.get('segment') as SegmentKey | null) ?? undefined,
    param: params.get('param'),
    offer: params.get('offer') ?? undefined,
  }), [params]);

  const remove = (c: Campaign) => { if (confirm(`Delete "${c.name}"?`)) A.remove(c.id); };

  return (
    <div className="text-slate-100">
      <PageHeader title="Campaigns" subtitle="Send marketing messages to the right customers, with consent, approval and results">
        {can('campaign.write') && <button onClick={() => { setEditingId(null); go('new'); }} className={gradientBtn}><Plus size={14} /> New Campaign</button>}
      </PageHeader>

      {missing && (
        <div className="mb-5 flex items-start gap-2 rounded-xl border border-amber-400/30 bg-amber-500/10 p-3 text-xs text-amber-200">
          <AlertTriangle size={15} className="mt-0.5 shrink-0" />
          <span>The campaigns table is missing in Supabase. Run <code className="rounded bg-black/30 px-1">supabase/migrations/005_campaigns.sql</code> (or <code className="rounded bg-black/30 px-1">RUN_ALL.sql</code>) in the SQL Editor, then reload.</span>
        </div>
      )}

      <PillTabs value={tab} onChange={go} tabs={[
        { v: 'campaigns', l: 'Campaigns', n: campaigns.length },
        ...(can('campaign.write') ? [{ v: 'new' as Tab, l: editing ? 'Edit campaign' : 'New campaign' }] : []),
        { v: 'segments', l: 'Segments' },
        { v: 'winback', l: 'Win-back' },
        { v: 'analytics', l: 'Analytics' },
      ]} />

      {tab === 'new' && <CampaignBuilder key={editing?.id ?? `new-${params.toString()}`} editing={editing} preset={preset} onDone={() => go('campaigns')} />}
      {tab === 'segments' && <SegmentsTab />}
      {tab === 'winback' && <WinBackTab />}
      {tab === 'analytics' && <AnalyticsTab />}

      {tab === 'campaigns' && (
        <>
          <KpiGrid cols={4}>
            <Kpi icon={<Megaphone size={14} />} value={campaigns.length} label="Campaigns" sub="All time" />
            <Kpi value={pending} label="Awaiting approval" sub={can('campaign.approve') ? 'Review and approve below' : 'A manager must approve'} accent={pending ? 'text-amber-300' : undefined} />
            <Kpi value={scheduled} label="Scheduled" sub="Will send at the chosen time" accent="text-sky-300" />
            <Kpi value={sent} label="Sent" sub="Completed" accent="text-emerald-400" />
          </KpiGrid>

          <Panel title={`All campaigns (${campaigns.length})`} icon={<Send size={15} />}>
            {campaigns.length === 0 ? <Empty>No campaigns yet. Click “New Campaign” to create the first one.</Empty> : (
              <div className={tableWrap}>
                <table className="w-full text-xs">
                  <thead className={thead}>
                    <tr><th className={th}>Campaign</th><th className={th}>Audience</th><th className={th}>Channel</th><th className={th}>Status</th><th className={th}>When</th><th className={th}>Results</th><th className={th}>Actions</th></tr>
                  </thead>
                  <tbody>
                    {campaigns.map(c => {
                      const st = c.status === 'Sent' || c.status === 'Sending' ? statsForCampaign(data, c.id) : null;
                      const busy = A.busy === c.id;
                      return (
                        <tr key={c.id} className={tr}>
                          <td className={td}>
                            <span className="block font-medium text-slate-100">{c.name}</span>
                            <span className="block text-[10px] text-slate-500">by {data.profiles.find(p => p.id === c.created_by)?.full_name ?? '—'}</span>
                            {c.status === 'Failed' && c.last_error && <span className="mt-0.5 block max-w-[260px] whitespace-normal text-[10px] text-rose-300">{c.last_error}</span>}
                          </td>
                          <td className={td}>{segmentLabel(c.segment_key)}{c.audience_lead_ids.length > 0 && <span className="text-slate-500"> · {c.audience_lead_ids.length}</span>}</td>
                          <td className={td + ' capitalize'}>{c.channel}</td>
                          <td className={td}><Badge color={c.status === 'Sent' ? 'green' : statusColor(c.status)}>{c.status}</Badge></td>
                          <td className={td + ' text-slate-400'}>{c.status === 'Sent' ? formatDateTime(c.sent_at) : c.scheduled_at ? formatDateTime(c.scheduled_at) : 'When approved'}</td>
                          <td className={td + ' text-slate-400'}>{st ? `${st.sent} sent · ${st.replies} replies · ${st.bookings} bookings` : '—'}</td>
                          <td className={td}>
                            <div className="flex flex-wrap gap-1.5">
                              {c.status === 'Draft' && can('campaign.write') && <>
                                <Button size="sm" variant="secondary" onClick={() => { setEditingId(c.id); setTab('new'); setParams({ tab: 'new' }, { replace: true }); }}><Pencil size={12} /> Edit</Button>
                                <Button size="sm" onClick={() => A.submit(c)}><Send size={12} /> Submit</Button>
                              </>}
                              {(c.status === 'Pending Approval' || c.status === 'Failed') && can('campaign.approve') &&
                                <Button size="sm" variant="success" loading={busy} disabled={!!A.busy} onClick={() => A.approve(c)}>{c.status === 'Failed' ? <><RotateCcw size={12} /> Retry</> : <><CheckCircle size={12} /> Approve</>}</Button>}
                              {['Draft', 'Pending Approval', 'Scheduled'].includes(c.status) && can('campaign.write') &&
                                <Button size="sm" variant="ghost" disabled={!!A.busy} onClick={() => A.cancel(c)}><XCircle size={12} /> Cancel</Button>}
                              {can('campaign.write') && <Button size="sm" variant="ghost" onClick={() => A.duplicate(c)} title="Duplicate"><Copy size={12} /></Button>}
                              {['Draft', 'Cancelled'].includes(c.status) && can('campaign.write') && <Button size="sm" variant="ghost" onClick={() => remove(c)} title="Delete"><Trash2 size={12} className="text-rose-400" /></Button>}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </Panel>
        </>
      )}
    </div>
  );
}
