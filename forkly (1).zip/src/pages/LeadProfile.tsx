// src/pages/LeadProfile.tsx
import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Card, CardBody, CardHeader } from '../components/ui/Card';
import { Avatar, Kpi, KpiGrid, ScoreBar, StatusChip, fmtShort, glass } from '../components/ui/kit';
import { buildScores, relativeDay } from '../lib/leadInsights';
import { Badge, statusColor } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Input, Select, Textarea } from '../components/ui/Input';
import { Modal } from '../components/ui/Modal';
import { toast } from 'sonner';
import { ArrowLeft, MessageSquare, Calendar, Clock } from 'lucide-react';
import type { LeadStatus, TaskPriority } from '../lib/types';
import { ConsentPanel } from '../components/ConsentPanel';

export default function LeadProfile() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { data, updateLead, addMessage, addApproval, addBooking, addTask, logActivity, currentUser } = useApp();
  const lead = data.leads.find(l => l.id === id);
  const [statusModal, setStatusModal] = useState(false);
  const [taskModal, setTaskModal] = useState(false);
  const [bookingModal, setBookingModal] = useState(false);
  const [note, setNote] = useState('');
  const [newStatus, setNewStatus] = useState<LeadStatus>('New');
  const [taskForm, setTaskForm] = useState({ title: '', description: '', priority: 'Medium' as TaskPriority, due_at: '' });
  const [bookingForm, setBookingForm] = useState({ booking_date: '', booking_time: '10:00', timezone: 'America/New_York', notes: '' });

  if (!lead) return <div className="text-slate-400">Lead not found. <Link to="/leads" className="text-blue-300">Back</Link></div>;

  const conversations = data.conversations.filter(c => c.lead_id === lead.id).sort((a, b) => a.created_at.localeCompare(b.created_at));
  const messages = data.messages.filter(m => m.lead_id === lead.id);
  const approvals = data.approvals.filter(a => messages.some(m => m.id === a.message_id));
  const bookings = data.bookings.filter(b => b.lead_id === lead.id);
  const tasks = data.follow_up_tasks.filter(t => t.lead_id === lead.id);
  const activity = data.activity_logs.filter(a => a.lead_id === lead.id).sort((a, b) => b.created_at.localeCompare(a.created_at));

  const generateDraft = () => {
    const content = `Hi ${lead.name.split(' ')[0]}, thanks for your interest in Forkly for ${lead.restaurant_name}. Based on our last touchpoint, I'd love to show you how we can help streamline your ordering and boost revenue. Would you be open to a quick 15-min demo this week?`;
    const msg = addMessage({ lead_id: lead.id, content, message_type: 'whatsapp', direction: 'outbound', status: 'Pending Approval', provider_message_id: null, objective: 'Follow-up', simulated: false });
    addApproval({ message_id: msg.id, requested_by: currentUser.id, reviewed_by: null, status: 'Pending', approved_content: null, reviewed_at: null });
    logActivity({ lead_id: lead.id, actor_id: currentUser.id, event_type: 'AI Draft Generated', description: `AI draft generated for ${lead.name}`, metadata: { messageId: msg.id } });
    toast.success('AI draft generated (sample) — pending approval');
  };

  const addNote = () => {
    if (!note.trim()) return;
    logActivity({ lead_id: lead.id, actor_id: currentUser.id, event_type: 'Note Added', description: note, metadata: null });
    setNote('');
    toast.success('Note added');
  };

  const scheduleFollowUp = () => {
    if (!taskForm.title || !taskForm.due_at) { toast.error('Title and due date required'); return; }
    addTask({ lead_id: lead.id, title: taskForm.title, description: taskForm.description, priority: taskForm.priority, due_at: new Date(taskForm.due_at).toISOString(), status: 'Pending', assigned_to: currentUser.id });
    logActivity({ lead_id: lead.id, actor_id: currentUser.id, event_type: 'Follow-up Created', description: `Follow-up: ${taskForm.title}`, metadata: null });
    setTaskModal(false);
    setTaskForm({ title: '', description: '', priority: 'Medium', due_at: '' });
    toast.success('Follow-up scheduled');
  };

  const createBooking = () => {
    if (!bookingForm.booking_date) { toast.error('Date required'); return; }
    const bk = addBooking({ lead_id: lead.id, booking_date: bookingForm.booking_date, booking_time: bookingForm.booking_time, timezone: bookingForm.timezone, status: 'Scheduled', assigned_to: currentUser.id, notes: bookingForm.notes });
    updateLead(lead.id, { status: 'Demo Booked', next_follow_up_at: new Date(bookingForm.booking_date + 'T' + bookingForm.booking_time).toISOString() });
    logActivity({ lead_id: lead.id, actor_id: currentUser.id, event_type: 'Booking Created', description: `Demo booked for ${lead.name}`, metadata: { bookingId: bk.id } });
    setBookingModal(false);
    setBookingForm({ booking_date: '', booking_time: '10:00', timezone: 'America/New_York', notes: '' });
    toast.success('Demo booked');
  };

  const changeStatus = () => {
    updateLead(lead.id, { status: newStatus });
    logActivity({ lead_id: lead.id, actor_id: currentUser.id, event_type: 'Status Changed', description: `${lead.name} → ${newStatus}`, metadata: null });
    setStatusModal(false);
    toast.success('Status updated');
  };

  const profile = data.profiles.find(p => p.id === lead.assigned_to);

  const score = buildScores(data).get(lead.id) ?? 0;

  return (
    <div className="space-y-5 text-slate-100">
      <div className={`${glass} flex flex-wrap items-center gap-4 p-4`}>
        <Button variant="secondary" size="sm" onClick={() => navigate('/leads')}><ArrowLeft size={14} /> Leads</Button>
        <Avatar name={lead.name} size={48} />
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-2xl font-semibold text-white">{lead.name}</h1>
          <p className="text-xs text-slate-400">{lead.restaurant_name} · {lead.source}</p>
        </div>
        <div className="w-40"><ScoreBar score={score} wide /></div>
        <StatusChip status={lead.status} />
      </div>

      <KpiGrid cols={4}>
        <Kpi value={score} label="Lead Score" sub={score >= 80 ? 'Hot lead' : 'Keep nurturing'} accent={score >= 80 ? 'text-orange-300' : undefined} />
        <Kpi value={lead.last_contact_at ? relativeDay(lead.last_contact_at) : '—'} label="Last Contact" sub={fmtShort(lead.last_contact_at)} />
        <Kpi value={lead.next_follow_up_at ? fmtShort(lead.next_follow_up_at) : '—'} label="Next Follow-up" sub={lead.next_follow_up_at ? relativeDay(lead.next_follow_up_at) : 'Not scheduled'} />
        <Kpi value={bookings.length} label="Bookings" sub={`${tasks.length} follow-up task${tasks.length === 1 ? '' : 's'}`} />
      </KpiGrid>

      <div className="flex flex-wrap gap-2">
        <Button size="sm" onClick={generateDraft}><MessageSquare size={14} /> Generate AI Follow-up</Button>
        <Button size="sm" variant="secondary" onClick={() => setTaskModal(true)}><Clock size={14} /> Schedule Follow-up</Button>
        <Button size="sm" variant="secondary" onClick={() => { setNewStatus(lead.status); setStatusModal(true); }}>Update Status</Button>
        <Button size="sm" variant="secondary" onClick={() => setBookingModal(true)}><Calendar size={14} /> Book Demo</Button>
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardHeader><h3 className="text-sm font-semibold">Contact & Restaurant</h3></CardHeader>
          <CardBody className="space-y-2 text-sm">
            <Row label="Phone" value={lead.phone} />
            <Row label="Email" value={lead.email} />
            <Row label="Source" value={lead.source} />
            <Row label="Stage" value={lead.status} />
            <Row label="Salesperson" value={profile?.full_name || 'Unassigned'} />
            <Row label="Last Contact" value={lead.last_contact_at ? new Date(lead.last_contact_at).toLocaleString() : '—'} />
            <Row label="Next Follow-up" value={lead.next_follow_up_at ? new Date(lead.next_follow_up_at).toLocaleString() : '—'} />
            <Row label="Created" value={new Date(lead.created_at).toLocaleString()} />
            <div className="pt-2">
              <p className="text-xs text-slate-400 mb-1">Notes</p>
              <p className="text-sm">{lead.notes || '—'}</p>
            </div>
            <div className="pt-2 flex gap-2">
              <Button size="sm" variant="ghost" onClick={() => { updateLead(lead.id, { assigned_to: currentUser.id }); toast.success('Assigned to you'); }}>Assign to me</Button>
            </div>
          </CardBody>
        </Card>

        <div className="space-y-5 lg:col-span-2">
          <ConsentPanel key={`${lead.id}-${lead.consent_status ?? ''}-${(lead.interests ?? []).join('|')}`} lead={lead} />
          <Card>
            <CardHeader><h3 className="text-sm font-semibold">Conversations</h3></CardHeader>
            <CardBody className="space-y-3 max-h-64 overflow-y-auto">
              {conversations.length === 0 && <p className="text-sm text-slate-400">No conversations yet.</p>}
              {conversations.map(c => (
                <div key={c.id} className={`flex ${c.direction === 'outbound' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] px-3 py-2 rounded-lg text-sm ${c.direction === 'outbound' ? 'bg-blue-500 text-white' : 'bg-white/[0.06] text-white'}`}>
                    {c.content}
                    <div className="text-[10px] opacity-70 mt-1">{new Date(c.created_at).toLocaleString()}</div>
                  </div>
                </div>
              ))}
            </CardBody>
          </Card>

          <Card>
            <CardHeader><h3 className="text-sm font-semibold">AI Drafts & Approvals</h3></CardHeader>
            <CardBody className="space-y-3">
              {messages.length === 0 && <p className="text-sm text-slate-400">No drafts yet.</p>}
              {messages.map(m => {
                const ap = approvals.find(a => a.message_id === m.id);
                return (
                  <div key={m.id} className="p-3 border border-white/10 rounded-xl">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs text-slate-400">{m.objective} · {m.message_type}</span>
                      <Badge color={statusColor(m.status)}>{m.status}</Badge>
                    </div>
                    <p className="text-sm">{m.content}</p>
                    {ap && <p className="text-xs text-slate-400 mt-2">Approval: {ap.status}{ap.reviewed_by ? ` by ${data.profiles.find(p=>p.id===ap.reviewed_by)?.full_name}` : ''}</p>}
                  </div>
                );
              })}
            </CardBody>
          </Card>

          <Card>
            <CardHeader><h3 className="text-sm font-semibold">Bookings</h3></CardHeader>
            <CardBody className="space-y-2">
              {bookings.length === 0 && <p className="text-sm text-slate-400">No bookings.</p>}
              {bookings.map(b => (
                <div key={b.id} className="flex items-center justify-between p-2 border border-white/10 rounded-xl text-sm">
                  <span>{b.booking_date} {b.booking_time} ({b.timezone})</span>
                  <Badge color={statusColor(b.status)}>{b.status}</Badge>
                </div>
              ))}
            </CardBody>
          </Card>

          <Card>
            <CardHeader><h3 className="text-sm font-semibold">Follow-up Tasks</h3></CardHeader>
            <CardBody className="space-y-2">
              {tasks.length === 0 && <p className="text-sm text-slate-400">No tasks.</p>}
              {tasks.map(t => (
                <div key={t.id} className="flex items-center justify-between p-2 border border-white/10 rounded-xl text-sm">
                  <div>
                    <div className="font-medium">{t.title}</div>
                    <div className="text-xs text-slate-400">{new Date(t.due_at).toLocaleString()} · {t.priority}</div>
                  </div>
                  <Badge color={statusColor(t.status)}>{t.status}</Badge>
                </div>
              ))}
            </CardBody>
          </Card>

          <Card>
            <CardHeader><h3 className="text-sm font-semibold">Activity Timeline</h3></CardHeader>
            <CardBody className="space-y-2 max-h-64 overflow-y-auto">
              {activity.length === 0 && <p className="text-sm text-slate-400">No activity.</p>}
              {activity.map(a => (
                <div key={a.id} className="flex gap-2 text-sm">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-2 shrink-0" />
                  <div>
                    <div>{a.description}</div>
                    <div className="text-xs text-slate-400">{new Date(a.created_at).toLocaleString()}</div>
                  </div>
                </div>
              ))}
            </CardBody>
          </Card>

          <Card>
            <CardHeader><h3 className="text-sm font-semibold">Internal Notes</h3></CardHeader>
            <CardBody>
              <div className="flex gap-2">
                <input value={note} onChange={e => setNote(e.target.value)} placeholder="Add a note..." className="h-9 flex-1 rounded-xl border border-white/10 bg-white/[0.05] px-3 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50" />
                <Button size="sm" onClick={addNote}>Add</Button>
              </div>
            </CardBody>
          </Card>
        </div>
      </div>

      <Modal open={statusModal} onClose={() => setStatusModal(false)} title="Update Status">
        <Select label="Status" value={newStatus} onChange={e => setNewStatus(e.target.value as LeadStatus)}>
          {(['New', 'Contacted', 'Interested', 'Demo Booked', 'Trial', 'Converted', 'Lost'] as LeadStatus[]).map(s => <option key={s} value={s}>{s}</option>)}
        </Select>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setStatusModal(false)}>Cancel</Button>
          <Button onClick={changeStatus}>Save</Button>
        </div>
      </Modal>

      <Modal open={taskModal} onClose={() => setTaskModal(false)} title="Schedule Follow-up">
        <div className="space-y-3">
          <Input label="Title" value={taskForm.title} onChange={e => setTaskForm({ ...taskForm, title: e.target.value })} />
          <Textarea label="Description" value={taskForm.description} onChange={e => setTaskForm({ ...taskForm, description: e.target.value })} />
          <Select label="Priority" value={taskForm.priority} onChange={e => setTaskForm({ ...taskForm, priority: e.target.value as TaskPriority })}>
            {(['Low', 'Medium', 'High', 'Urgent'] as TaskPriority[]).map(p => <option key={p} value={p}>{p}</option>)}
          </Select>
          <Input label="Due" type="datetime-local" value={taskForm.due_at} onChange={e => setTaskForm({ ...taskForm, due_at: e.target.value })} />
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setTaskModal(false)}>Cancel</Button>
          <Button onClick={scheduleFollowUp}>Schedule</Button>
        </div>
      </Modal>

      <Modal open={bookingModal} onClose={() => setBookingModal(false)} title="Book Demo">
        <div className="space-y-3">
          <Input label="Date" type="date" value={bookingForm.booking_date} onChange={e => setBookingForm({ ...bookingForm, booking_date: e.target.value })} />
          <Input label="Time" type="time" value={bookingForm.booking_time} onChange={e => setBookingForm({ ...bookingForm, booking_time: e.target.value })} />
          <Select label="Timezone" value={bookingForm.timezone} onChange={e => setBookingForm({ ...bookingForm, timezone: e.target.value })}>
            <option value="America/New_York">America/New_York</option>
            <option value="America/Chicago">America/Chicago</option>
            <option value="America/Los_Angeles">America/Los_Angeles</option>
            <option value="Europe/London">Europe/London</option>
          </Select>
          <Textarea label="Notes" value={bookingForm.notes} onChange={e => setBookingForm({ ...bookingForm, notes: e.target.value })} />
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setBookingModal(false)}>Cancel</Button>
          <Button onClick={createBooking}>Book</Button>
        </div>
      </Modal>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-3">
      <span className="text-slate-400">{label}</span>
      <span className="font-medium text-right">{value}</span>
    </div>
  );
}
