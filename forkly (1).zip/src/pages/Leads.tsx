// src/pages/Leads.tsx — Nexora-style leads workspace: KPIs, stage tabs, scored table, sources donut, hot leads, activity
import React, { useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Cell, Pie, PieChart, ResponsiveContainer } from 'recharts';
import {
  Plus, Search, Pencil, Archive, ChevronLeft, ChevronRight, ArrowUpDown, RotateCcw, Download,
  Users, Flame, CalendarDays, UserRound, Mail, Upload, UserCheck, Phone, MessageCircle,
} from 'lucide-react';
import { toast } from 'sonner';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/Button';
import { Input, Select, Textarea } from '../components/ui/Input';
import { Modal } from '../components/ui/Modal';
import { Avatar, DONUT, Kpi, PanelTitle, STATUS_CHIP, ScoreBar, darkField, fmtShort, glass, softBtn } from '../components/ui/kit';
import { usePermissions } from '../lib/permissions';
import { followUpTaskFor, loadAutomation, pickAssignee } from '../lib/automation';
import { CSV_TEMPLATE, mapLeadRows, parseCsv, type ImportRow } from '../lib/csv';
import type { Lead, LeadSource, LeadStatus } from '../lib/types';
import {
  QUALIFIED_STATUSES, avgResponseHours, buildScores, formatHours, isHot, relativeDay, shareBy,
} from '../lib/leadInsights';

const PAGE_SIZE = 8;
const SOURCES: LeadSource[] = ['Meta Lead Ads', 'WhatsApp', 'Website', 'Referral', 'Cold Outreach', 'Google Ads', 'Event', 'Partner'];
const STATUSES: LeadStatus[] = ['New', 'Contacted', 'Interested', 'Demo Booked', 'Trial', 'Converted', 'Lost'];
const RANGES = [{ v: 'all', l: 'All time' }, { v: '7', l: 'Last 7 days' }, { v: '30', l: 'Last 30 days' }, { v: '90', l: 'Last 90 days' }];
export default function Leads() {
  const { data, addLead, updateLead, archiveLead, logActivity, addTask, currentUser } = useApp();
  const { can } = usePermissions();
  const [params, setParams] = useSearchParams();
  const [importRows, setImportRows] = useState<ImportRow[] | null>(null);
  const [bulkOwner, setBulkOwner] = useState('');
  const [bulkStatus, setBulkStatus] = useState('');
  const [search, setSearch] = useState('');
  const [sourceFilter, setSourceFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [ownerFilter, setOwnerFilter] = useState('');
  const [range, setRange] = useState('all');
  const [sortKey, setSortKey] = useState<'name' | 'score' | 'created_at'>('created_at');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Lead | null>(null);
  const [form, setForm] = useState<Partial<Lead>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});

  const allLeads = useMemo(() => data.leads.filter(l => !l.archived), [data.leads]);
  const scores = useMemo(() => buildScores(data), [data]);
  const ownerName = (id: string | null) => data.profiles.find(p => p.id === id)?.full_name ?? 'Unassigned';

  // leads inside the chosen date range (drives KPIs, tabs, charts)
  const scope = useMemo(() => {
    if (range === 'all') return allLeads;
    const cutoff = Date.now() - Number(range) * 86400000;
    return allLeads.filter(l => new Date(l.created_at).getTime() >= cutoff);
  }, [allLeads, range]);

  const kpi = useMemo(() => {
    const total = scope.length;
    const qualified = scope.filter(l => QUALIFIED_STATUSES.includes(l.status)).length;
    const converted = scope.filter(l => l.status === 'Converted').length;
    const hot = scope.filter(l => isHot(l, scores)).length;
    const newWeek = allLeads.filter(l => Date.now() - new Date(l.created_at).getTime() < 7 * 86400000).length;
    const resp = formatHours(avgResponseHours(data, new Set(scope.map(l => l.id))));
    return { total, qualified, hot, newWeek, resp, conv: total ? Math.round((converted / total) * 100) : 0, qualPct: total ? Math.round((qualified / total) * 100) : 0 };
  }, [scope, allLeads, scores, data]);

  const stageCounts = useMemo(() => {
    const m: Record<string, number> = { '': scope.length };
    for (const s of STATUSES) m[s] = scope.filter(l => l.status === s).length;
    return m;
  }, [scope]);

  const filtered = useMemo(() => {
    let list = scope;
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(l => l.name.toLowerCase().includes(q) || l.restaurant_name.toLowerCase().includes(q) || l.email.toLowerCase().includes(q) || l.phone.includes(q));
    }
    if (sourceFilter) list = list.filter(l => l.source === sourceFilter);
    if (statusFilter) list = list.filter(l => l.status === statusFilter);
    if (ownerFilter) list = list.filter(l => (ownerFilter === 'none' ? !l.assigned_to : l.assigned_to === ownerFilter));
    const dir = sortDir === 'asc' ? 1 : -1;
    return [...list].sort((a, b) => {
      if (sortKey === 'score') return ((scores.get(a.id) ?? 0) - (scores.get(b.id) ?? 0)) * dir;
      const va = sortKey === 'name' ? a.name.toLowerCase() : a.created_at;
      const vb = sortKey === 'name' ? b.name.toLowerCase() : b.created_at;
      return va < vb ? -dir : va > vb ? dir : 0;
    });
  }, [scope, search, sourceFilter, statusFilter, ownerFilter, sortKey, sortDir, scores]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const curPage = Math.min(page, totalPages);
  const pageData = filtered.slice((curPage - 1) * PAGE_SIZE, curPage * PAGE_SIZE);
  const pageNums = useMemo(() => {
    const start = Math.max(1, Math.min(curPage - 2, totalPages - 4));
    return Array.from({ length: Math.min(5, totalPages) }, (_, i) => start + i);
  }, [curPage, totalPages]);

  // side panels
  const sources = useMemo(() => {
    const rows = shareBy(scope, l => l.source);
    const top = rows.slice(0, 4);
    const rest = rows.slice(4).reduce((a, r) => a + r.value, 0);
    if (rest) top.push({ label: 'Other', value: rest, pct: Math.round((rest / (scope.length || 1)) * 100) });
    return top;
  }, [scope]);
  const hotLeads = useMemo(() => scope.filter(l => isHot(l, scores)).sort((a, b) => (scores.get(b.id) ?? 0) - (scores.get(a.id) ?? 0)).slice(0, 6), [scope, scores]);
  const owners = useMemo(() => shareBy(scope, l => ownerName(l.assigned_to)).slice(0, 3), [scope, data.profiles]); // eslint-disable-line react-hooks/exhaustive-deps
  const activity = useMemo(() => [...data.activity_logs].sort((a, b) => b.created_at.localeCompare(a.created_at)).slice(0, 4), [data.activity_logs]);

  const setFilter = (fn: () => void) => { fn(); setPage(1); setSelected(new Set()); };
  const resetFilters = () => { setSearch(''); setSourceFilter(''); setStatusFilter(''); setOwnerFilter(''); setRange('all'); setPage(1); setSelected(new Set()); };

  const openCreate = () => {
    setEditing(null);
    setForm({ name: '', restaurant_name: '', phone: '', email: '', source: 'Website', status: 'New', assigned_to: currentUser.id, notes: '', last_contact_at: null, next_follow_up_at: null, archived: false });
    setErrors({});
    setModalOpen(true);
  };
  React.useEffect(() => {
    if (params.get('new') === '1' && can('lead.write')) { openCreate(); }
    if (params.get('import') === '1' && can('lead.import')) { setImportRows([]); }
    if (params.has('new') || params.has('import')) setParams({}, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params]);

  const openEdit = (l: Lead) => { setEditing(l); setForm({ ...l }); setErrors({}); setModalOpen(true); };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name?.trim()) e.name = 'Name required';
    if (!form.restaurant_name?.trim()) e.restaurant_name = 'Restaurant required';
    if (!form.phone?.trim()) e.phone = 'Phone required';
    else if (!/^\+?[\d\s().-]{7,}$/.test(form.phone)) e.phone = 'Invalid phone';
    if (form.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) e.email = 'Invalid email';
    const dup = allLeads.find(l => l.id !== editing?.id && (l.phone === form.phone || (form.email && l.email === form.email)));
    if (dup) e.phone = `Duplicate lead: ${dup.name}`;
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const save = () => {
    if (!validate()) return;
    if (editing) {
      updateLead(editing.id, form as Partial<Lead>);
      logActivity({ lead_id: editing.id, actor_id: currentUser.id, event_type: 'Lead Updated', description: `Lead ${form.name} updated`, metadata: null });
      toast.success('Lead updated');
    } else {
      const auto = loadAutomation();
      const payload = { ...form } as Omit<Lead, 'id' | 'created_at' | 'updated_at'>;
      if (auto.autoAssign && !payload.assigned_to) payload.assigned_to = pickAssignee(data);
      const newLead = addLead(payload);
      logActivity({ lead_id: newLead.id, actor_id: currentUser.id, event_type: 'Lead Created', description: `Lead ${newLead.name} created`, metadata: { source: newLead.source } });
      if (auto.autoFollowUp) addTask(followUpTaskFor(newLead, auto.followUpHours, currentUser.id));
      toast.success(auto.autoAssign && newLead.assigned_to ? `Lead created and assigned to ${ownerName(newLead.assigned_to)}` : 'Lead created');
    }
    setModalOpen(false);
  };

  const archiveOne = (l: Lead) => {
    if (!confirm('Archive lead?')) return;
    archiveLead(l.id);
    logActivity({ lead_id: l.id, actor_id: currentUser.id, event_type: 'Lead Updated', description: `${l.name} archived`, metadata: null });
    toast.success('Archived');
  };
  const archiveSelected = () => {
    if (!selected.size || !confirm(`Archive ${selected.size} selected lead${selected.size === 1 ? '' : 's'}?`)) return;
    for (const id of selected) {
      const l = allLeads.find(x => x.id === id);
      if (!l) continue;
      archiveLead(id);
      logActivity({ lead_id: id, actor_id: currentUser.id, event_type: 'Lead Updated', description: `${l.name} archived`, metadata: null });
    }
    toast.success('Archived');
    setSelected(new Set());
  };

  const onFile = async (f?: File) => {
    if (!f) return;
    const rows = mapLeadRows(parseCsv(await f.text()), data.leads);
    if (!rows.length) { toast.error('No data rows found. Check the header row.'); return; }
    setImportRows(rows);
  };
  const importable = (importRows ?? []).filter(r => !r.error && !r.duplicate);
  const runImport = () => {
    const auto = loadAutomation();
    const load: Record<string, number> = {};
    for (const r of importable) {
      const assigned = auto.autoAssign ? pickAssignee(data, load) : currentUser.id;
      if (assigned) load[assigned] = (load[assigned] ?? 0) + 1;
      const lead = addLead({ ...r.lead, assigned_to: assigned, last_contact_at: null, next_follow_up_at: null, archived: false });
      logActivity({ lead_id: lead.id, actor_id: currentUser.id, event_type: 'Lead Created', description: `Lead ${lead.name} imported`, metadata: { source: lead.source, import: true } });
      if (auto.autoFollowUp) addTask(followUpTaskFor(lead, auto.followUpHours, currentUser.id));
    }
    toast.success(`Imported ${importable.length} lead${importable.length === 1 ? '' : 's'}`);
    setImportRows(null);
  };
  const downloadTemplate = () => {
    const url = URL.createObjectURL(new Blob([CSV_TEMPLATE], { type: 'text/csv' }));
    const a = document.createElement('a'); a.href = url; a.download = 'leads-template.csv'; a.click(); URL.revokeObjectURL(url);
  };

  const applyBulk = () => {
    if (!selected.size || (!bulkOwner && !bulkStatus)) return;
    for (const id of selected) {
      const l = allLeads.find(x => x.id === id);
      if (!l) continue;
      const patch: Partial<Lead> = {};
      if (bulkOwner) patch.assigned_to = bulkOwner === 'none' ? null : bulkOwner;
      if (bulkStatus) patch.status = bulkStatus as LeadStatus;
      updateLead(id, patch);
      if (bulkOwner) logActivity({ lead_id: id, actor_id: currentUser.id, event_type: 'Assignment Changed', description: `${l.name} assigned to ${ownerName(patch.assigned_to ?? null)}`, metadata: null });
      if (bulkStatus) logActivity({ lead_id: id, actor_id: currentUser.id, event_type: 'Status Changed', description: `${l.name} → ${bulkStatus}`, metadata: null });
    }
    toast.success(`Updated ${selected.size} lead${selected.size === 1 ? '' : 's'}`);
    setSelected(new Set()); setBulkOwner(''); setBulkStatus('');
  };

  const exportCsv = () => {
    const q = (v: string) => `"${v.replace(/"/g, '""')}"`;
    const rows = [['Name', 'Restaurant', 'Phone', 'Email', 'Source', 'Status', 'Score', 'Owner', 'Next follow-up', 'Created'],
      ...filtered.map(l => [l.name, l.restaurant_name, l.phone, l.email, l.source, l.status, String(scores.get(l.id) ?? 0), ownerName(l.assigned_to), l.next_follow_up_at ?? '', l.created_at])];
    const url = URL.createObjectURL(new Blob([rows.map(r => r.map(q).join(',')).join('\n')], { type: 'text/csv;charset=utf-8' }));
    const a = document.createElement('a');
    a.href = url; a.download = 'leads.csv'; a.click();
    URL.revokeObjectURL(url);
  };

  const toggleSort = (key: typeof sortKey) => {
    if (sortKey === key) setSortDir(d => (d === 'asc' ? 'desc' : 'asc'));
    else { setSortKey(key); setSortDir(key === 'name' ? 'asc' : 'desc'); }
  };

  const pageAllSelected = pageData.length > 0 && pageData.every(l => selected.has(l.id));
  const togglePage = () => setSelected(s => {
    const n = new Set(s);
    if (pageAllSelected) pageData.forEach(l => n.delete(l.id)); else pageData.forEach(l => n.add(l.id));
    return n;
  });

  const topSource = sources[0];

  return (
    <div className="text-slate-100">
      {/* header */}
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-white">Leads</h1>
          <p className="text-xs text-slate-400">Track and manage your leads to drive more conversions</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <label className="flex items-center gap-2"><UserRound size={14} className="text-slate-400" />
            <select className={darkField} value={ownerFilter} onChange={e => setFilter(() => setOwnerFilter(e.target.value))}>
              <option value="">Owner: All reps</option>
              {data.profiles.map(p => <option key={p.id} value={p.id}>{p.full_name}</option>)}
              <option value="none">Unassigned</option>
            </select>
          </label>
          <label className="flex items-center gap-2"><CalendarDays size={14} className="text-slate-400" />
            <select className={darkField} value={range} onChange={e => setFilter(() => setRange(e.target.value))}>
              {RANGES.map(r => <option key={r.v} value={r.v}>Date: {r.l}</option>)}
            </select>
          </label>
          {can('lead.import') && <button onClick={() => setImportRows([])} className={softBtn}><Upload size={13} /> Import CSV</button>}
          {can('lead.write') && <button onClick={openCreate} className="inline-flex h-9 items-center gap-1.5 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-500 px-4 text-xs font-semibold text-white shadow-lg shadow-blue-500/30 hover:brightness-110"><Plus size={14} /> Add Lead</button>}
        </div>
      </div>

      {/* KPIs */}
      <div className="mb-5 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        <Kpi value={kpi.total.toLocaleString()} label="Total Leads" sub={range === 'all' ? 'All time' : RANGES.find(r => r.v === range)!.l} />
        <Kpi value={`+${kpi.newWeek}`} label="New Leads" sub="Last 7 days" accent="text-emerald-400" />
        <Kpi value={kpi.qualified.toLocaleString()} label="Qualified Leads" sub={`${kpi.qualPct}% of total`} />
        <Kpi value={`${kpi.conv}%`} label="Conversion Rate" sub="lead → deal" accent="text-emerald-400" />
        <Kpi value={kpi.resp.value} label={kpi.resp.unit ? `${kpi.resp.unit} avg response` : 'Avg Response Time'} sub="first reply to inbound" />
        <Kpi value={String(kpi.hot)} label="Hot Leads" sub={`score ${80}+, still open`} accent="text-orange-300" />
      </div>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_340px]">
        {/* LEFT */}
        <div className="min-w-0 space-y-5">
          {/* stage tabs */}
          <div className="flex flex-wrap gap-2">
            {[{ v: '', l: 'All' }, ...STATUSES.map(s => ({ v: s as string, l: s }))].map(t => (
              <button key={t.v || 'all'} onClick={() => setFilter(() => setStatusFilter(t.v))}
                className={`rounded-full border px-4 py-2 text-xs font-medium transition-colors ${statusFilter === t.v ? 'border-blue-400/60 bg-blue-500/20 text-white' : 'border-white/10 bg-white/[0.03] text-slate-300 hover:bg-white/[0.07]'}`}>
                {t.l} <span className="text-slate-400">({stageCounts[t.v] ?? 0})</span>
              </button>
            ))}
          </div>

          {/* table */}
          <div className={`${glass} p-4`}>
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-lg font-semibold text-white">{statusFilter || 'All'} Leads</h2>
              <div className="flex items-center gap-2">
                {selected.size > 0 && can('lead.archive') && <button onClick={archiveSelected} className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-rose-400/40 bg-rose-500/10 px-3 text-xs text-rose-300 hover:bg-rose-500/20"><Archive size={13} /> Archive {selected.size}</button>}
                <button onClick={exportCsv} disabled={!filtered.length} className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.05] px-3 text-xs text-slate-200 hover:bg-white/10 disabled:opacity-40"><Download size={13} /> Export</button>
                {can('lead.write') && <button onClick={openCreate} className="inline-flex h-9 items-center gap-1.5 rounded-xl bg-blue-500/90 px-3 text-xs font-semibold text-white hover:bg-blue-500"><Plus size={13} /> Add Lead</button>}
              </div>
            </div>

            <div className="mb-3 flex flex-wrap items-center gap-2 rounded-xl border border-white/10 bg-black/20 p-2">
              <div className="relative min-w-[180px] flex-1">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input value={search} onChange={e => setFilter(() => setSearch(e.target.value))} placeholder="Search leads…" className={`${darkField} w-full pl-9 placeholder:text-slate-500`} />
              </div>
              <select className={darkField} value={statusFilter} onChange={e => setFilter(() => setStatusFilter(e.target.value))}>
                <option value="">Status: All</option>{STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
              <select className={darkField} value={sourceFilter} onChange={e => setFilter(() => setSourceFilter(e.target.value))}>
                <option value="">Source: All</option>{SOURCES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
              <select className={darkField} value={ownerFilter} onChange={e => setFilter(() => setOwnerFilter(e.target.value))}>
                <option value="">Owner: All reps</option>{data.profiles.map(p => <option key={p.id} value={p.id}>{p.full_name}</option>)}<option value="none">Unassigned</option>
              </select>
              <button onClick={resetFilters} title="Reset filters" className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/[0.05] text-slate-300 hover:bg-white/10"><RotateCcw size={14} /></button>
            </div>

            {selected.size > 0 && can('lead.bulk') && (
              <div className="mb-3 flex flex-wrap items-center gap-2 rounded-xl border border-blue-400/30 bg-blue-500/10 p-2 text-xs text-slate-200">
                <UserCheck size={14} className="text-blue-300" /><span className="font-medium">{selected.size} selected</span>
                <select className={darkField} value={bulkOwner} onChange={e => setBulkOwner(e.target.value)}><option value="">Assign to…</option>{data.profiles.map(p => <option key={p.id} value={p.id}>{p.full_name}</option>)}<option value="none">Unassigned</option></select>
                <select className={darkField} value={bulkStatus} onChange={e => setBulkStatus(e.target.value)}><option value="">Move to stage…</option>{STATUSES.map(st => <option key={st} value={st}>{st}</option>)}</select>
                <button onClick={applyBulk} disabled={!bulkOwner && !bulkStatus} className="inline-flex h-9 items-center rounded-xl bg-blue-500 px-3 font-semibold text-white disabled:opacity-40">Apply</button>
                <button onClick={() => setSelected(new Set())} className="ml-auto text-slate-400 hover:text-white">Clear</button>
              </div>
            )}

            <div className="overflow-x-auto rounded-xl border border-white/10">
              <table className="w-full min-w-[720px] text-sm">
                <thead className="bg-white/[0.04] text-[11px] text-slate-400">
                  <tr>
                    <th className="w-10 px-3 py-3"><input type="checkbox" aria-label="Select page" checked={pageAllSelected} onChange={togglePage} className="accent-blue-500" /></th>
                    <th className="whitespace-nowrap px-3 py-3 text-left font-medium"><button onClick={() => toggleSort('name')} className="inline-flex items-center gap-1">Lead <ArrowUpDown size={11} /></button></th>
                    <th className="whitespace-nowrap px-3 py-3 text-left font-medium">Company</th>
                    <th className="whitespace-nowrap px-3 py-3 text-left font-medium"><button onClick={() => toggleSort('score')} className="inline-flex items-center gap-1">Score <ArrowUpDown size={11} /></button></th>
                    <th className="whitespace-nowrap px-3 py-3 text-left font-medium">Source</th>
                    <th className="whitespace-nowrap px-3 py-3 text-left font-medium">Status</th>
                    <th className="whitespace-nowrap px-3 py-3 text-left font-medium">Owner</th>
                    <th className="hidden whitespace-nowrap px-3 py-3 text-left font-medium 2xl:table-cell"><button onClick={() => toggleSort('created_at')} className="inline-flex items-center gap-1">Created <ArrowUpDown size={11} /></button></th>
                    <th className="whitespace-nowrap px-3 py-3 text-left font-medium">Next follow-up</th>
                    <th className="whitespace-nowrap px-3 py-3" />
                  </tr>
                </thead>
                <tbody>
                  {pageData.map(l => (
                    <tr key={l.id} className="border-t border-white/10 hover:bg-white/[0.04]">
                      <td className="whitespace-nowrap px-3 py-3"><input type="checkbox" aria-label={`Select ${l.name}`} checked={selected.has(l.id)} onChange={() => setSelected(s => { const n = new Set(s); if (n.has(l.id)) n.delete(l.id); else n.add(l.id); return n; })} className="accent-blue-500" /></td>
                      <td className="whitespace-nowrap px-3 py-3">
                        <Link to={`/leads/${l.id}`} className="flex items-center gap-2.5 font-medium text-white hover:text-blue-300"><Avatar name={l.name} />{l.name}</Link>
                      </td>
                      <td className="whitespace-nowrap px-3 py-3 text-slate-300">{l.restaurant_name}</td>
                      <td className="whitespace-nowrap px-3 py-3"><ScoreBar score={scores.get(l.id) ?? 0} /></td>
                      <td className="whitespace-nowrap px-3 py-3 text-xs text-slate-300">{l.source}</td>
                      <td className="whitespace-nowrap px-3 py-3"><span className={`inline-flex rounded-full border px-2.5 py-0.5 text-[11px] font-medium ${STATUS_CHIP[l.status]}`}>{l.status}</span></td>
                      <td className="whitespace-nowrap px-3 py-3 text-xs text-slate-300">{ownerName(l.assigned_to)}</td>
                      <td className="hidden whitespace-nowrap px-3 py-3 text-xs text-slate-400 2xl:table-cell">{fmtShort(l.created_at)}</td>
                      <td className="whitespace-nowrap px-3 py-3 text-xs text-slate-400">{fmtShort(l.next_follow_up_at)}</td>
                      <td className="whitespace-nowrap px-3 py-3">
                        <div className="flex items-center gap-1">
                          <a href={`tel:${l.phone}`} title="Call" className="rounded-lg p-1.5 text-slate-400 hover:bg-white/10 hover:text-emerald-300"><Phone size={14} /></a>
                          <Link to={`/whatsapp?lead=${l.id}`} title="WhatsApp" className="rounded-lg p-1.5 text-slate-400 hover:bg-white/10 hover:text-emerald-300"><MessageCircle size={14} /></Link>
                          {can('lead.write') && <button onClick={() => openEdit(l)} title="Edit" className="rounded-lg p-1.5 text-slate-400 hover:bg-white/10 hover:text-white"><Pencil size={14} /></button>}
                          {can('lead.archive') && <button onClick={() => archiveOne(l)} title="Archive" className="rounded-lg p-1.5 text-slate-400 hover:bg-white/10 hover:text-rose-300"><Archive size={14} /></button>}
                        </div>
                      </td>
                    </tr>
                  ))}
                  {pageData.length === 0 && (
                    <tr><td colSpan={9} className="px-4 py-10 text-center text-sm text-slate-400">{allLeads.length === 0 ? 'No leads yet. Add your first lead to start tracking.' : 'No leads match these filters.'}</td></tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
              <span>{filtered.length ? `Showing ${(curPage - 1) * PAGE_SIZE + 1} to ${Math.min(curPage * PAGE_SIZE, filtered.length)} of ${filtered.length} entries` : 'Showing 0 entries'}</span>
              <div className="flex items-center gap-1.5">
                <button onClick={() => setPage(Math.max(1, curPage - 1))} disabled={curPage === 1} aria-label="Previous page" className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 bg-white/[0.05] disabled:opacity-40"><ChevronLeft size={14} /></button>
                {pageNums.map(n => <button key={n} onClick={() => setPage(n)} className={`h-8 w-8 rounded-lg border text-xs ${n === curPage ? 'border-blue-400 bg-blue-500 text-white' : 'border-white/10 bg-white/[0.05] text-slate-300 hover:bg-white/10'}`}>{n}</button>)}
                <button onClick={() => setPage(Math.min(totalPages, curPage + 1))} disabled={curPage === totalPages} aria-label="Next page" className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 bg-white/[0.05] disabled:opacity-40"><ChevronRight size={14} /></button>
              </div>
            </div>
          </div>

          {/* bottom row */}
          <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
            <div className={`${glass} p-4`}>
              <PanelTitle icon={<CalendarDays size={15} />} title="Lead Activity" to="/activity" />
              {activity.length === 0 ? <p className="py-6 text-center text-xs text-slate-500">No activity yet.</p> : (
                <ol className="relative space-y-4 pl-6 before:absolute before:left-[7px] before:top-1 before:h-[calc(100%-8px)] before:w-px before:bg-white/15">
                  {activity.map(a => (
                    <li key={a.id} className="relative">
                      <span className="absolute -left-6 top-0.5 h-3.5 w-3.5 rounded-full border-2 border-blue-400 bg-[#0a0f2c]" />
                      <div className="text-sm font-medium text-white">{relativeDay(a.created_at)} <span className="text-xs font-normal text-slate-400">{new Date(a.created_at).toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' })}</span></div>
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-400"><Mail size={11} />{a.description}{a.actor_id ? ` · ${ownerName(a.actor_id)}` : ''}</div>
                    </li>
                  ))}
                </ol>
              )}
            </div>
            <div className={`${glass} p-4`}>
              <PanelTitle icon={<Users size={15} />} title="Leads by Salesperson" to="/pipeline" linkLabel="Pipeline" />
              {owners.length === 0 ? <p className="py-6 text-center text-xs text-slate-500">No leads to show.</p> : (
                <div className="space-y-4">
                  {owners.map(o => (
                    <div key={o.label}>
                      <div className="mb-1 flex items-center justify-between text-xs"><span className="flex items-center gap-2 text-slate-200"><Avatar name={o.label} size={24} />{o.label}</span><span className="text-slate-300">{o.value} · {o.pct}%</span></div>
                      <div className="h-1.5 rounded-full bg-white/10"><div className="h-full rounded-full bg-gradient-to-r from-sky-400 to-blue-500" style={{ width: `${o.pct}%` }} /></div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* RIGHT */}
        <div className="space-y-5">
          <div className={`${glass} p-4`}>
            <PanelTitle icon={<Users size={15} />} title="Lead Sources" />
            <div className="flex items-center gap-3">
              <div className="relative h-[170px] w-[170px] shrink-0">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={sources.length ? sources : [{ label: 'none', value: 1, pct: 0 }]} dataKey="value" nameKey="label" innerRadius={55} outerRadius={78} paddingAngle={sources.length > 1 ? 3 : 0} stroke="none" startAngle={90} endAngle={-270}>
                      {(sources.length ? sources : [{ label: 'none' }]).map((_, i) => <Cell key={i} fill={sources.length ? DONUT[i % DONUT.length] : 'rgba(255,255,255,0.1)'} />)}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-semibold text-white">{topSource ? `${topSource.pct}%` : '—'}</span>
                  <span className="max-w-[80px] truncate text-[10px] text-slate-400">{topSource ? topSource.label : 'No data'}</span>
                </div>
              </div>
              <ul className="min-w-0 flex-1 space-y-2 text-xs">
                {sources.map((s, i) => (
                  <li key={s.label} className="flex items-center justify-between gap-2"><span className="flex min-w-0 items-center gap-2 text-slate-300"><span className="h-2 w-2 shrink-0 rounded-full" style={{ background: DONUT[i % DONUT.length] }} /><span className="truncate">{s.label}</span></span><span className="font-semibold text-slate-100">{s.pct}%</span></li>
                ))}
              </ul>
            </div>
          </div>

          <div className={`${glass} p-4`}>
            <PanelTitle icon={<Flame size={15} />} title="Hot Leads" to="/pipeline" />
            {hotLeads.length === 0 ? <p className="py-6 text-center text-xs text-slate-500">No hot leads yet. Leads scoring 80+ show up here.</p> : (
              <ul className="space-y-3.5">
                {hotLeads.map(l => (
                  <li key={l.id}>
                    <Link to={`/leads/${l.id}`} className="block rounded-lg hover:bg-white/[0.04]">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0"><div className="truncate text-sm font-semibold text-white">{l.restaurant_name}</div><div className="truncate text-[10px] text-slate-400">Owner: {ownerName(l.assigned_to)}</div></div>
                        <div className="w-24 shrink-0"><ScoreBar score={scores.get(l.id) ?? 0} wide /></div>
                        <div className="w-14 shrink-0 text-right text-[10px] text-slate-400">{l.next_follow_up_at ? <>Due<br />{fmtShort(l.next_follow_up_at)}</> : 'No follow-up'}</div>
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>

      <Modal open={importRows !== null} onClose={() => setImportRows(null)} title="Import leads from CSV" width="max-w-3xl">
        {importRows && importRows.length === 0 ? (
          <div className="space-y-4 text-sm text-slate-300">
            <p>Upload a CSV with a header row. Recognised columns: <span className="text-white">name, restaurant, phone, email, source, status, notes</span>. Duplicates (same phone or email) are skipped.</p>
            <label className="flex cursor-pointer flex-col items-center gap-2 rounded-2xl border border-dashed border-white/20 bg-white/[0.03] p-8 text-center hover:bg-white/[0.06]">
              <Upload size={22} className="text-blue-300" /><span className="text-xs">Click to choose a .csv file</span>
              <input type="file" accept=".csv,text/csv" className="hidden" onChange={e => onFile(e.target.files?.[0])} />
            </label>
            <button onClick={downloadTemplate} className="text-xs text-blue-300 hover:underline">Download template</button>
          </div>
        ) : importRows && (
          <div>
            <div className="mb-3 flex flex-wrap gap-3 text-xs">
              <span className="rounded-full border border-emerald-400/30 bg-emerald-500/10 px-3 py-1 text-emerald-300">{importable.length} ready</span>
              <span className="rounded-full border border-amber-400/30 bg-amber-500/10 px-3 py-1 text-amber-300">{importRows.filter(r => r.duplicate).length} duplicates</span>
              <span className="rounded-full border border-rose-400/30 bg-rose-500/10 px-3 py-1 text-rose-300">{importRows.filter(r => r.error).length} invalid</span>
            </div>
            <div className="max-h-72 overflow-auto rounded-xl border border-white/10">
              <table className="w-full text-xs">
                <thead className="bg-white/[0.04] text-slate-400"><tr><th className="px-3 py-2 text-left">Line</th><th className="px-3 py-2 text-left">Name</th><th className="px-3 py-2 text-left">Restaurant</th><th className="px-3 py-2 text-left">Phone</th><th className="px-3 py-2 text-left">Result</th></tr></thead>
                <tbody>{importRows.map(r => (
                  <tr key={r.line} className="border-t border-white/10"><td className="px-3 py-2 text-slate-500">{r.line}</td><td className="px-3 py-2 text-white">{r.lead.name}</td><td className="px-3 py-2">{r.lead.restaurant_name}</td><td className="px-3 py-2">{r.lead.phone}</td>
                    <td className={`px-3 py-2 ${r.error ? 'text-rose-300' : r.duplicate ? 'text-amber-300' : 'text-emerald-300'}`}>{r.error ?? (r.duplicate ? 'Duplicate, skipped' : 'OK')}</td></tr>
                ))}</tbody>
              </table>
            </div>
            <div className="mt-5 flex justify-end gap-2">
              <Button variant="secondary" onClick={() => setImportRows([])}>Choose another file</Button>
              <Button onClick={runImport} disabled={!importable.length}>Import {importable.length}</Button>
            </div>
          </div>
        )}
      </Modal>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Lead' : 'Add Lead'} width="max-w-2xl">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <Input label="Name" value={form.name || ''} onChange={e => setForm({ ...form, name: e.target.value })} error={errors.name} />
          <Input label="Restaurant" value={form.restaurant_name || ''} onChange={e => setForm({ ...form, restaurant_name: e.target.value })} error={errors.restaurant_name} />
          <Input label="Phone" value={form.phone || ''} onChange={e => setForm({ ...form, phone: e.target.value })} error={errors.phone} />
          <Input label="Email" value={form.email || ''} onChange={e => setForm({ ...form, email: e.target.value })} error={errors.email} />
          <Select label="Source" value={form.source || 'Website'} onChange={e => setForm({ ...form, source: e.target.value as LeadSource })}>
            {SOURCES.map(s => <option key={s} value={s}>{s}</option>)}
          </Select>
          <Select label="Status" value={form.status || 'New'} onChange={e => setForm({ ...form, status: e.target.value as LeadStatus })}>
            {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
          </Select>
          <Select label="Salesperson" value={form.assigned_to || ''} onChange={e => setForm({ ...form, assigned_to: e.target.value || null })}>
            <option value="">Unassigned</option>
            {data.profiles.map(p => <option key={p.id} value={p.id}>{p.full_name}</option>)}
          </Select>
          <Input label="Next Follow-up" type="datetime-local" value={form.next_follow_up_at ? form.next_follow_up_at.slice(0, 16) : ''} onChange={e => setForm({ ...form, next_follow_up_at: e.target.value ? new Date(e.target.value).toISOString() : null })} />
          <div className="md:col-span-2"><Textarea label="Notes" value={form.notes || ''} onChange={e => setForm({ ...form, notes: e.target.value })} /></div>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setModalOpen(false)}>Cancel</Button>
          <Button onClick={save}>{editing ? 'Save' : 'Create'}</Button>
        </div>
      </Modal>
    </div>
  );
}
