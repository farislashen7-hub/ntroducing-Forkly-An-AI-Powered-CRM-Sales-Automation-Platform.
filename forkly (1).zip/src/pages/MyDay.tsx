// src/pages/MyDay.tsx — task management for one salesperson: follow-ups today, overdue, upcoming appointments, completed.
// Managers can switch to any team member or the whole team.
import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { toast } from 'sonner';
import { AlertTriangle, Calendar, CheckCircle2, Clock, ListChecks, MessageCircle, Phone, Plus, Timer } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Avatar, Empty, Kpi, KpiGrid, PageHeader, Panel, PillTabs, darkField, gradientBtn } from '../components/ui/kit';
import { Badge, statusColor } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Input, Select, Textarea } from '../components/ui/Input';
import { Modal } from '../components/ui/Modal';
import { usePermissions } from '../lib/permissions';
import { buildWorkday, type WorkItem } from '../lib/workload';
import { telLink } from '../lib/utils';
import type { TaskPriority } from '../lib/types';

type Tab = 'today' | 'overdue' | 'appointments' | 'completed';
const DAY = 86400000;
const fmtDue = (iso: string) => new Date(iso).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
const daysLate = (iso: string) => Math.max(1, Math.ceil((Date.now() - new Date(iso).getTime()) / DAY));

export default function MyDay() {
  const { data, currentUser, updateTask, updateLead, addTask, logActivity } = useApp();
  const { can } = usePermissions();
  const isManager = can('lead.bulk');
  const [who, setWho] = useState<string>('me');            // 'me' | 'all' | profile id
  const [tab, setTab] = useState<Tab>('today');
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ lead_id: '', title: '', description: '', priority: 'Medium' as TaskPriority, due_at: '' });

  const userId = !isManager || who === 'me' ? currentUser.id : who === 'all' ? null : who;
  const wd = useMemo(() => buildWorkday(data, userId), [data, userId]);
  const viewing = userId === null ? 'the whole team' : userId === currentUser.id ? 'you' : data.profiles.find(p => p.id === userId)?.full_name ?? '';

  const complete = (i: WorkItem) => {
    if (i.kind === 'task') updateTask(i.id, { status: 'Completed' });
    else updateLead(i.id, { next_follow_up_at: null, last_contact_at: new Date().toISOString() });
    logActivity({ lead_id: i.lead.id, actor_id: currentUser.id, event_type: 'Follow-up Completed', description: `Follow-up done: ${i.title}`, metadata: null });
    toast.success('Done');
  };
  const snooze = (i: WorkItem, days: number) => {
    const base = Math.max(Date.now(), new Date(i.due).getTime());
    const next = new Date(base + days * DAY).toISOString();
    if (i.kind === 'task') updateTask(i.id, { due_at: next });
    else updateLead(i.id, { next_follow_up_at: next });
    toast.success(days === 1 ? 'Moved to tomorrow' : `Moved ${days} days`);
  };
  const saveTask = () => {
    if (!form.lead_id || !form.title.trim() || !form.due_at) { toast.error('Lead, title and due date are required'); return; }
    const lead = data.leads.find(l => l.id === form.lead_id);
    addTask({ lead_id: form.lead_id, title: form.title.trim(), description: form.description, priority: form.priority, due_at: new Date(form.due_at).toISOString(), status: 'Pending', assigned_to: userId ?? lead?.assigned_to ?? currentUser.id });
    logActivity({ lead_id: form.lead_id, actor_id: currentUser.id, event_type: 'Follow-up Created', description: `Follow-up: ${form.title.trim()}`, metadata: null });
    setModal(false); setForm({ lead_id: '', title: '', description: '', priority: 'Medium', due_at: '' });
    toast.success('Task created');
  };

  const row = (i: WorkItem, late: boolean) => (
    <div key={i.key} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-3 text-sm hover:bg-white/[0.05]">
      <div className="flex min-w-0 flex-1 items-center gap-3">
        <Avatar name={i.lead.name} size={34} />
        <div className="min-w-0">
          <div className="truncate font-medium text-white">{i.title}</div>
          <div className="truncate text-[11px] text-slate-400"><Link to={`/leads/${i.lead.id}`} className="text-blue-300 hover:underline">{i.lead.name}</Link> · {i.lead.restaurant_name}{i.detail && i.kind === 'task' ? ` · ${i.detail}` : ''}</div>
          <div className={`text-[11px] ${late ? 'text-rose-300' : 'text-slate-500'}`}>{late ? `${daysLate(i.due)} day${daysLate(i.due) === 1 ? '' : 's'} late · ` : ''}Due {fmtDue(i.due)}</div>
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-1.5">
        <Badge color={statusColor(i.priority)}>{i.priority}</Badge>
        {i.lead.phone && <a href={telLink(i.lead.phone)} title="Call"><Button size="sm" variant="ghost"><Phone size={13} /></Button></a>}
        <Link to={`/whatsapp?lead=${i.lead.id}`} title="WhatsApp"><Button size="sm" variant="ghost"><MessageCircle size={13} /></Button></Link>
        <Button size="sm" variant="ghost" title="Tomorrow" onClick={() => snooze(i, 1)}><Timer size={13} /> +1d</Button>
        <Button size="sm" variant="secondary" onClick={() => complete(i)}><CheckCircle2 size={13} /> Done</Button>
      </div>
    </div>
  );

  return (
    <div className="text-slate-100">
      <PageHeader title="My Tasks" subtitle={`Follow-ups and appointments for ${viewing}`}>
        {isManager && (
          <select className={darkField} value={who} onChange={e => setWho(e.target.value)} aria-label="Team member">
            <option value="me">My tasks</option>
            <option value="all">Whole team</option>
            {data.profiles.filter(p => p.id !== currentUser.id && p.role !== 'Viewer').map(p => <option key={p.id} value={p.id}>{p.full_name}</option>)}
          </select>
        )}
        {can('lead.write') && <button className={gradientBtn} onClick={() => setModal(true)}><Plus size={14} /> New Task</button>}
      </PageHeader>

      <KpiGrid cols={4}>
        <Kpi icon={<Clock size={14} />} value={wd.today.length} label="Follow up today" sub="Customers to contact" accent={wd.today.length ? 'text-amber-300' : undefined} />
        <Kpi icon={<AlertTriangle size={14} />} value={wd.overdue.length} label="Overdue" sub="Late customers" accent={wd.overdue.length ? 'text-rose-300' : undefined} />
        <Kpi icon={<Calendar size={14} />} value={wd.appointments.length} label="Upcoming appointments" sub="Next 14 days" accent="text-sky-300" />
        <Kpi icon={<ListChecks size={14} />} value={wd.completed.length} label="Completed" sub={`${wd.completedToday} today`} accent="text-emerald-400" />
      </KpiGrid>

      <PillTabs value={tab} onChange={setTab} tabs={[
        { v: 'today', l: 'Today', n: wd.today.length }, { v: 'overdue', l: 'Overdue', n: wd.overdue.length },
        { v: 'appointments', l: 'Appointments', n: wd.appointments.length }, { v: 'completed', l: 'Completed', n: wd.completed.length },
      ]} />

      {tab === 'today' && <Panel title="Customers to follow up today" icon={<Clock size={15} />}>{wd.today.length === 0 ? <Empty>Nothing due today. 🎉</Empty> : <div className="space-y-2">{wd.today.map(i => row(i, false))}</div>}</Panel>}
      {tab === 'overdue' && <Panel title="Overdue follow-ups" icon={<AlertTriangle size={15} />}>{wd.overdue.length === 0 ? <Empty>No overdue customers.</Empty> : <div className="space-y-2">{wd.overdue.map(i => row(i, true))}</div>}</Panel>}

      {tab === 'appointments' && (
        <Panel title="Upcoming appointments" icon={<Calendar size={15} />} to="/bookings" linkLabel="All bookings">
          {wd.appointments.length === 0 ? <Empty>No appointments in the next 14 days.</Empty> : (
            <div className="space-y-2">
              {wd.appointments.map(({ booking: b, lead }) => {
                const isToday = b.booking_date === new Date().toISOString().slice(0, 10);
                return (
                  <div key={b.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-3 text-sm">
                    <div className="flex min-w-0 items-center gap-3">
                      <Avatar name={lead.name} size={34} />
                      <div className="min-w-0">
                        <div className="truncate font-medium text-white"><Link to={`/leads/${lead.id}`} className="hover:underline">{lead.name}</Link> <span className="text-xs font-normal text-slate-400">· {lead.restaurant_name}</span></div>
                        <div className="text-[11px] text-slate-400">{b.booking_date} at {b.booking_time} ({b.timezone}){b.notes ? ` · ${b.notes}` : ''}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">{isToday && <Badge color="amber">Today</Badge>}<Badge color={statusColor(b.status)}>{b.status}</Badge></div>
                  </div>
                );
              })}
            </div>
          )}
        </Panel>
      )}

      {tab === 'completed' && (
        <Panel title="Completed tasks" icon={<ListChecks size={15} />}>
          {wd.completed.length === 0 ? <Empty>No completed tasks yet.</Empty> : (
            <div className="space-y-2">
              {wd.completed.map(({ task, lead }) => (
                <div key={task.id} className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-3 text-sm">
                  <div className="flex min-w-0 items-center gap-3"><Avatar name={lead?.name ?? '?'} size={30} /><div className="min-w-0"><div className="truncate font-medium text-slate-200 line-through decoration-slate-500">{task.title}</div><div className="text-[11px] text-slate-500">{lead?.name} · completed {fmtDue(task.updated_at)}</div></div></div>
                  <Badge color="green">Completed</Badge>
                </div>
              ))}
            </div>
          )}
        </Panel>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title="New follow-up task">
        <div className="space-y-3">
          <Select label="Customer" value={form.lead_id} onChange={e => setForm({ ...form, lead_id: e.target.value })}>
            <option value="">Choose…</option>
            {data.leads.filter(l => !l.archived).map(l => <option key={l.id} value={l.id}>{l.name} · {l.restaurant_name}</option>)}
          </Select>
          <Input label="Title" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} />
          <Textarea label="Details (optional)" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
          <div className="grid grid-cols-2 gap-3">
            <Select label="Priority" value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value as TaskPriority })}>{(['Low', 'Medium', 'High', 'Urgent'] as const).map(p => <option key={p}>{p}</option>)}</Select>
            <Input label="Due" type="datetime-local" value={form.due_at} onChange={e => setForm({ ...form, due_at: e.target.value })} />
          </div>
        </div>
        <div className="mt-5 flex justify-end gap-2"><Button variant="secondary" onClick={() => setModal(false)}>Cancel</Button><Button onClick={saveTask}>Create</Button></div>
      </Modal>
    </div>
  );
}
