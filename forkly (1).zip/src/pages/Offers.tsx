// src/pages/Offers.tsx — English / LTR offer builder with live preview (offer card + WhatsApp message)
import React, { useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/Button';
import { Kpi, KpiGrid, PageHeader, glass } from '../components/ui/kit';
import { OfferCard, OFFER_THEMES, WhatsAppPreview, buildAutoMessage, offerToText } from '../components/OfferCard';
import { supabase } from '../lib/supabase';
import { toast } from 'sonner';
import { Users, Megaphone, Upload, Plus, Pencil, Trash2, Power, MessageCircle, Sparkles, Check } from 'lucide-react';
import type { OfferTheme } from '../lib/types';

const emptyForm = {
  title: '', description: '', price: '', original_price: '', valid_until: '',
  theme: 'green' as OfferTheme, message: '', active: true, image_url: null as string | null,
};

const field = 'w-full h-10 px-3 rounded-xl border border-white/10 bg-white/[0.05] text-sm text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-400';
const area = 'w-full px-4 py-3 rounded-xl border border-white/10 bg-white/[0.05] text-sm text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-400';

function Label({ children, required }: { children: React.ReactNode; required?: boolean }) {
  return <label className="block text-sm font-medium text-slate-300 mb-1.5">{children}{required && <span className="text-rose-400 ml-1">*</span>}</label>;
}

const MAX_IMG = 3 * 1024 * 1024;

export default function Offers() {
  const { data, addOffer, updateOffer, deleteOffer } = useApp();
  const navigate = useNavigate();
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const topRef = useRef<HTMLDivElement>(null);

  const recipients = useMemo(() => data.leads.filter(l => !l.archived && l.phone).length, [data.leads]);
  const set = <K extends keyof typeof emptyForm>(k: K, v: (typeof emptyForm)[K]) => setForm(f => ({ ...f, [k]: v }));
  const previewText = offerToText(form);

  const pickImage = async (file?: File) => {
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) { toast.error('JPG, PNG or WebP only'); return; }
    if (file.size > MAX_IMG) { toast.error('Max image size is 3MB'); return; }
    setUploading(true);
    try {
      if (supabase) {
        const ext = file.type === 'image/png' ? 'png' : file.type === 'image/webp' ? 'webp' : 'jpg';
        const path = `${crypto.randomUUID()}.${ext}`;
        const { error } = await supabase.storage.from('offers').upload(path, file, { contentType: file.type, cacheControl: '31536000' });
        if (error) throw new Error(error.message + ' — run 003_offers_design.sql in Supabase');
        set('image_url', supabase.storage.from('offers').getPublicUrl(path).data.publicUrl);
      } else {
        const url = await new Promise<string>((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result as string); r.onerror = rej; r.readAsDataURL(file); });
        set('image_url', url);
      }
    } catch (e) {
      toast.error(`Image upload failed: ${(e as Error).message}`);
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const reset = () => { setForm(emptyForm); setEditingId(null); };

  const save = () => {
    if (!form.title.trim()) { toast.error('Enter the offer title'); return; }
    if (!form.price.trim()) { toast.error('Enter the offer price (enter 0 if free)'); return; }
    const payload = { ...form, title: form.title.trim(), valid_until: form.valid_until || null, discount_label: '' };
    if (editingId) { updateOffer(editingId, payload); toast.success('Changes saved'); }
    else { addOffer(payload); toast.success('Offer added'); }
    reset();
  };

  const edit = (id: string) => {
    const o = data.offers.find(x => x.id === id);
    if (!o) return;
    setEditingId(id);
    setForm({ title: o.title, description: o.description, price: o.price, original_price: o.original_price, valid_until: o.valid_until || '', theme: o.theme, message: o.message || '', active: o.active, image_url: o.image_url });
    topRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const remove = (id: string) => {
    if (!confirm('Delete this offer?')) return;
    deleteOffer(id);
    if (editingId === id) reset();
    toast.success('Deleted');
  };

  return (
    <div dir="ltr" className="space-y-5 text-slate-100">
      <PageHeader title="Offers" subtitle="Build offers, preview them live and send them over WhatsApp" />
      <KpiGrid cols={4}>
        <Kpi icon={<Megaphone size={14} />} value={data.offers.length} label="Total Offers" sub="All saved offers" />
        <Kpi icon={<Power size={14} />} value={data.offers.filter(o => o.active).length} label="Active" sub="Visible for sending" accent="text-emerald-400" />
        <Kpi icon={<Users size={14} />} value={recipients} label="Recipients" sub="Leads with a phone" />
        <Kpi icon={<Pencil size={14} />} value={editingId ? 1 : 0} label="Editing" sub={editingId ? "Unsaved offer open" : "Nothing open"} accent={editingId ? "text-amber-300" : undefined} />
      </KpiGrid>
      <div ref={topRef} className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        {/* ---------- Form ---------- */}
        <div className={`${glass} space-y-5 p-5 lg:order-1`}>
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-500/15 text-teal-300 flex items-center justify-center"><Megaphone size={20} /></div>
            <div>
              <h2 className="text-lg font-semibold text-white">{editingId ? 'Edit offer' : 'New offer'}</h2>
              <p className="text-sm text-slate-400">Fill in the details and watch the live preview on the side</p>
            </div>
          </div>

          <div>
            <Label>Offer image (optional)</Label>
            <div className="flex items-center gap-3">
              <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={e => pickImage(e.target.files?.[0])} />
              <button type="button" onClick={() => fileRef.current?.click()} disabled={uploading}
                className="inline-flex items-center gap-2 h-11 px-5 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-500 text-white text-sm font-medium shadow-lg shadow-blue-500/30 disabled:opacity-60">
                <Upload size={15} /> {uploading ? 'Uploading…' : form.image_url ? 'Change image' : 'Choose image'}
              </button>
              {form.image_url && <button type="button" onClick={() => set('image_url', null)} className="text-xs text-rose-400">Remove</button>}
              <span className="text-xs text-slate-500">JPG, PNG or WebP, max 3MB.</span>
            </div>
          </div>

          <div>
            <Label required>Offer title</Label>
            <input className={field} value={form.title} onChange={e => set('title', e.target.value)} placeholder="e.g. Full Checkup Package" />
          </div>
          <div>
            <Label>Offer details</Label>
            <textarea className={area + ' min-h-[100px]'} value={form.description} onChange={e => set('description', e.target.value)} placeholder="e.g. Consultation + basic lab tests + ECG" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label required>Offer price (SAR)</Label>
              <input className={field} inputMode="decimal" value={form.price} onChange={e => set('price', e.target.value)} />
            </div>
            <div>
              <Label>Original price (optional)</Label>
              <input className={field} inputMode="decimal" value={form.original_price} onChange={e => set('original_price', e.target.value)} />
            </div>
          </div>
          <div>
            <Label>Valid until (optional)</Label>
            <input type="date" className={field} value={form.valid_until} onChange={e => set('valid_until', e.target.value)} />
          </div>

          <div>
            <Label>Offer style — colors</Label>
            <div className="flex flex-wrap gap-2">
              {(Object.keys(OFFER_THEMES) as OfferTheme[]).map(k => (
                <button key={k} type="button" onClick={() => set('theme', k)}
                  className={`inline-flex items-center gap-2 h-10 px-4 rounded-full border text-sm ${form.theme === k ? 'border-white ring-1 ring-white font-semibold' : 'border-white/10 text-slate-300'}`}>
                  <span className="w-3.5 h-3.5 rounded-full" style={{ background: OFFER_THEMES[k].dot }} />{OFFER_THEMES[k].label}
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-xl border border-white/10 bg-black/20 p-4 space-y-3">
            <Label>WhatsApp message</Label>
            <textarea className={area + ' min-h-[140px]'} value={form.message} onChange={e => set('message', e.target.value)}
              placeholder="Leave empty and the message is auto-generated from the offer details." />
            <p className="text-xs text-slate-500">Leave empty and the message is auto-generated from the offer details. *bold* and ~strikethrough~ work like WhatsApp.</p>
            <button type="button" onClick={() => set('message', buildAutoMessage(form))}
              className="inline-flex items-center gap-2 h-10 px-4 rounded-xl border border-white/10 bg-white/[0.04] text-sm font-medium">
              <Sparkles size={14} /> Fill with auto text and edit it
            </button>
          </div>

          <label className="flex items-center gap-2 text-sm font-medium">
            <input type="checkbox" className="w-4 h-4 accent-blue-500" checked={form.active} onChange={e => set('active', e.target.checked)} /> Offer is active
          </label>

          <div className="flex gap-2">
            <button type="button" onClick={save} className="flex-1 h-11 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-500 hover:brightness-110 text-white text-sm font-semibold shadow-lg shadow-blue-500/30 inline-flex items-center justify-center gap-2">
              {editingId ? <><Check size={18} /> Save changes</> : <>Add offer <Plus size={18} /></>}
            </button>
            {editingId && <button type="button" onClick={reset} className="h-11 px-5 rounded-xl border border-white/10 bg-white/[0.05] text-sm">Cancel</button>}
          </div>
        </div>

        {/* ---------- Live preview ---------- */}
        <div className="space-y-5 lg:order-2 lg:sticky lg:top-4">
          <OfferCard offer={form} />
          <WhatsAppPreview text={previewText} recipients={recipients} />
        </div>
      </div>

      {/* ---------- Saved offers ---------- */}
      <div className="space-y-3">
        <h2 className="text-lg font-semibold text-white">Your offers ({data.offers.length})</h2>
        {data.offers.length === 0 ? (
          <p className="text-sm text-slate-400">No offers yet. Fill in the form and add your first offer.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
            {data.offers.map(o => (
              <OfferCard key={o.id} offer={o}>
                <Button size="sm" variant="secondary" onClick={() => navigate(`/whatsapp?offer=${o.id}`)}><MessageCircle size={13} /> Send</Button>
                <Button size="sm" variant="ghost" onClick={() => edit(o.id)}><Pencil size={13} /> Edit</Button>
                <Button size="sm" variant="ghost" onClick={() => updateOffer(o.id, { active: !o.active })}><Power size={13} /> {o.active ? 'Pause' : 'Activate'}</Button>
                <Button size="sm" variant="ghost" onClick={() => remove(o.id)}><Trash2 size={13} className="text-rose-400" /></Button>
              </OfferCard>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
