// src/pages/Overview.tsx — Leads-style dashboard: KPI strip, charts, attention lists, activity timeline
import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Bar, BarChart, Cell, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { AlertTriangle, Calendar, CheckCircle2, Clock, Mail, Send, TrendingUp, Users } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CHART_AXIS, CHART_TIP, DONUT, Empty, Kpi, KpiGrid, PageHeader, Panel, StatusChip, Avatar, fmtShort } from '../components/ui/kit';
import { Badge, statusColor } from '../components/ui/Badge';
import { buildScores, isHot, relativeDay, shareBy } from '../lib/leadInsights';
import type { LeadStatus } from '../lib/types';

const STAGES: LeadStatus[] = ['New', 'Contacted', 'Interested', 'Demo Booked', 'Trial', 'Converted'];

export default function Overview() {
  const { data } = useApp();
  const leads = useMemo(() => data.leads.filter(l => !l.archived), [data.leads]);
  const scores = useMemo(() => buildScores(data), [data]);

  const totalLeads = leads.length;
  const newWeek = leads.filter(l => Date.now() - new Date(l.created_at).getTime() < 7 * 86400000).length;
  const pendingApprovals = data.approvals.filter(a => a.status === 'Pending').length;
  const messagesSent = data.messages.filter(m => ['Accepted by Provider', 'Delivered'].includes(m.status)).length;
  const demosBooked = data.bookings.length;
  const converted = leads.filter(l => l.status === 'Converted').length;
  const conversionRate = totalLeads ? Math.round((converted / totalLeads) * 100) : 0;
  const hot = leads.filter(l => isHot(l, scores)).length;

  const last14 = useMemo(() => Array.from({ length: 14 }, (_, i) => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - (13 - i));
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const count = leads.filter(l => {
      const c = new Date(l.created_at);
      return `${c.getFullYear()}-${String(c.getMonth() + 1).padStart(2, '0')}-${String(c.getDate()).padStart(2, '0')}` === key;
    }).length;
    return { day: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }), count };
  }), [leads]);

  const sources = useMemo(() => {
    const rows = shareBy(leads, l => l.source);
    const top = rows.slice(0, 4);
    const rest = rows.slice(4).reduce((a, r) => a + r.value, 0);
    if (rest) top.push({ label: 'Other', value: rest, pct: Math.round((rest / (leads.length || 1)) * 100) });
    return top;
  }, [leads]);
  const topSource = sources[0];

  const pipelineData = STAGES.map(s => ({ name: s, count: leads.filter(l => l.status === s).length }));

  const attention = leads.filter(l => (l.status === 'New' && !l.last_contact_at) || (l.next_follow_up_at && new Date(l.next_follow_up_at).getTime() < Date.now())).slice(0, 6);
  const upcomingDemos = data.bookings
    .filter(b => new Date(b.booking_date).getTime() >= Date.now() - 86400000)
    .sort((a, b) => a.booking_date.localeCompare(b.booking_date))
    .slice(0, 5);
  const overdueTasks = data.follow_up_tasks.filter(t => t.status === 'Pending' && new Date(t.due_at).getTime() < Date.now()).slice(0, 5);
  const recentActivity = [...data.activity_logs].sort((a, b) => b.created_at.localeCompare(a.created_at)).slice(0, 5);
  const ownerName = (id: string | null) => data.profiles.find(p => p.id === id)?.full_name ?? 'System';

  return (
    <div className="text-slate-100">
      <PageHeader title="Overview" subtitle="Your sales pipeline at a glance" />

      <KpiGrid>
        <Kpi icon={<Users size={14} />} value={totalLeads.toLocaleString()} label="Total Leads" sub="All time" />
        <Kpi icon={<TrendingUp size={14} />} value={`+${newWeek}`} label="New Leads" sub="Last 7 days" accent="text-emerald-400" />
        <Kpi icon={<CheckCircle2 size={14} />} value={pendingApprovals} label="Pending Approvals" sub="Awaiting review" accent={pendingApprovals ? 'text-amber-300' : undefined} />
        <Kpi icon={<Send size={14} />} value={messagesSent} label="Messages Sent" sub="Accepted or delivered" />
        <Kpi icon={<Calendar size={14} />} value={demosBooked} label="Demos Booked" sub={`${hot} hot lead${hot === 1 ? '' : 's'}`} accent="text-orange-300" />
        <Kpi icon={<TrendingUp size={14} />} value={`${conversionRate}%`} label="Conversion Rate" sub="lead → deal" accent="text-emerald-400" />
      </KpiGrid>

      <div className="mb-5 grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_340px]">
        <Panel title="Leads Over Time" icon={<TrendingUp size={15} />} to="/leads">
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={last14}>
                <XAxis dataKey="day" tick={CHART_AXIS} stroke="rgba(255,255,255,0.15)" interval={1} />
                <YAxis tick={CHART_AXIS} stroke="rgba(255,255,255,0.15)" allowDecimals={false} />
                <Tooltip {...CHART_TIP} />
                <Line type="monotone" dataKey="count" stroke="#60a5fa" strokeWidth={2} dot={{ r: 3, fill: '#60a5fa' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Panel>

        <Panel title="Lead Sources" icon={<Users size={15} />} to="/leads">
          <div className="flex items-center gap-3">
            <div className="relative h-[170px] w-[170px] shrink-0">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={sources.length ? sources : [{ label: 'none', value: 1, pct: 0 }]} dataKey="value" nameKey="label" innerRadius={55} outerRadius={78} paddingAngle={sources.length > 1 ? 3 : 0} stroke="none" startAngle={90} endAngle={-270}>
                    {(sources.length ? sources : [{ label: 'none' }]).map((_, i) => <Cell key={i} fill={sources.length ? DONUT[i % DONUT.length] : 'rgba(255,255,255,0.1)'} />)}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-2xl font-semibold text-white">{topSource ? `${topSource.pct}%` : '—'}</span>
                <span className="max-w-[80px] truncate text-[10px] text-slate-400">{topSource ? topSource.label : 'No data'}</span>
              </div>
            </div>
            <ul className="min-w-0 flex-1 space-y-2 text-xs">
              {sources.map((s, i) => (
                <li key={s.label} className="flex items-center justify-between gap-2"><span className="flex min-w-0 items-center gap-2 text-slate-300"><span className="h-2 w-2 shrink-0 rounded-full" style={{ background: DONUT[i % DONUT.length] }} /><span className="truncate">{s.label}</span></span><span className="font-semibold text-slate-100">{s.pct}%</span></li>
              ))}
            </ul>
          </div>
        </Panel>
      </div>

      <Panel title="Pipeline" icon={<TrendingUp size={15} />} to="/pipeline" linkLabel="Open board" className="mb-5">
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={pipelineData}>
              <XAxis dataKey="name" tick={CHART_AXIS} stroke="rgba(255,255,255,0.15)" />
              <YAxis tick={CHART_AXIS} stroke="rgba(255,255,255,0.15)" allowDecimals={false} />
              <Tooltip {...CHART_TIP} />
              <Bar dataKey="count" fill="#3b82f6" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Panel>

      <div className="mb-5 grid grid-cols-1 gap-5 lg:grid-cols-3">
        <Panel title="Attention Required" icon={<AlertTriangle size={15} />} to="/leads">
          {attention.length === 0 ? <Empty>No urgent leads.</Empty> : (
            <ul className="space-y-1">
              {attention.map(l => (
                <li key={l.id}>
                  <Link to={`/leads/${l.id}`} className="flex items-center justify-between gap-2 rounded-lg p-2 hover:bg-white/[0.05]">
                    <span className="flex min-w-0 items-center gap-2.5"><Avatar name={l.name} size={28} />
                      <span className="min-w-0"><span className="block truncate text-sm font-medium text-white">{l.name}</span><span className="block truncate text-[10px] text-slate-400">{l.restaurant_name}</span></span>
                    </span>
                    <StatusChip status={l.status} />
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel title="Upcoming Demos" icon={<Calendar size={15} />} to="/bookings">
          {upcomingDemos.length === 0 ? <Empty>No upcoming demos.</Empty> : (
            <ul className="space-y-1">
              {upcomingDemos.map(b => {
                const l = data.leads.find(x => x.id === b.lead_id);
                return (
                  <li key={b.id} className="flex items-center justify-between gap-2 rounded-lg p-2 hover:bg-white/[0.05]">
                    <span className="flex min-w-0 items-center gap-2.5"><Avatar name={l?.name ?? '?'} size={28} />
                      <span className="min-w-0"><span className="block truncate text-sm font-medium text-white">{l?.name}</span><span className="block text-[10px] text-slate-400">{b.booking_date} · {b.booking_time}</span></span>
                    </span>
                    <Badge color={statusColor(b.status)}>{b.status}</Badge>
                  </li>
                );
              })}
            </ul>
          )}
        </Panel>

        <Panel title="Overdue Follow-ups" icon={<Clock size={15} />} to="/bookings">
          {overdueTasks.length === 0 ? <Empty>No overdue tasks.</Empty> : (
            <ul className="space-y-1">
              {overdueTasks.map(t => {
                const l = data.leads.find(x => x.id === t.lead_id);
                return (
                  <li key={t.id} className="flex items-center justify-between gap-2 rounded-lg p-2 hover:bg-white/[0.05]">
                    <span className="flex min-w-0 items-center gap-2.5"><Avatar name={l?.name ?? '?'} size={28} />
                      <span className="min-w-0"><span className="block truncate text-sm font-medium text-white">{l?.name}</span><span className="block truncate text-[10px] text-slate-400">{t.title} · due {fmtShort(t.due_at)}</span></span>
                    </span>
                    <Badge color="red">Overdue</Badge>
                  </li>
                );
              })}
            </ul>
          )}
        </Panel>
      </div>

      <Panel title="Recent Activity" icon={<Calendar size={15} />} to="/activity">
        {recentActivity.length === 0 ? <Empty>No activity yet.</Empty> : (
          <ol className="relative space-y-4 pl-6 before:absolute before:left-[7px] before:top-1 before:h-[calc(100%-8px)] before:w-px before:bg-white/15">
            {recentActivity.map(a => (
              <li key={a.id} className="relative">
                <span className="absolute -left-6 top-0.5 h-3.5 w-3.5 rounded-full border-2 border-blue-400 bg-[#0a0f2c]" />
                <div className="text-sm font-medium text-white">{relativeDay(a.created_at)} <span className="text-xs font-normal text-slate-400">{new Date(a.created_at).toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' })}</span></div>
                <div className="flex items-center gap-1.5 text-[11px] text-slate-400"><Mail size={11} />{a.description} · {ownerName(a.actor_id)}</div>
              </li>
            ))}
          </ol>
        )}
      </Panel>
    </div>
  );
}
