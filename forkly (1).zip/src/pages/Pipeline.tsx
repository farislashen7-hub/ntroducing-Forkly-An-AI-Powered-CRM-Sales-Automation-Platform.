// src/pages/Pipeline.tsx
import React, { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { Avatar, Kpi, KpiGrid, PageHeader, ScoreBar, darkField, glass } from '../components/ui/kit';
import { buildScores } from '../lib/leadInsights';
import { usePermissions } from '../lib/permissions';
import { Button } from '../components/ui/Button';
import { Modal } from '../components/ui/Modal';
import { Input, Select } from '../components/ui/Input';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import {
  DndContext, closestCorners, PointerSensor, useSensor, useSensors, useDroppable, useDraggable,
} from '@dnd-kit/core';
import type { DragEndEvent } from '@dnd-kit/core';
import { CSS } from '@dnd-kit/utilities';
import { Calendar, CalendarPlus, Flame, Layers, TrendingUp, Users } from 'lucide-react';
import type { Lead, LeadStatus } from '../lib/types';

const STAGES: LeadStatus[] = ['New', 'Contacted', 'Interested', 'Demo Booked', 'Trial', 'Converted'];

function DraggableCard({ lead, score, onQuick }: { lead: Lead; score: number; onQuick: (id: string) => void }) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({ id: lead.id });
  const style = transform ? { transform: CSS.Translate.toString(transform) } : undefined;
  const { data } = useApp();
  const profile = data.profiles.find(p => p.id === lead.assigned_to);
  return (
    <div ref={setNodeRef} style={style} {...listeners} {...attributes}
      className={`mb-2 cursor-grab rounded-xl border border-white/10 bg-white/[0.05] p-3 transition hover:bg-white/[0.08] active:cursor-grabbing ${isDragging ? 'opacity-50' : ''}`}>
      <div className="flex items-center gap-2.5">
        <Avatar name={lead.name} size={30} />
        <div className="min-w-0 flex-1">
          <Link to={`/leads/${lead.id}`} className="block truncate text-sm font-semibold text-white hover:text-blue-300" onClick={e => e.stopPropagation()}>{lead.name}</Link>
          <div className="truncate text-[11px] text-slate-400">{lead.restaurant_name}</div>
        </div>
      </div>
      <div className="mt-3"><ScoreBar score={score} wide /></div>
      <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400">
        <span>{lead.source}</span>
        <span>{profile?.full_name || 'Unassigned'}</span>
      </div>
      {lead.next_follow_up_at && (
        <div className="mt-1 flex items-center gap-1 text-[10px] text-slate-400"><Calendar size={10} /> {new Date(lead.next_follow_up_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</div>
      )}
      <button onClick={(e) => { e.stopPropagation(); onQuick(lead.id); }} className="mt-2 inline-flex items-center gap-1 rounded-lg border border-white/10 bg-white/[0.05] px-2 py-1 text-[10px] text-slate-300 hover:bg-white/10"><CalendarPlus size={10} /> Book Demo</button>
    </div>
  );
}

function Column({ stage, leads, scores, onQuick }: { stage: LeadStatus; leads: Lead[]; scores: Map<string, number>; onQuick: (id: string) => void }) {
  const { setNodeRef, isOver } = useDroppable({ id: stage });
  return (
    <div className={`${glass} min-w-[270px] flex-1 p-3`}>
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-white">{stage}</h3>
        <span className="rounded-full border border-white/10 bg-white/[0.05] px-2 py-0.5 text-[11px] text-slate-300">{leads.length}</span>
      </div>
      <div ref={setNodeRef} className={`min-h-[200px] rounded-xl transition ${isOver ? 'bg-blue-500/10 ring-1 ring-blue-400/40' : ''}`}>
        {leads.map(l => <DraggableCard key={l.id} lead={l} score={scores.get(l.id) ?? 0} onQuick={onQuick} />)}
        {leads.length === 0 && <p className="py-8 text-center text-[11px] text-slate-500">Drop leads here</p>}
      </div>
    </div>
  );
}

export default function Pipeline() {
  const { data, updateLead, addBooking, logActivity, currentUser } = useApp();
  const [filters, setFilters] = useState({ source: '', salesperson: '' });
  const [bookingLead, setBookingLead] = useState<string | null>(null);
  const [bookingForm, setBookingForm] = useState({ booking_date: '', booking_time: '10:00', timezone: 'America/New_York', notes: '' });

  const { can } = usePermissions();
  const scores = useMemo(() => buildScores(data), [data]);
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

  const leads = data.leads.filter(l => !l.archived).filter(l => {
    if (filters.source && l.source !== filters.source) return false;
    if (filters.salesperson && l.assigned_to !== filters.salesperson) return false;
    return true;
  });

  const onDragEnd = (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over) return;
    if (!can('pipeline.move')) { toast.error('Your role cannot move leads'); return; }
    const leadId = String(active.id);
    const newStage = String(over.id) as LeadStatus;
    const lead = data.leads.find(l => l.id === leadId);
    if (!lead || lead.status === newStage) return;
    if (newStage === 'Demo Booked') {
      const hasBooking = data.bookings.some(b => b.lead_id === leadId);
      if (!hasBooking) {
        toast.error('Create a booking record before moving to Demo Booked');
        setBookingLead(leadId);
        return;
      }
    }
    updateLead(leadId, { status: newStage });
    logActivity({ lead_id: leadId, actor_id: currentUser.id, event_type: 'Pipeline Stage Changed', description: `${lead.name}: ${lead.status} → ${newStage}`, metadata: null });
    toast.success(`Moved to ${newStage}`);
  };

  const openBooking = (leadId: string) => setBookingLead(leadId);

  const createBooking = () => {
    if (!bookingLead || !bookingForm.booking_date) { toast.error('Date required'); return; }
    const lead = data.leads.find(l => l.id === bookingLead);
    addBooking({ lead_id: bookingLead, booking_date: bookingForm.booking_date, booking_time: bookingForm.booking_time, timezone: bookingForm.timezone, status: 'Scheduled', assigned_to: currentUser.id, notes: bookingForm.notes });
    updateLead(bookingLead, { status: 'Demo Booked', next_follow_up_at: new Date(bookingForm.booking_date + 'T' + bookingForm.booking_time).toISOString() });
    logActivity({ lead_id: bookingLead, actor_id: currentUser.id, event_type: 'Booking Created', description: `Demo booked for ${lead?.name}`, metadata: null });
    setBookingLead(null);
    setBookingForm({ booking_date: '', booking_time: '10:00', timezone: 'America/New_York', notes: '' });
    toast.success('Demo booked and moved to Demo Booked');
  };

  const SOURCES = [...new Set(data.leads.map(l => l.source))];

  return (
    <div className="text-slate-100">
      <PageHeader title="Sales Pipeline" subtitle="Drag leads between stages to move them forward">
        <select className={darkField} value={filters.source} onChange={e => setFilters({ ...filters, source: e.target.value })}>
          <option value="">Source: All</option>
          {SOURCES.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
        <select className={darkField} value={filters.salesperson} onChange={e => setFilters({ ...filters, salesperson: e.target.value })}>
          <option value="">Owner: All reps</option>
          {data.profiles.map(p => <option key={p.id} value={p.id}>{p.full_name}</option>)}
        </select>
      </PageHeader>

      <KpiGrid cols={4}>
        <Kpi icon={<Layers size={14} />} value={leads.length} label="In Pipeline" sub="Open + converted" />
        <Kpi icon={<Users size={14} />} value={leads.filter(l => l.status === 'Interested' || l.status === 'Demo Booked' || l.status === 'Trial').length} label="Qualified" sub="Interested to Trial" />
        <Kpi icon={<Flame size={14} />} value={leads.filter(l => l.status !== 'Converted' && (scores.get(l.id) ?? 0) >= 80).length} label="Hot Leads" sub="score 80+, still open" accent="text-orange-300" />
        <Kpi icon={<TrendingUp size={14} />} value={`${leads.length ? Math.round((leads.filter(l => l.status === 'Converted').length / leads.length) * 100) : 0}%`} label="Converted" sub="of filtered leads" accent="text-emerald-400" />
      </KpiGrid>

      <DndContext sensors={sensors} collisionDetection={closestCorners} onDragEnd={onDragEnd}>
        <div className="flex gap-4 overflow-x-auto pb-4">
          {STAGES.map(stage => (
            <Column key={stage} stage={stage} leads={leads.filter(l => l.status === stage)} scores={scores} onQuick={openBooking} />
          ))}
        </div>
      </DndContext>

      <Modal open={!!bookingLead} onClose={() => setBookingLead(null)} title="Book Demo (required for Demo Booked)">
        <div className="space-y-3">
          <Input label="Date" type="date" value={bookingForm.booking_date} onChange={e => setBookingForm({ ...bookingForm, booking_date: e.target.value })} />
          <Input label="Time" type="time" value={bookingForm.booking_time} onChange={e => setBookingForm({ ...bookingForm, booking_time: e.target.value })} />
          <Select label="Timezone" value={bookingForm.timezone} onChange={e => setBookingForm({ ...bookingForm, timezone: e.target.value })}>
            <option value="America/New_York">America/New_York</option>
            <option value="America/Chicago">America/Chicago</option>
            <option value="America/Los_Angeles">America/Los_Angeles</option>
            <option value="Europe/London">Europe/London</option>
          </Select>
          <Input label="Notes" value={bookingForm.notes} onChange={e => setBookingForm({ ...bookingForm, notes: e.target.value })} />
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setBookingLead(null)}>Cancel</Button>
          <Button onClick={createBooking}>Book & Move</Button>
        </div>
      </Modal>
    </div>
  );
}
