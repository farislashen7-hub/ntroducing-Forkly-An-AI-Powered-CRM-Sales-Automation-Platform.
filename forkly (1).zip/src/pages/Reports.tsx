// src/pages/Reports.tsx — analytics: funnel, source performance, rep leaderboard, response time, trend + CSV export
import React, { useMemo, useState } from 'react';
import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { BarChart3, CalendarCheck, Download, Filter, Timer, Trophy, TrendingUp, Users, Target } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Avatar, CHART_AXIS, CHART_TIP, Empty, Kpi, KpiGrid, PageHeader, Panel, darkField, softBtn, tableWrap, td, th, thead, tr } from '../components/ui/kit';
import { QUALIFIED_STATUSES, avgResponseHours, buildScores, formatHours } from '../lib/leadInsights';
import type { LeadStatus } from '../lib/types';
import { usePermissions } from '../lib/permissions';

const RANGES = [{ v: '7', l: 'Last 7 days' }, { v: '30', l: 'Last 30 days' }, { v: '90', l: 'Last 90 days' }, { v: 'all', l: 'All time' }];
const FUNNEL: LeadStatus[] = ['New', 'Contacted', 'Interested', 'Demo Booked', 'Trial', 'Converted'];
const pct = (a: number, b: number) => (b ? Math.round((a / b) * 100) : 0);
// reached a stage = currently at that stage or any later one
const rank = (s: LeadStatus) => FUNNEL.indexOf(s);

export default function Reports() {
  const { data, currentUser } = useApp();
  const { can } = usePermissions();
  const teamView = can('report.team');   // managers/admins see everyone; others only their own customers
  const [range, setRange] = useState('30');

  const scope = useMemo(() => {
    const live = data.leads.filter(l => !l.archived && (teamView || l.assigned_to === currentUser.id));
    if (range === 'all') return live;
    const cutoff = Date.now() - Number(range) * 86400000;
    return live.filter(l => new Date(l.created_at).getTime() >= cutoff);
  }, [data.leads, range, teamView, currentUser.id]);

  const scores = useMemo(() => buildScores(data), [data]);
  const total = scope.length;
  const converted = scope.filter(l => l.status === 'Converted').length;
  const lost = scope.filter(l => l.status === 'Lost').length;
  const scopeIds = new Set(scope.map(l => l.id));
  const contacted = scope.filter(l => l.last_contact_at || l.status !== 'New').length;
  const bookedLeads = new Set(data.bookings.filter(b => b.status !== 'Cancelled' && scopeIds.has(b.lead_id)).map(b => b.lead_id)).size;
  const bookingsCount = data.bookings.filter(b => b.status !== 'Cancelled' && scopeIds.has(b.lead_id)).length;
  const resp = formatHours(avgResponseHours(data, new Set(scope.map(l => l.id))));

  const funnel = FUNNEL.map(s => {
    const n = scope.filter(l => l.status !== 'Lost' && rank(l.status) >= rank(s)).length;
    return { stage: s, count: n, pct: pct(n, total) };
  });

  const bySource = useMemo(() => {
    const booked = new Set(data.bookings.filter(b => b.status !== 'Cancelled').map(b => b.lead_id));
    const m = new Map<string, { total: number; qualified: number; converted: number; score: number; booked: number }>();
    for (const l of scope) {
      const r = m.get(l.source) ?? { total: 0, qualified: 0, converted: 0, score: 0, booked: 0 };
      r.total++; r.score += scores.get(l.id) ?? 0;
      if (booked.has(l.id)) r.booked++;
      if (QUALIFIED_STATUSES.includes(l.status) || l.status === 'Converted') r.qualified++;
      if (l.status === 'Converted') r.converted++;
      m.set(l.source, r);
    }
    return [...m.entries()].map(([source, r]) => ({ source, ...r, avg: Math.round(r.score / r.total) })).sort((a, b) => b.total - a.total);
  }, [scope, scores, data.bookings]);
  // most successful source: best win rate, then most conversions (ignore sources with a single lead when others exist)
  const bestSource = useMemo(() => {
    const pool = bySource.filter(s => s.total >= 2).length ? bySource.filter(s => s.total >= 2) : bySource;
    return [...pool].sort((a, b) => pct(b.converted, b.total) - pct(a.converted, a.total) || b.converted - a.converted || b.total - a.total)[0]?.source ?? null;
  }, [bySource]);

  const byRep = useMemo(() => {
    return data.profiles.filter(p => teamView || p.id === currentUser.id).map(p => {
      const mine = scope.filter(l => l.assigned_to === p.id);
      const conv = mine.filter(l => l.status === 'Converted').length;
      const open = mine.filter(l => l.status !== 'Converted' && l.status !== 'Lost').length;
      const r = formatHours(avgResponseHours(data, new Set(mine.map(l => l.id))));
      const tasksDone = data.follow_up_tasks.filter(t => t.assigned_to === p.id && t.status === 'Completed').length;
      const mineIds = new Set(mine.map(l => l.id));
      const demos = data.bookings.filter(b => b.status !== 'Cancelled' && (b.assigned_to === p.id || (!b.assigned_to && mineIds.has(b.lead_id)))).length;
      const reached = mine.filter(l => l.last_contact_at || l.status !== 'New').length;
      const late = data.follow_up_tasks.filter(t => t.assigned_to === p.id && t.status === 'Pending' && new Date(t.due_at).getTime() < Date.now()).length;
      return { id: p.id, name: p.full_name, role: p.role, reached, late, leads: mine.length, open, conv, rate: pct(conv, mine.length), resp: r.value === '—' ? '—' : `${r.value} ${r.unit}`, tasksDone, demos };
    }).filter(r => r.leads > 0 || r.tasksDone > 0 || r.demos > 0).sort((a, b) => b.conv - a.conv || b.leads - a.leads);
  }, [data, scope, teamView, currentUser.id]);

  const trend = useMemo(() => {
    const days = range === 'all' ? 30 : Math.min(Number(range), 30);
    return Array.from({ length: days }, (_, i) => {
      const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - (days - 1 - i));
      const next = new Date(d); next.setDate(d.getDate() + 1);
      const inDay = (iso: string) => { const t = new Date(iso).getTime(); return t >= d.getTime() && t < next.getTime(); };
      return {
        day: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        created: data.leads.filter(l => !l.archived && inDay(l.created_at)).length,
        converted: data.leads.filter(l => l.status === 'Converted' && inDay(l.updated_at)).length,
      };
    });
  }, [data.leads, range]);

  const lostRate = pct(lost, total);

  const exportReport = () => {
    const q = (v: string | number) => `"${String(v).replace(/"/g, '""')}"`;
    const rows: (string | number)[][] = [
      ['Report', RANGES.find(r => r.v === range)!.l], [],
      ['Funnel stage', 'Leads', '% of total'], ...funnel.map(f => [f.stage, f.count, f.pct]), [],
      ['Source', 'Leads', 'Booked', 'Qualified', 'Converted', 'Conversion %', 'Avg score'], ...bySource.map(s => [s.source, s.total, s.booked, s.qualified, s.converted, pct(s.converted, s.total), s.avg]), [],
      ['Salesperson', 'Leads', 'Contacted', 'Open', 'Converted', 'Conversion %', 'Avg response', 'Bookings', 'Tasks done', 'Overdue tasks'], ...byRep.map(r => [r.name, r.leads, r.reached, r.open, r.conv, r.rate, r.resp, r.demos, r.tasksDone, r.late]),
    ];
    const url = URL.createObjectURL(new Blob([rows.map(r => r.map(q).join(',')).join('\n')], { type: 'text/csv;charset=utf-8' }));
    const a = document.createElement('a'); a.href = url; a.download = `report-${range}.csv`; a.click(); URL.revokeObjectURL(url);
  };

  return (
    <div className="text-slate-100">
      <PageHeader title="Reports" subtitle="New leads, contact, bookings, conversion, team and source performance">
        <select className={darkField} value={range} onChange={e => setRange(e.target.value)}>{RANGES.map(r => <option key={r.v} value={r.v}>{r.l}</option>)}</select>
        <button onClick={exportReport} className={softBtn}><Download size={13} /> Export CSV</button>
      </PageHeader>

      {!teamView && <p className="mb-4 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs text-slate-300">You are seeing your own customers only. Managers see the whole team.</p>}
      <KpiGrid>
        <Kpi icon={<Users size={14} />} value={total} label="New Leads" sub={RANGES.find(r => r.v === range)!.l} />
        <Kpi icon={<Target size={14} />} value={contacted} label="Contacted" sub={`${pct(contacted, total)}% of new leads`} />
        <Kpi icon={<CalendarCheck size={14} />} value={bookingsCount} label="Bookings" sub={`${bookedLeads} customers booked (${pct(bookedLeads, total)}%)`} accent="text-sky-300" />
        <Kpi icon={<TrendingUp size={14} />} value={`${pct(converted, total)}%`} label="Conversion Rate" sub={`${converted} converted`} accent="text-emerald-400" />
        <Kpi icon={<Timer size={14} />} value={resp.value} label={resp.unit ? `${resp.unit} response` : 'Response Time'} sub="first reply to inbound" />
        <Kpi icon={<Filter size={14} />} value={`${lostRate}%`} label="Lost Rate" sub={`${lost} lost`} accent={lostRate > 30 ? 'text-rose-300' : undefined} />
      </KpiGrid>

      <div className="mb-5 grid grid-cols-1 gap-5 xl:grid-cols-2">
        <Panel title="Conversion Funnel" icon={<Filter size={15} />}>
          {total === 0 ? <Empty>No leads in this period.</Empty> : (
            <div className="space-y-3">
              {funnel.map((f, i) => (
                <div key={f.stage}>
                  <div className="mb-1 flex items-center justify-between text-xs"><span className="text-slate-200">{f.stage}</span><span className="text-slate-300">{f.count} · {f.pct}%{i > 0 && funnel[i - 1].count ? <span className="text-slate-500"> ({pct(f.count, funnel[i - 1].count)}% of prev)</span> : null}</span></div>
                  <div className="h-2.5 rounded-full bg-white/10"><div className="h-full rounded-full bg-gradient-to-r from-sky-400 to-violet-500" style={{ width: `${f.pct}%` }} /></div>
                </div>
              ))}
            </div>
          )}
        </Panel>

        <Panel title="Leads vs Conversions" icon={<TrendingUp size={15} />}>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trend}>
                <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
                <XAxis dataKey="day" tick={CHART_AXIS} stroke="rgba(255,255,255,0.15)" interval="preserveStartEnd" />
                <YAxis tick={CHART_AXIS} stroke="rgba(255,255,255,0.15)" allowDecimals={false} />
                <Tooltip {...CHART_TIP} />
                <Line type="monotone" dataKey="created" name="New leads" stroke="#60a5fa" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="converted" name="Converted" stroke="#34d399" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Panel>
      </div>

      <div className="mb-5 grid grid-cols-1 gap-5 xl:grid-cols-2">
        <Panel title="Best Lead Sources" icon={<BarChart3 size={15} />}>
          {bySource.length === 0 ? <Empty>No data.</Empty> : (
            <>
              <div className="mb-4 h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={bySource}>
                    <XAxis dataKey="source" tick={CHART_AXIS} stroke="rgba(255,255,255,0.15)" interval={0} angle={-20} textAnchor="end" height={50} />
                    <YAxis tick={CHART_AXIS} stroke="rgba(255,255,255,0.15)" allowDecimals={false} />
                    <Tooltip {...CHART_TIP} />
                    <Bar dataKey="total" name="Leads" fill="#3b82f6" radius={[6, 6, 0, 0]} />
                    <Bar dataKey="converted" name="Converted" fill="#34d399" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className={tableWrap}>
                <table className="w-full min-w-[420px] text-sm">
                  <thead className={thead}><tr><th className={th}>Source</th><th className={th}>Leads</th><th className={th}>Booked</th><th className={th}>Qualified</th><th className={th}>Conversion</th><th className={th}>Avg score</th></tr></thead>
                  <tbody>{bySource.map(s => (
                    <tr key={s.source} className={tr}><td className={`${td} text-white`}>{s.source}{s.source === bestSource && <span className="ml-2 rounded-full border border-emerald-400/30 bg-emerald-500/15 px-2 py-0.5 text-[10px] text-emerald-300">Best</span>}</td><td className={td}>{s.total}</td><td className={td}>{s.booked}</td><td className={td}>{pct(s.qualified, s.total)}%</td><td className={`${td} text-emerald-300`}>{pct(s.converted, s.total)}%</td><td className={td}>{s.avg}</td></tr>
                  ))}</tbody>
                </table>
              </div>
            </>
          )}
        </Panel>

        <Panel title={teamView ? "Team Performance" : "My Performance"} icon={<Trophy size={15} />}>
          {byRep.length === 0 ? <Empty>No assigned leads in this period.</Empty> : (
            <div className={tableWrap}>
              <table className="w-full min-w-[620px] text-sm">
                <thead className={thead}><tr><th className={th}>#</th><th className={th}>Salesperson</th><th className={th}>Leads</th><th className={th}>Contacted</th><th className={th}>Won</th><th className={th}>Conversion</th><th className={th}>Bookings</th><th className={th}>Overdue</th><th className={th}>Response</th></tr></thead>
                <tbody>{byRep.map((r, i) => (
                  <tr key={r.id} className={tr}>
                    <td className={`${td} text-slate-400`}>{i + 1}</td>
                    <td className={td}><span className="flex items-center gap-2.5 font-medium text-white"><Avatar name={r.name} size={28} />{r.name}</span></td>
                    <td className={td}>{r.leads}</td><td className={td}>{r.reached}</td><td className={`${td} text-emerald-300`}>{r.conv}</td><td className={td}>{r.rate}%</td><td className={td}>{r.demos}</td><td className={`${td} ${r.late ? 'text-rose-300' : ''}`}>{r.late}</td><td className={`${td} text-xs text-slate-300`}>{r.resp}</td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}
