// src/pages/Settings.tsx
import React, { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card, CardBody, CardHeader } from '../components/ui/Card';
import { Avatar, Kpi, KpiGrid, PageHeader, tableWrap, td, th, thead, tr } from '../components/ui/kit';
import { Badge } from '../components/ui/Badge';
import { Input, Select } from '../components/ui/Input';
import { Shield, User, Plug, Rocket, Zap } from 'lucide-react';
import { toast } from 'sonner';
import { DEFAULT_AUTOMATION, loadAutomation, saveAutomation, type AutomationSettings } from '../lib/automation';
import { usePermissions } from '../lib/permissions';
import { Button } from '../components/ui/Button';
import { supabaseStatus } from '../lib/supabase';
import { getHealth, type Health } from '../lib/api';

function Row({ label, ok, detail }: { label: string; ok: boolean; detail: string }) {
  return (
    <div className="flex items-center justify-between py-2 border-t border-white/10 first:border-t-0 text-sm">
      <span className="font-medium">{label}</span>
      <span className="flex items-center gap-2">
        <span className="text-xs text-slate-400 text-right">{detail}</span>
        <Badge color={ok ? 'green' : 'amber'}>{ok ? 'Connected' : 'Not connected'}</Badge>
      </span>
    </div>
  );
}

export default function Settings() {
  const { data, currentUser, syncState } = useApp();
  const [health, setHealth] = useState<Health | null>(null);
  useEffect(() => { getHealth().then(setHealth); }, []);
  const { can } = usePermissions();
  const [auto, setAuto] = useState<AutomationSettings>(loadAutomation);
  const setAutoSave = (patch: Partial<AutomationSettings>) => { const n = { ...auto, ...patch }; setAuto(n); saveAutomation(n); toast.success('Automation saved'); };
  const [deploying, setDeploying] = useState(false);
  const [deployResult, setDeployResult] = useState<{ ok: boolean; url?: string; created?: boolean; error?: string } | null>(null);
  const runDeploy = async () => {
    setDeploying(true); setDeployResult(null);
    try {
      const r = await fetch('/api/deploy', { method: 'POST' });
      setDeployResult(await r.json());
    } catch (e) { setDeployResult({ ok: false, error: (e as Error).message }); }
    setDeploying(false);
  };

  const sbDetail = supabaseStatus.ok
    ? syncState === 'synced' ? 'Browser synced with database' : syncState === 'error' ? 'Cannot read tables — run the SQL migrations' : 'Loading…'
    : supabaseStatus.reason === 'secret_key_in_browser' ? 'VITE key is a SECRET key — use the sb_publishable_ key'
    : supabaseStatus.reason === 'bad_url' ? 'VITE_SUPABASE_URL is malformed (https://<ref>.supabase.co)'
    : 'VITE_SUPABASE_URL / key missing — running on local data';

  return (
    <div className="space-y-5 text-slate-100">
      <PageHeader title="Settings" subtitle="Profile, integrations and team" />

      <KpiGrid cols={4}>
        <Kpi icon={<User size={14} />} value={data.profiles.length} label="Team Members" sub={`Signed in as ${currentUser.full_name}`} />
        <Kpi icon={<Shield size={14} />} value={currentUser.role} label="Your Role" sub="Switch from the sidebar" />
        <Kpi icon={<Plug size={14} />} value={supabaseStatus.ok && syncState === 'synced' ? 'Live' : 'Local'} label="Database" sub={supabaseStatus.ok ? 'Supabase' : 'Browser data'} accent={supabaseStatus.ok && syncState === 'synced' ? 'text-emerald-400' : 'text-amber-300'} />
        <Kpi icon={<Plug size={14} />} value={health?.n8n ? 'On' : 'Off'} label="n8n Webhooks" sub={health?.n8n ? 'Configured' : 'Not configured'} accent={health?.n8n ? 'text-emerald-400' : 'text-amber-300'} />
      </KpiGrid>

      <Card>
        <CardHeader><h3 className="text-sm font-semibold flex items-center gap-2"><User size={14} /> User Profile</h3></CardHeader>
        <CardBody className="space-y-3">
          <Input label="Name" value={currentUser.full_name} readOnly />
          <Input label="Email" value={currentUser.email} readOnly />
          <Select label="Role" value={currentUser.role} disabled>
            <option>{currentUser.role}</option>
          </Select>
          <Input label="User ID" value={currentUser.id} readOnly />
          <p className="text-xs text-slate-400">Use the sidebar dropdown to switch users.</p>
        </CardBody>
      </Card>

      <Card>
        <CardHeader><h3 className="text-sm font-semibold flex items-center gap-2"><Zap size={14} /> Automation Rules</h3></CardHeader>
        <CardBody className="space-y-4">
          <p className="text-xs text-slate-400">Run automatically when a lead is created or imported.{!can('settings.admin') && ' Only admins can change these.'}</p>
          {([
            ['autoAssign', 'Auto-assign new leads', 'Round-robin to the salesperson with the fewest open leads.'],
            ['autoFollowUp', 'Auto-create first follow-up task', 'Every new lead gets a task so nothing is forgotten.'],
          ] as const).map(([k, title, sub]) => (
            <label key={k} className="flex items-start justify-between gap-4 rounded-xl border border-white/10 bg-white/[0.03] p-3">
              <span><span className="block text-sm font-medium text-white">{title}</span><span className="block text-xs text-slate-400">{sub}</span></span>
              <input type="checkbox" className="mt-1 h-4 w-4 accent-blue-500" disabled={!can('settings.admin')} checked={auto[k]} onChange={e => setAutoSave({ [k]: e.target.checked } as Partial<AutomationSettings>)} />
            </label>
          ))}
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <Input label="First follow-up due after (hours)" type="number" min={1} disabled={!can('settings.admin')} value={auto.followUpHours} onChange={e => setAuto({ ...auto, followUpHours: Math.max(1, Number(e.target.value) || DEFAULT_AUTOMATION.followUpHours) })} onBlur={() => saveAutomation(auto)} />
            <Input label="Mark leads stale after (days without contact)" type="number" min={1} disabled={!can('settings.admin')} value={auto.staleDays} onChange={e => setAuto({ ...auto, staleDays: Math.max(1, Number(e.target.value) || DEFAULT_AUTOMATION.staleDays) })} onBlur={() => saveAutomation(auto)} />
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardHeader><h3 className="text-sm font-semibold flex items-center gap-2"><Plug size={14} /> Integrations</h3></CardHeader>
        <CardBody>
          <Row label="Supabase (browser)" ok={supabaseStatus.ok && syncState === 'synced'} detail={sbDetail} />
          <Row label="Supabase (server)" ok={!!health?.supabase_server} detail={health ? (health.supabase_server ? 'Service key set' : 'SUPABASE_SERVICE_ROLE_KEY missing') : 'API unreachable'} />
          <Row label="n8n webhooks" ok={!!health?.n8n} detail={health?.n8n ? `${health.n8n_base_host} · ${health.paths.approve} · ${health.paths.bookings} · ${health.paths.regenerate}` : 'N8N_WEBHOOK_BASE / PATH / SECRET missing'} />
        </CardBody>
      </Card>

      <Card>
        <CardHeader><h3 className="text-sm font-semibold flex items-center gap-2"><Rocket size={14} /> Deploy to Vercel</h3></CardHeader>
        <CardBody className="space-y-3">
          <p className="text-xs text-slate-400">First click creates a new Vercel project; every click after that updates the same project and URL.</p>
          {import.meta.env.DEV ? (
            <Button onClick={runDeploy} loading={deploying}><Rocket size={14} /> {deploying ? 'Deploying… (1–2 min)' : 'Deploy'}</Button>
          ) : (
            <p className="text-xs text-slate-400">Run <code>npm run dev</code> locally (or <code>npm run deploy</code>) to publish from here.</p>
          )}
          {deployResult?.ok && <p className="text-sm text-emerald-300">{deployResult.created ? 'New project created. ' : 'Updated. '}<a className="underline" href={deployResult.url} target="_blank" rel="noreferrer">{deployResult.url}</a></p>}
          {deployResult && !deployResult.ok && <p className="text-sm text-rose-400 whitespace-pre-wrap">{deployResult.error}</p>}
        </CardBody>
      </Card>

      <Card>
        <CardHeader><h3 className="text-sm font-semibold flex items-center gap-2"><Shield size={14} /> Team Members & Roles</h3></CardHeader>
        <CardBody>
          <div className={tableWrap}>
            <table className="w-full min-w-[480px] text-sm">
              <thead className={thead}>
                <tr><th className={th}>Name</th><th className={th}>Email</th><th className={th}>Role</th></tr>
              </thead>
              <tbody>
                {data.profiles.map(p => (
                  <tr key={p.id} className={tr}>
                    <td className={td}><span className="flex items-center gap-2.5 font-medium text-white"><Avatar name={p.full_name} />{p.full_name}</span></td>
                    <td className={`${td} text-xs text-slate-300`}>{p.email}</td>
                    <td className={td}><Badge color={p.role === 'Admin' ? 'indigo' : p.role === 'Sales Manager' ? 'purple' : 'gray'}>{p.role}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
