// src/pages/Templates.tsx — message template library with live preview
import React, { useMemo, useState } from 'react';
import { Copy, FileText, Pencil, Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/Button';
import { Input, Textarea } from '../components/ui/Input';
import { Modal } from '../components/ui/Modal';
import { Empty, Kpi, KpiGrid, PageHeader, Panel, PillTabs, gradientBtn } from '../components/ui/kit';
import { TEMPLATE_VARS, loadTemplates, renderTemplate, saveTemplates, type Template } from '../lib/templates';
import { uid } from '../lib/utils';
import { usePermissions } from '../lib/permissions';

export default function Templates() {
  const { currentUser, data } = useApp();
  const { can } = usePermissions();
  const canEdit = can('offer.write');
  const [list, setList] = useState<Template[]>(loadTemplates);
  const [cat, setCat] = useState('all');
  const [editing, setEditing] = useState<Template | null>(null);
  const sampleLead = data.leads.find(l => !l.archived) ?? null;

  const persist = (next: Template[]) => { setList(next); saveTemplates(next); };
  const cats = useMemo(() => [...new Set(list.map(t => t.category).filter(Boolean))], [list]);
  const shown = cat === 'all' ? list : list.filter(t => t.category === cat);

  const save = () => {
    if (!editing) return;
    if (!editing.name.trim() || !editing.body.trim()) { toast.error('Name and message required'); return; }
    const exists = list.some(t => t.id === editing.id);
    persist(exists ? list.map(t => (t.id === editing.id ? editing : t)) : [editing, ...list]);
    setEditing(null);
    toast.success('Template saved');
  };

  return (
    <div className="text-slate-100">
      <PageHeader title="Templates" subtitle="Reusable messages with variables, ready to insert in WhatsApp">
        {canEdit && <button onClick={() => setEditing({ id: uid(), name: '', category: 'Outreach', body: '' })} className={gradientBtn}><Plus size={14} /> New Template</button>}
      </PageHeader>

      <KpiGrid cols={3}>
        <Kpi icon={<FileText size={14} />} value={list.length} label="Templates" sub="In your library" />
        <Kpi value={cats.length} label="Categories" sub={cats.join(' · ') || '—'} />
        <Kpi value={`{{ }}`} label="Variables" sub={TEMPLATE_VARS.map(v => `{{${v}}}`).join(' ')} />
      </KpiGrid>

      <PillTabs value={cat} onChange={setCat} tabs={[{ v: 'all', l: 'All', n: list.length }, ...cats.map(c => ({ v: c, l: c, n: list.filter(t => t.category === c).length }))]} />

      {shown.length === 0 ? <Panel><Empty>No templates yet.</Empty></Panel> : (
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
          {shown.map(t => (
            <Panel key={t.id} title={t.name} icon={<FileText size={15} />} right={<span className="rounded-full border border-white/10 px-2 py-0.5 text-[10px] text-slate-300">{t.category}</span>}>
              <p className="whitespace-pre-wrap rounded-xl border border-white/10 bg-black/20 p-3 text-xs leading-6 text-slate-200">{renderTemplate(t.body, sampleLead, currentUser.full_name)}</p>
              <div className="mt-3 flex gap-2">
                <Button size="sm" variant="secondary" onClick={() => { navigator.clipboard?.writeText(renderTemplate(t.body, sampleLead, currentUser.full_name)); toast.success('Copied'); }}><Copy size={13} /> Copy</Button>
                {canEdit && <Button size="sm" variant="ghost" onClick={() => setEditing(t)}><Pencil size={13} /> Edit</Button>}
                {canEdit && <Button size="sm" variant="ghost" onClick={() => { if (confirm('Delete template?')) persist(list.filter(x => x.id !== t.id)); }}><Trash2 size={13} className="text-rose-400" /></Button>}
              </div>
            </Panel>
          ))}
        </div>
      )}

      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing && list.some(t => t.id === editing.id) ? 'Edit Template' : 'New Template'} width="max-w-2xl">
        {editing && (
          <>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <Input label="Name" value={editing.name} onChange={e => setEditing({ ...editing, name: e.target.value })} />
              <Input label="Category" value={editing.category} onChange={e => setEditing({ ...editing, category: e.target.value })} />
              <div className="md:col-span-2"><Textarea label="Message" className="min-h-[120px]" value={editing.body} onChange={e => setEditing({ ...editing, body: e.target.value })} /></div>
            </div>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {TEMPLATE_VARS.map(v => <button key={v} type="button" onClick={() => setEditing({ ...editing, body: `${editing.body}{{${v}}}` })} className="rounded-full border border-white/10 bg-white/[0.05] px-2.5 py-1 text-[10px] text-slate-300 hover:bg-white/10">{`{{${v}}}`}</button>)}
            </div>
            <p className="mt-3 text-[11px] text-slate-400">Preview{sampleLead ? ` (with ${sampleLead.name})` : ''}:</p>
            <p className="mt-1 whitespace-pre-wrap rounded-xl border border-white/10 bg-black/20 p-3 text-xs text-slate-200">{renderTemplate(editing.body, sampleLead, currentUser.full_name) || '—'}</p>
            <div className="mt-5 flex justify-end gap-2"><Button variant="secondary" onClick={() => setEditing(null)}>Cancel</Button><Button onClick={save}>Save</Button></div>
          </>
        )}
      </Modal>
    </div>
  );
}
