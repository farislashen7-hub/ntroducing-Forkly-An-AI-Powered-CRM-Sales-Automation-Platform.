// src/pages/WhatsApp.tsx
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Card } from '../components/ui/Card';
import { Avatar, Kpi, KpiGrid, PageHeader, darkField } from '../components/ui/kit';
import { Badge, statusColor } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Modal } from '../components/ui/Modal';
import { wipeChatsViaServer } from '../lib/api';
import { supabaseEnabled } from '../lib/supabase';
import { Select, Textarea } from '../components/ui/Input';
import { offerToText } from '../components/OfferCard';
import { toast } from 'sonner';
import { loadTemplates, renderTemplate } from '../lib/templates';
import { Send, MessageCircle, Search, Download, Trash2 } from 'lucide-react';

interface ThreadItem {
  id: string;
  direction: 'inbound' | 'outbound';
  content: string;
  created_at: string;
  status?: string;
}

export default function WhatsApp() {
  const { data, addMessage, addApproval, addConversation, updateLead, logActivity, currentUser, wipeChatsLocal, refresh } = useApp();
  const [params] = useSearchParams();
  const offerParam = params.get('offer');
  const leadParam = params.get('lead');

  const leads = data.leads.filter(l => !l.archived);
  const [selectedId, setSelectedId] = useState<string>(leadParam || '');
  const [search, setSearch] = useState('');
  const [text, setText] = useState('');
  const [offerId, setOfferId] = useState('');
  const endRef = useRef<HTMLDivElement>(null);
  const [wipeOpen, setWipeOpen] = useState(false);
  const [wipeConfirm, setWipeConfirm] = useState('');
  const [wiping, setWiping] = useState(false);
  const isAdmin = currentUser.role === 'Admin';
  const templates = useMemo(() => loadTemplates(), []);

  const waMessages = useMemo(() => data.messages.filter(m => m.message_type === 'whatsapp'), [data.messages]);

  // last activity per lead (conversations + whatsapp messages)
  const lastByLead = useMemo(() => {
    const map: Record<string, { at: string; preview: string }> = {};
    const bump = (leadId: string, at: string, preview: string) => {
      if (!map[leadId] || map[leadId].at < at) map[leadId] = { at, preview };
    };
    data.conversations.forEach(c => bump(c.lead_id, c.created_at, c.content));
    waMessages.forEach(m => bump(m.lead_id, m.created_at, m.content));
    return map;
  }, [data.conversations, waMessages]);

  const chatLeads = leads
    .filter(l => lastByLead[l.id])
    .filter(l => `${l.name} ${l.restaurant_name} ${l.phone}`.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => lastByLead[b.id].at.localeCompare(lastByLead[a.id].at));

  const otherLeads = leads.filter(l => !lastByLead[l.id]);

  // preselect first chat / prefill offer from ?offer=
  useEffect(() => {
    if (!selectedId && chatLeads[0]) setSelectedId(chatLeads[0].id);
    else if (!selectedId && leads[0]) setSelectedId(leads[0].id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [leads.length]);

  useEffect(() => {
    if (!offerParam) return;
    const o = data.offers.find(x => x.id === offerParam);
    if (o) { setOfferId(o.id); setText(offerToText(o)); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [offerParam]);

  const lead = leads.find(l => l.id === selectedId);

  const thread: ThreadItem[] = useMemo(() => {
    if (!lead) return [];
    const items: ThreadItem[] = [
      ...data.conversations.filter(c => c.lead_id === lead.id).map(c => ({ id: c.id, direction: c.direction, content: c.content, created_at: c.created_at })),
      ...waMessages.filter(m => m.lead_id === lead.id).map(m => ({ id: m.id, direction: m.direction, content: m.content, created_at: m.created_at, status: m.status })),
    ];
    return items.sort((a, b) => a.created_at.localeCompare(b.created_at));
  }, [lead, data.conversations, waMessages]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [thread.length, selectedId]);

  const pickOffer = (id: string) => {
    setOfferId(id);
    const o = data.offers.find(x => x.id === id);
    if (o) setText(offerToText(o));
  };

  const send = () => {
    if (!lead) { toast.error('Select a lead'); return; }
    if (!text.trim()) { toast.error('Message is empty'); return; }
    const offer = data.offers.find(o => o.id === offerId);
    const msg = addMessage({ lead_id: lead.id, content: text.trim(), message_type: 'whatsapp', direction: 'outbound', status: 'Pending Approval', provider_message_id: null, objective: offer ? `Offer: ${offer.title}` : 'WhatsApp', simulated: false });
    addApproval({ message_id: msg.id, requested_by: currentUser.id, reviewed_by: null, status: 'Pending', approved_content: null, reviewed_at: null });
    logActivity({ lead_id: lead.id, actor_id: currentUser.id, event_type: 'AI Draft Generated', description: `WhatsApp message submitted for approval: ${lead.name}`, metadata: { messageId: msg.id } });
    setText('');
    setOfferId('');
    toast.success('Submitted for approval');
  };

  const logReply = () => {
    if (!lead) { toast.error('Select a lead'); return; }
    if (!text.trim()) { toast.error('Type the reply first'); return; }
    addConversation({ lead_id: lead.id, direction: 'inbound', content: text.trim() });
    updateLead(lead.id, { last_contact_at: new Date().toISOString() });
    setText('');
    setOfferId('');
    toast.success('Reply logged');
  };

  const wipeAll = async () => {
    if (wipeConfirm.trim().toUpperCase() !== 'WIPE') return;
    setWiping(true);
    if (supabaseEnabled) {
      const r = await wipeChatsViaServer(currentUser.id);
      if (!r.ok) { setWiping(false); toast.error(r.error || 'Failed to wipe chats'); return; }
      if (r.n8n && !r.n8n.ok) toast.warning(`Chats deleted, but n8n returned an error: ${r.n8n.error ?? ''}`);
      else toast.success('All chats wiped');
      wipeChatsLocal();
      await refresh();
    } else {
      wipeChatsLocal();
      toast.success('All chats wiped (local data)');
    }
    setWiping(false); setWipeOpen(false); setWipeConfirm(''); setSelectedId('');
  };

  const leadRow = (l: typeof leads[0]) => (
    <button
      key={l.id}
      onClick={() => setSelectedId(l.id)}
      className={`flex w-full items-center gap-3 border-b border-white/10 px-4 py-3 text-left hover:bg-white/[0.06] ${selectedId === l.id ? 'bg-blue-500/15' : ''}`}
    >
      <Avatar name={l.name} size={36} />
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2">
          <span className="truncate text-sm font-medium text-white">{l.name}</span>
          {lastByLead[l.id] && <span className="shrink-0 text-[10px] text-slate-500">{new Date(lastByLead[l.id].at).toLocaleDateString()}</span>}
        </div>
        <div className="truncate text-xs text-slate-400">{lastByLead[l.id]?.preview || l.restaurant_name}</div>
      </div>
    </button>
  );

  return (
    <div className="text-slate-100">
      <PageHeader title="WhatsApp" subtitle="WhatsApp conversations and messages with your leads">
        {isAdmin && (
          <Button variant="danger" size="sm" onClick={() => setWipeOpen(true)} disabled={chatLeads.length === 0}>
            <Trash2 size={14} /> Wipe all chats
          </Button>
        )}
      </PageHeader>

      <KpiGrid cols={4}>
        <Kpi icon={<MessageCircle size={14} />} value={chatLeads.length} label="Active Chats" sub="Leads with messages" />
        <Kpi icon={<Send size={14} />} value={waMessages.filter(m => m.direction === 'outbound').length} label="Outbound" sub="WhatsApp messages" />
        <Kpi icon={<Download size={14} />} value={data.conversations.filter(c => c.direction === 'inbound').length} label="Inbound Replies" sub="Logged from leads" accent="text-emerald-400" />
        <Kpi icon={<Search size={14} />} value={waMessages.filter(m => m.status === 'Pending Approval').length} label="Awaiting Approval" sub="Drafts in queue" accent="text-amber-300" />
      </KpiGrid>

      <Modal open={wipeOpen} onClose={() => !wiping && setWipeOpen(false)} title="Wipe all chats">
        <div className="space-y-3">
          <p className="text-sm text-white">This permanently deletes all WhatsApp conversations and cannot be undone. Type <b>WIPE</b> to confirm.</p>
          <input
            value={wipeConfirm}
            onChange={e => setWipeConfirm(e.target.value)}
            placeholder="WIPE"
            className={`${darkField} w-full text-sm`}
          />
          <div className="flex justify-end gap-2">
            <Button variant="danger" size="sm" loading={wiping} disabled={wipeConfirm.trim().toUpperCase() !== 'WIPE'} onClick={wipeAll}>Delete everything</Button>
            <Button variant="secondary" size="sm" disabled={wiping} onClick={() => setWipeOpen(false)}>Cancel</Button>
          </div>
        </div>
      </Modal>

      <Card className="overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-[300px_1fr] h-[calc(100vh-22rem)] min-h-[480px]">
          {/* Chat list */}
          <div className="border-r border-white/10 flex flex-col min-h-0">
            <div className="p-3 border-b border-white/10 relative">
              <Search size={14} className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search chats..."
                className={`${darkField} w-full pl-8 placeholder:text-slate-500`}
              />
            </div>
            <div className="flex-1 overflow-y-auto">
              {chatLeads.length === 0 && <p className="text-xs text-slate-400 p-4">No chats yet.</p>}
              {chatLeads.map(leadRow)}
            </div>
            {otherLeads.length > 0 && (
              <div className="p-3 border-t border-white/10">
                <Select label="Start new chat" value="" onChange={e => e.target.value && setSelectedId(e.target.value)}>
                  <option value="">Select lead…</option>
                  {otherLeads.map(l => <option key={l.id} value={l.id}>{l.name} — {l.restaurant_name}</option>)}
                </Select>
              </div>
            )}
          </div>

          {/* Thread */}
          <div className="flex flex-col min-h-0 bg-white/[0.04]">
            {!lead ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center text-slate-400 p-6">
                <MessageCircle size={32} className="mb-2 text-slate-500" />
                <p className="text-sm">{leads.length === 0 ? 'Add a lead first to start a WhatsApp chat.' : 'Select a chat'}</p>
              </div>
            ) : (
              <>
                <div className="px-5 py-3 bg-white/[0.04] border-b border-white/10 flex items-center justify-between">
                  <div>
                    <div className="text-sm font-semibold text-white">{lead.name} <span className="text-xs font-normal text-slate-400">· {lead.restaurant_name}</span></div>
                    <div className="text-xs text-slate-400">{lead.phone}</div>
                  </div>
                  <Link to={`/leads/${lead.id}`} className="text-xs text-blue-300">View lead</Link>
                </div>

                <div className="flex-1 overflow-y-auto p-5 space-y-3 bg-black/20">
                  {thread.length === 0 && <p className="text-xs text-slate-400 text-center">No messages yet.</p>}
                  {thread.map(m => (
                    <div key={m.id} className={`flex ${m.direction === 'outbound' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[75%] px-3 py-2 rounded-2xl text-sm whitespace-pre-wrap ${m.direction === 'outbound' ? 'bg-gradient-to-br from-blue-500 to-indigo-600 text-white' : 'bg-white/[0.08] text-slate-100'}`}>
                        {m.content}
                        <div className="flex items-center justify-end gap-2 mt-1">
                          {m.status && <Badge color={statusColor(m.status)} className="!text-[9px] !py-0">{m.status}</Badge>}
                          <span className="text-[10px] text-slate-400">{new Date(m.created_at).toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                  <div ref={endRef} />
                </div>

                <div className="p-3 bg-white/[0.04] border-t border-white/10 space-y-2">
                  {data.offers.filter(o => o.active).length > 0 && (
                    <Select value={offerId} onChange={e => pickOffer(e.target.value)}>
                      <option value="">Attach an offer…</option>
                      {data.offers.filter(o => o.active).map(o => <option key={o.id} value={o.id}>{o.title}</option>)}
                    </Select>
                  )}
                  <Select value="" onChange={e => { const t = templates.find(x => x.id === e.target.value); if (t) setText(renderTemplate(t.body, lead, currentUser.full_name)); }}>
                    <option value="">Insert a template…</option>
                    {templates.map(t => <option key={t.id} value={t.id}>{t.category} · {t.name}</option>)}
                  </Select>
                  <Textarea value={text} onChange={e => setText(e.target.value)} placeholder="Type a message…" className="min-h-[70px]" />
                  <div className="flex justify-end gap-2">
                    <Button variant="secondary" size="sm" onClick={logReply}><Download size={14} /> Log received reply</Button>
                    <Button size="sm" onClick={send}><Send size={14} /> Send for approval</Button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
}
