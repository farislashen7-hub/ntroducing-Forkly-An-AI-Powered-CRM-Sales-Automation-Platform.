// src/pages/campaigns/AnalyticsTab.tsx — campaign results: sent, delivered, replies, interested, bookings
import React, { useMemo } from 'react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { BarChart3, CalendarCheck, CheckCheck, Heart, MessageSquareReply, Send } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CHART_AXIS, CHART_TIP, Empty, Kpi, KpiGrid, Panel, tableWrap, td, th, thead, tr } from '../../components/ui/kit';
import { Badge, statusColor } from '../../components/ui/Badge';
import { BOOKING_WINDOW_DAYS, REPLY_WINDOW_DAYS, statsForAll, statsForCampaign, statsForWinBack, type CampaignStats } from '../../lib/campaignStats';
import { segmentLabel } from '../../lib/segments';

const pctText = (n: number) => `${n}%`;

export function AnalyticsTab() {
  const { data } = useApp();
  const total = useMemo(() => statsForAll(data), [data]);
  const rows = useMemo(() => {
    const list: { key: string; name: string; sub: string; status?: string; stats: CampaignStats }[] = data.campaigns
      .filter(c => c.status !== 'Draft' && c.status !== 'Cancelled')
      .map(c => ({ key: c.id, name: c.name, sub: `${segmentLabel(c.segment_key)} · ${c.channel}`, status: c.status, stats: statsForCampaign(data, c.id) }));
    const wb = statsForWinBack(data);
    if (wb.recipients > 0) list.push({ key: 'winback', name: 'Win-back messages', sub: 'Individual, approved by staff', stats: wb });
    return list.sort((a, b) => b.stats.sent - a.stats.sent);
  }, [data]);

  const funnel = [
    { step: 'Sent', n: total.sent }, { step: 'Delivered', n: total.delivered }, { step: 'Replied', n: total.replies },
    { step: 'Interested', n: total.interested }, { step: 'Booked', n: total.bookings },
  ];

  return (
    <div>
      <KpiGrid cols={5}>
        <Kpi icon={<Send size={14} />} value={total.sent} label="Messages sent" sub={`${total.recipients} contacts${total.failed ? ` · ${total.failed} failed` : ''}`} />
        <Kpi icon={<CheckCheck size={14} />} value={total.delivered} label="Delivered" sub={`${pctText(total.deliveryRate)} of sent`} accent="text-emerald-400" />
        <Kpi icon={<MessageSquareReply size={14} />} value={total.replies} label="Replies" sub={`${pctText(total.replyRate)} of sent`} />
        <Kpi icon={<Heart size={14} />} value={total.interested} label="Interested" sub="Replied and now qualified" accent="text-violet-300" />
        <Kpi icon={<CalendarCheck size={14} />} value={total.bookings} label="Bookings" sub={`${pctText(total.bookingRate)} of sent`} accent="text-sky-300" />
      </KpiGrid>

      {total.simulated > 0 && <p className="mb-4 rounded-xl border border-amber-400/30 bg-amber-500/10 px-3 py-2 text-xs text-amber-200">{total.simulated} message{total.simulated === 1 ? '' : 's'} were simulated (no WhatsApp provider connected). Numbers are real only after n8n is configured.</p>}

      <div className="mb-5 grid grid-cols-1 gap-5 xl:grid-cols-3">
        <Panel title="Results funnel" icon={<BarChart3 size={15} />} className="xl:col-span-2">
          {total.sent === 0 ? <Empty>No campaign has been sent yet.</Empty> : (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={funnel} margin={{ left: -10, right: 8, top: 8 }}>
                  <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
                  <XAxis dataKey="step" tick={CHART_AXIS} axisLine={false} tickLine={false} />
                  <YAxis allowDecimals={false} tick={CHART_AXIS} axisLine={false} tickLine={false} />
                  <Tooltip {...CHART_TIP} />
                  <Bar dataKey="n" name="Contacts / messages" fill="#3b82f6" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </Panel>
        <Panel title="How results are counted">
          <ul className="list-disc space-y-2 pl-4 text-xs text-slate-400">
            <li><span className="text-slate-200">Sent</span>: accepted by the WhatsApp / SMS / email provider.</li>
            <li><span className="text-slate-200">Delivered</span>: the provider confirmed delivery.</li>
            <li><span className="text-slate-200">Reply</span>: the customer wrote back within {REPLY_WINDOW_DAYS} days.</li>
            <li><span className="text-slate-200">Interested</span>: replied, and the lead is now Interested, Demo Booked, Trial or Converted.</li>
            <li><span className="text-slate-200">Booking</span>: a booking created within {BOOKING_WINDOW_DAYS} days after the message, not cancelled.</li>
          </ul>
        </Panel>
      </div>

      <Panel title="Per campaign" icon={<Send size={15} />}>
        {rows.length === 0 ? <Empty>Campaigns appear here once they are approved.</Empty> : (
          <div className={tableWrap}>
            <table className="w-full text-xs">
              <thead className={thead}>
                <tr><th className={th}>Campaign</th><th className={th}>Status</th><th className={th}>Sent</th><th className={th}>Delivered</th><th className={th}>Replies</th><th className={th}>Interested</th><th className={th}>Bookings</th><th className={th}>Reply rate</th></tr>
              </thead>
              <tbody>
                {rows.map(r => (
                  <tr key={r.key} className={tr}>
                    <td className={td}><span className="block font-medium text-slate-100">{r.name}</span><span className="block text-[10px] text-slate-500">{r.sub}</span></td>
                    <td className={td}>{r.status ? <Badge color={statusColor(r.status)}>{r.status}</Badge> : '—'}</td>
                    <td className={td}>{r.stats.sent}{r.stats.failed > 0 && <span className="ml-1 text-rose-300">({r.stats.failed} failed)</span>}</td>
                    <td className={td}>{r.stats.delivered} <span className="text-slate-500">· {pctText(r.stats.deliveryRate)}</span></td>
                    <td className={td}>{r.stats.replies}</td>
                    <td className={td}>{r.stats.interested}</td>
                    <td className={td}>{r.stats.bookings}</td>
                    <td className={td}>{pctText(r.stats.replyRate)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
    </div>
  );
}
