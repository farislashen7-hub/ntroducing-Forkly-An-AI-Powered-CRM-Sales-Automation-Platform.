// src/pages/campaigns/CampaignBuilder.tsx — create / edit a campaign: name, audience, offer type, message, attachment, schedule, channel.
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { toast } from 'sonner';
import { AlertTriangle, CalendarClock, Check, FileText, Paperclip, Send, ShieldCheck, Upload, X } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Button } from '../../components/ui/Button';
import { Input, Select, Textarea } from '../../components/ui/Input';
import { Panel, glass } from '../../components/ui/kit';
import { WhatsAppPreview, offerToText } from '../../components/OfferCard';
import { supabase } from '../../lib/supabase';
import { TEMPLATE_VARS, loadTemplates } from '../../lib/templates';
import { usePermissions } from '../../lib/permissions';
import {
  BLOCK_LABEL, DEFAULT_UNRESPONSIVE_DAYS, FREQUENCY_CAP_DAYS, SEGMENTS, WINDOW_HOURS, allInterests, renderCampaignText, type BlockReason,
} from '../../lib/segments';
import { emptyCampaign, useCampaignActions, type CampaignDraft } from '../../lib/useCampaignActions';
import type { Campaign, CampaignChannel, CampaignOfferType, SegmentKey } from '../../lib/types';

const OFFER_TYPES: { v: CampaignOfferType; l: string }[] = [
  { v: 'discount', l: 'Discount' }, { v: 'free_trial', l: 'Free trial / consultation' }, { v: 'package', l: 'Package / bundle' },
  { v: 'reminder', l: 'Reminder' }, { v: 'announcement', l: 'Announcement / news' },
];
const CHANNELS: { v: CampaignChannel; l: string }[] = [{ v: 'whatsapp', l: 'WhatsApp' }, { v: 'sms', l: 'SMS' }, { v: 'email', l: 'Email' }];
const MAX_FILE = 10 * 1024 * 1024;
const MAX_LOCAL_FILE = 1.5 * 1024 * 1024; // browser-only mode keeps files inside localStorage
const ACCEPT = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];

/** <input type="datetime-local"> value from an ISO string, in the browser's local time */
const toLocalInput = (iso: string | null) => {
  if (!iso) return '';
  const d = new Date(iso);
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
};

export function CampaignBuilder({ editing, preset, onDone }: { editing: Campaign | null; preset: { segment?: SegmentKey; param?: string | null; offer?: string }; onDone: () => void }) {
  const { currentUser } = useApp();
  const { can } = usePermissions();
  const A = useCampaignActions();
  const { data } = A;
  const [form, setForm] = useState<CampaignDraft>(() => {
    if (editing) { const { id: _i, created_at: _c, updated_at: _u, ...rest } = editing; void _i; void _c; void _u; return rest; }
    const base = emptyCampaign(currentUser.id);
    if (preset.segment) { base.segment_key = preset.segment; base.segment_param = preset.param ?? null; }
    return base;
  });
  const [scheduleMode, setScheduleMode] = useState<'approval' | 'later'>(editing?.scheduled_at ? 'later' : 'approval');
  const [uploading, setUploading] = useState(false);
  const [showBlocked, setShowBlocked] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const set = <K extends keyof CampaignDraft>(k: K, v: CampaignDraft[K]) => setForm(f => ({ ...f, [k]: v }));
  const templates = useMemo(() => loadTemplates(), []);
  const interests = useMemo(() => allInterests(data), [data]);
  const segDef = SEGMENTS.find(s => s.key === form.segment_key)!;

  // fill from ?offer= once
  useEffect(() => {
    if (!preset.offer || editing) return;
    const o = data.offers.find(x => x.id === preset.offer);
    if (o) setForm(f => ({ ...f, offer_id: o.id, name: f.name || o.title, message: offerToText(o) }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [preset.offer]);

  const stats = useMemo(() => A.snapshot(form), [form.segment_key, form.segment_param, form.channel, form.template_name, data]); // eslint-disable-line react-hooks/exhaustive-deps
  const sample = stats.eligible[0] ?? stats.members[0] ?? null;
  const ownerName = data.profiles.find(p => p.id === sample?.assigned_to)?.full_name ?? currentUser.full_name;
  const preview = renderCampaignText(form.message || 'Your message appears here…', sample, ownerName, form.include_optout);
  const blockedReasons = (Object.keys(stats.byReason) as BlockReason[]).filter(r => stats.byReason[r] > 0);

  const pickFile = async (file?: File) => {
    if (!file) return;
    if (!ACCEPT.includes(file.type)) { toast.error('Image (JPG, PNG, WebP) or PDF only'); return; }
    if (file.size > MAX_FILE) { toast.error('Max file size is 10MB'); return; }
    if (!supabase && file.size > MAX_LOCAL_FILE) { toast.error('Without Supabase the file must be under 1.5MB'); return; }
    setUploading(true);
    try {
      let url: string;
      if (supabase) {
        const ext = file.type === 'application/pdf' ? 'pdf' : file.type === 'image/png' ? 'png' : file.type === 'image/webp' ? 'webp' : 'jpg';
        const path = `${crypto.randomUUID()}.${ext}`;
        const { error } = await supabase.storage.from('campaign-files').upload(path, file, { contentType: file.type, cacheControl: '31536000' });
        if (error) throw new Error(`${error.message} (run 005_campaigns.sql in Supabase)`);
        url = supabase.storage.from('campaign-files').getPublicUrl(path).data.publicUrl;
      } else {
        url = await new Promise<string>((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result as string); r.onerror = rej; r.readAsDataURL(file); });
      }
      setForm(f => ({ ...f, attachment_url: url, attachment_name: file.name, attachment_type: file.type === 'application/pdf' ? 'file' : 'image' }));
    } catch (e) {
      toast.error(`Upload failed: ${(e as Error).message}`);
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const payload = (): CampaignDraft => ({
    ...form,
    name: form.name.trim(),
    template_name: form.channel === 'whatsapp' && form.template_name?.trim() ? form.template_name.trim() : null,
    scheduled_at: scheduleMode === 'later' && form.scheduled_at ? form.scheduled_at : null,
    segment_param: form.segment_key === 'unresponsive' ? String(Number(form.segment_param) || DEFAULT_UNRESPONSIVE_DAYS) : form.segment_key === 'interested_service' ? (form.segment_param ?? '') : null,
  });

  const save = (submit: boolean) => {
    const p = payload();
    if (scheduleMode === 'later' && !p.scheduled_at) { toast.error('Pick the date and time to send.'); return; }
    if (form.segment_key === 'interested_service' && !p.segment_param?.trim()) { toast.error('Pick the service / interest for this audience.'); return; }
    const problem = A.validate(p);
    if (problem) { toast.error(problem); return; }
    let camp: Campaign;
    if (editing) {
      A.updateCampaign(editing.id, p);
      camp = { ...editing, ...p };
    } else {
      camp = A.addCampaign(p);
    }
    if (submit) { if (!A.submit(camp)) { toast.message('Saved as draft'); onDone(); return; } } else toast.success('Draft saved');
    onDone();
  };

  const needsTemplate = form.channel === 'whatsapp' && !form.template_name?.trim();

  return (
    <div className="grid grid-cols-1 items-start gap-6 lg:grid-cols-2">
      <div className="space-y-5">
        {/* 1 — name */}
        <Panel title="1 · Campaign" icon={<Send size={15} />}>
          <Input label="Campaign name" placeholder="e.g. Winter checkup offer" value={form.name} onChange={e => set('name', e.target.value)} />
        </Panel>

        {/* 2 — audience */}
        <Panel title="2 · Target audience" icon={<ShieldCheck size={15} />}>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <Select label="Segment" value={form.segment_key} onChange={e => setForm(f => ({ ...f, segment_key: e.target.value as SegmentKey, segment_param: null }))}>
              {SEGMENTS.map(s => <option key={s.key} value={s.key}>{s.label}</option>)}
            </Select>
            {segDef.param === 'days' && <Input label="No reply for (days)" type="number" min={1} value={form.segment_param ?? DEFAULT_UNRESPONSIVE_DAYS} onChange={e => set('segment_param', e.target.value)} />}
            {segDef.param === 'interest' && (
              <div>
                <Input label="Service / interest" list="interest-list" placeholder={interests.length ? 'Pick or type' : 'Tag leads with interests first'} value={form.segment_param ?? ''} onChange={e => set('segment_param', e.target.value)} />
                <datalist id="interest-list">{interests.map(t => <option key={t} value={t} />)}</datalist>
              </div>
            )}
          </div>
          <p className="mt-2 text-[11px] text-slate-400">{segDef.description}</p>

          <div className="mt-3 grid grid-cols-3 gap-2 text-center">
            <div className="rounded-xl border border-white/10 bg-black/20 px-2 py-2"><div className="text-xl font-semibold text-white">{stats.members.length}</div><div className="text-[10px] text-slate-400">In segment</div></div>
            <div className="rounded-xl border border-emerald-400/30 bg-emerald-500/10 px-2 py-2"><div className="text-xl font-semibold text-emerald-300">{stats.eligible.length}</div><div className="text-[10px] text-slate-400">Will be messaged</div></div>
            <div className="rounded-xl border border-amber-400/30 bg-amber-500/10 px-2 py-2"><div className="text-xl font-semibold text-amber-300">{stats.blocked.length}</div><div className="text-[10px] text-slate-400">Skipped</div></div>
          </div>
          {blockedReasons.length > 0 && (
            <div className="mt-3 rounded-xl border border-white/10 bg-black/20 p-3 text-xs">
              <button type="button" className="flex w-full items-center justify-between text-slate-300" onClick={() => setShowBlocked(s => !s)}>
                <span className="flex items-center gap-1.5"><AlertTriangle size={13} className="text-amber-300" /> Why people are skipped</span>
                <span className="text-slate-500">{showBlocked ? 'Hide' : 'Show'}</span>
              </button>
              <ul className="mt-2 space-y-1 text-slate-400">
                {blockedReasons.map(r => <li key={r}>{stats.byReason[r]} · {BLOCK_LABEL[r]}</li>)}
              </ul>
              {showBlocked && (
                <div className="mt-2 max-h-40 space-y-1 overflow-y-auto border-t border-white/10 pt-2 text-slate-300">
                  {stats.blocked.slice(0, 100).map(b => <div key={b.lead.id} className="flex justify-between gap-2"><span className="truncate">{b.lead.name}</span><span className="shrink-0 text-slate-500">{BLOCK_LABEL[b.reason]}</span></div>)}
                </div>
              )}
            </div>
          )}
        </Panel>

        {/* 3 — channel + offer type */}
        <Panel title="3 · Channel & offer type" icon={<Paperclip size={15} />}>
          <div className="mb-3 flex flex-wrap gap-2">
            {CHANNELS.map(c => (
              <button key={c.v} type="button" onClick={() => set('channel', c.v)}
                className={`rounded-full border px-4 py-2 text-xs font-medium ${form.channel === c.v ? 'border-blue-400/60 bg-blue-500/20 text-white' : 'border-white/10 bg-white/[0.03] text-slate-300 hover:bg-white/[0.07]'}`}>{c.l}</button>
            ))}
          </div>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <Select label="Offer type" value={form.offer_type} onChange={e => set('offer_type', e.target.value as CampaignOfferType)}>
              {OFFER_TYPES.map(o => <option key={o.v} value={o.v}>{o.l}</option>)}
            </Select>
            <Select label="Use an offer from the library (optional)" value={form.offer_id ?? ''} onChange={e => {
              const o = data.offers.find(x => x.id === e.target.value);
              setForm(f => ({ ...f, offer_id: o?.id ?? null, ...(o ? { message: offerToText(o), name: f.name || o.title } : {}) }));
            }}>
              <option value="">None</option>
              {data.offers.filter(o => o.active).map(o => <option key={o.id} value={o.id}>{o.title}</option>)}
            </Select>
          </div>
        </Panel>

        {/* 4 — message */}
        <Panel title="4 · Message" icon={<FileText size={15} />}>
          <Textarea label="Message text" className="min-h-[150px]" value={form.message} onChange={e => set('message', e.target.value)} placeholder="Hi {{first_name}}, …" />
          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            {TEMPLATE_VARS.map(v => <button key={v} type="button" onClick={() => set('message', `${form.message}{{${v}}}`)} className="rounded-full border border-white/10 bg-white/[0.05] px-2.5 py-1 text-[10px] text-slate-300 hover:bg-white/10">{`{{${v}}}`}</button>)}
            <select className="h-7 rounded-full border border-white/10 bg-white/[0.05] px-2 text-[10px] text-slate-300" value="" onChange={e => { const t = templates.find(x => x.id === e.target.value); if (t) set('message', t.body); }}>
              <option value="">Insert from Templates…</option>
              {templates.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </div>
          <label className="mt-3 flex items-start gap-2 text-xs text-slate-300">
            <input type="checkbox" className="mt-0.5 h-4 w-4 accent-blue-500" checked={form.include_optout} onChange={e => set('include_optout', e.target.checked)} />
            <span>Add an unsubscribe line (“Reply STOP / أرسل إيقاف”). Replies with these words opt the customer out automatically. Recommended for every marketing message.</span>
          </label>

          {form.channel === 'whatsapp' && (
            <div className="mt-4 rounded-xl border border-white/10 bg-black/20 p-3">
              <div className="mb-2 text-xs font-medium text-white">Approved WhatsApp template</div>
              <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                <div className="md:col-span-2"><Input label="Template name (as approved in Meta)" placeholder="e.g. winter_offer_ar" value={form.template_name ?? ''} onChange={e => set('template_name', e.target.value)} /></div>
                <Select label="Language" value={form.template_language} onChange={e => set('template_language', e.target.value)}>
                  <option value="ar">Arabic (ar)</option><option value="en">English (en)</option><option value="en_US">English US (en_US)</option>
                </Select>
              </div>
              <p className={`mt-2 text-[11px] ${needsTemplate ? 'text-amber-300' : 'text-slate-400'}`}>
                {needsTemplate
                  ? `No template: only customers who wrote to you in the last ${WINDOW_HOURS}h can receive this. Everyone else is skipped.`
                  : 'Customers outside the 24h window receive the approved template. Variables sent to n8n: name, first_name, restaurant.'}
              </p>
            </div>
          )}
        </Panel>

        {/* 5 — attachment */}
        <Panel title="5 · Image or file (optional)" icon={<Upload size={15} />}>
          <input ref={fileRef} type="file" accept={ACCEPT.join(',')} className="hidden" onChange={e => pickFile(e.target.files?.[0])} />
          {form.attachment_url ? (
            <div className="flex items-center gap-3 rounded-xl border border-white/10 bg-black/20 p-2">
              {form.attachment_type === 'image' ? <img src={form.attachment_url} alt="" className="h-14 w-14 rounded-lg object-cover" /> : <div className="flex h-14 w-14 items-center justify-center rounded-lg bg-white/10 text-slate-300"><FileText size={22} /></div>}
              <div className="min-w-0 flex-1 truncate text-xs text-slate-200">{form.attachment_name}</div>
              <button type="button" aria-label="Remove file" onClick={() => setForm(f => ({ ...f, attachment_url: null, attachment_name: null, attachment_type: null }))} className="rounded-lg p-1.5 text-slate-400 hover:bg-white/10 hover:text-rose-300"><X size={15} /></button>
            </div>
          ) : (
            <Button variant="secondary" size="sm" loading={uploading} onClick={() => fileRef.current?.click()}><Upload size={14} /> Choose image or PDF</Button>
          )}
          <p className="mt-2 text-[11px] text-slate-500">JPG, PNG, WebP or PDF, max 10MB. The file is sent to n8n with the campaign.</p>
        </Panel>

        {/* 6 — schedule */}
        <Panel title="6 · When to send" icon={<CalendarClock size={15} />}>
          <div className="flex flex-wrap gap-2">
            {([['approval', 'As soon as it is approved'], ['later', 'Schedule a date and time']] as const).map(([v, l]) => (
              <button key={v} type="button" onClick={() => setScheduleMode(v)}
                className={`rounded-full border px-4 py-2 text-xs font-medium ${scheduleMode === v ? 'border-blue-400/60 bg-blue-500/20 text-white' : 'border-white/10 bg-white/[0.03] text-slate-300 hover:bg-white/[0.07]'}`}>{l}</button>
            ))}
          </div>
          {scheduleMode === 'later' && (
            <div className="mt-3 max-w-xs"><Input label="Send at (your local time)" type="datetime-local" value={toLocalInput(form.scheduled_at)} onChange={e => set('scheduled_at', e.target.value ? new Date(e.target.value).toISOString() : null)} /></div>
          )}
          <p className="mt-2 text-[11px] text-slate-500">A manager approves the campaign first. Nothing is sent before approval.</p>
        </Panel>

        <div className="flex flex-wrap gap-2">
          <Button variant="secondary" onClick={() => save(false)}>Save draft</Button>
          <Button onClick={() => save(true)} disabled={!can('campaign.write')}><Check size={15} /> Submit for approval</Button>
          <Button variant="ghost" onClick={onDone}>Cancel</Button>
        </div>
      </div>

      {/* ---------- preview ---------- */}
      <div className="space-y-5 lg:sticky lg:top-4">
        <WhatsAppPreview text={preview} recipients={stats.eligible.length} caption={`Will reach ${stats.eligible.length} opted-in contact${stats.eligible.length === 1 ? '' : 's'}${sample ? ` · preview for ${sample.name}` : ''}`} />
        {form.attachment_url && form.attachment_type === 'image' && <img src={form.attachment_url} alt="" className="max-h-56 w-full rounded-2xl border border-white/10 object-cover" />}
        <div className={`${glass} space-y-2 p-4 text-xs text-slate-300`}>
          <div className="flex items-center gap-2 font-semibold text-white"><ShieldCheck size={14} className="text-emerald-300" /> Built-in safeguards</div>
          <ul className="list-disc space-y-1 pl-4 text-slate-400">
            <li>Only contacts with recorded opt-in consent are messaged. Opt-outs are always excluded.</li>
            <li>Replies like STOP / إيقاف switch a customer to opted-out automatically.</li>
            <li>WhatsApp: outside the {WINDOW_HOURS}h window only an approved template can be sent.</li>
            <li>At most one marketing message per contact every {FREQUENCY_CAP_DAYS} days.</li>
            <li>Consent is checked again at the moment of sending, not only when you approve.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
