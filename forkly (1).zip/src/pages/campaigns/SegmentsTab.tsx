// src/pages/campaigns/SegmentsTab.tsx — customer segmentation + consent overview + bulk consent recording
import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { Megaphone, ShieldCheck, Users } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Avatar, Empty, Kpi, KpiGrid, Panel, StatusChip, darkField, fmtShort, tableWrap, td, th, thead, tr } from '../../components/ui/kit';
import { Badge } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { usePermissions } from '../../lib/permissions';
import { CONSENT_LABEL, DEFAULT_UNRESPONSIVE_DAYS, SEGMENTS, allInterests, buildCtx, consentOf, interestsOf, segmentLeads } from '../../lib/segments';
import type { SegmentKey } from '../../lib/types';

const BADGE = { opted_in: 'green', opted_out: 'red', unknown: 'gray' } as const;

export function SegmentsTab() {
  const { data, updateLead, logActivity, currentUser } = useApp();
  const { can } = usePermissions();
  const navigate = useNavigate();
  const [key, setKey] = useState<SegmentKey>('interested_not_booked');
  const [days, setDays] = useState(String(DEFAULT_UNRESPONSIVE_DAYS));
  const [interest, setInterest] = useState('');
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [source, setSource] = useState('');
  const [proof, setProof] = useState(false);

  const ctx = useMemo(() => buildCtx(data), [data]);
  const interests = useMemo(() => allInterests(data), [data]);
  const paramFor = (k: SegmentKey) => (k === 'unresponsive' ? days : k === 'interested_service' ? interest : null);
  const counts = useMemo(() => Object.fromEntries(SEGMENTS.map(s => [s.key, segmentLeads(data, s.key, paramFor(s.key), ctx).length])) as Record<SegmentKey, number>, [data, ctx, days, interest]); // eslint-disable-line react-hooks/exhaustive-deps
  const members = useMemo(() => segmentLeads(data, key, paramFor(key), ctx), [data, ctx, key, days, interest]); // eslint-disable-line react-hooks/exhaustive-deps

  const live = data.leads.filter(l => !l.archived);
  const optedIn = live.filter(l => consentOf(l) === 'opted_in').length;
  const optedOut = live.filter(l => consentOf(l) === 'opted_out').length;
  const unknown = live.length - optedIn - optedOut;
  const def = SEGMENTS.find(s => s.key === key)!;

  const toggle = (id: string) => setSelected(s => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });
  const allOn = members.length > 0 && members.every(m => selected.has(m.id));

  const recordConsent = () => {
    const ids = [...selected].filter(id => members.some(m => m.id === id));
    if (!ids.length) return;
    if (!source.trim()) { toast.error('Write the source of the consent (e.g. “signed form at reception”).'); return; }
    if (!proof) { toast.error('Confirm that these customers agreed to receive marketing messages.'); return; }
    const now = new Date().toISOString();
    let n = 0;
    for (const id of ids) {
      const l = data.leads.find(x => x.id === id);
      if (!l || consentOf(l) === 'opted_out') continue; // never flip an opt-out back from a bulk action
      updateLead(id, { consent_status: 'opted_in', consent_at: now, consent_source: source.trim() });
      logActivity({ lead_id: id, actor_id: currentUser.id, event_type: 'Consent Updated', description: `Marketing consent: Opted in (${source.trim()})`, metadata: { status: 'opted_in', source: source.trim(), bulk: true } });
      n++;
    }
    const skipped = ids.length - n;
    toast.success(`Consent recorded for ${n} contact${n === 1 ? '' : 's'}${skipped ? `. ${skipped} opted-out contact${skipped === 1 ? ' was' : 's were'} left unchanged.` : ''}`);
    setSelected(new Set()); setProof(false);
  };

  return (
    <div>
      <KpiGrid cols={4}>
        <Kpi icon={<Users size={14} />} value={live.length} label="Active contacts" sub="Not archived" />
        <Kpi icon={<ShieldCheck size={14} />} value={optedIn} label="Opted in" sub="Can receive marketing" accent="text-emerald-400" />
        <Kpi value={unknown} label="No consent on file" sub="Skipped by campaigns" accent={unknown ? 'text-amber-300' : undefined} />
        <Kpi value={optedOut} label="Opted out" sub="Never messaged" accent={optedOut ? 'text-rose-300' : undefined} />
      </KpiGrid>

      <div className="mb-5 grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-5">
        {SEGMENTS.map(s => (
          <button key={s.key} type="button" onClick={() => { setKey(s.key); setSelected(new Set()); }}
            className={`rounded-2xl border p-4 text-left transition-colors ${key === s.key ? 'border-blue-400/60 bg-blue-500/15' : 'border-white/10 bg-white/[0.03] hover:bg-white/[0.07]'}`}>
            <div className="text-2xl font-semibold text-white">{counts[s.key]}</div>
            <div className="mt-1 text-xs font-medium text-slate-200">{s.label}</div>
            <div className="mt-1 text-[10px] leading-4 text-slate-500">{s.description}</div>
          </button>
        ))}
      </div>

      <Panel
        title={def.label}
        icon={<Users size={15} />}
        right={
          <div className="flex flex-wrap items-center gap-2">
            {def.param === 'days' && <label className="flex items-center gap-1.5 text-[11px] text-slate-400">No reply for <input type="number" min={1} className={`${darkField} w-16`} value={days} onChange={e => setDays(e.target.value)} /> days</label>}
            {def.param === 'interest' && (
              <select className={darkField} value={interest} onChange={e => setInterest(e.target.value)}>
                <option value="">Choose a service…</option>
                {interests.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            )}
            {can('campaign.write') && (
              <Button size="sm" onClick={() => navigate(`/campaigns?tab=new&segment=${key}${paramFor(key) ? `&param=${encodeURIComponent(paramFor(key)!)}` : ''}`)}><Megaphone size={13} /> Create campaign</Button>
            )}
          </div>
        }
      >
        {def.param === 'interest' && interests.length === 0 && <p className="mb-3 text-xs text-amber-300">No lead has an interest tag yet. Add “Interested in” on a lead&apos;s profile.</p>}

        {selected.size > 0 && can('lead.bulk') && (
          <div className="mb-3 space-y-2 rounded-xl border border-white/10 bg-black/20 p-3">
            <div className="text-xs font-medium text-white">Record opt-in consent for {selected.size} selected contact{selected.size === 1 ? '' : 's'}</div>
            <div className="max-w-md"><Input label="Where did the consent come from?" placeholder="e.g. signed form at reception, website checkbox" value={source} onChange={e => setSource(e.target.value)} /></div>
            <label className="flex items-start gap-2 text-xs text-slate-300">
              <input type="checkbox" className="mt-0.5 h-4 w-4 accent-blue-500" checked={proof} onChange={e => setProof(e.target.checked)} />
              <span>I confirm these customers agreed to receive marketing messages from us and I can show proof if asked.</span>
            </label>
            <Button size="sm" onClick={recordConsent}>Record consent</Button>
          </div>
        )}

        {members.length === 0 ? <Empty>Nobody is in this segment right now.</Empty> : (
          <div className={tableWrap}>
            <table className="w-full text-xs">
              <thead className={thead}>
                <tr>
                  {can('lead.bulk') && <th className={th}><input type="checkbox" className="accent-blue-500" checked={allOn} onChange={() => setSelected(allOn ? new Set() : new Set(members.map(m => m.id)))} aria-label="Select all" /></th>}
                  <th className={th}>Contact</th><th className={th}>Stage</th><th className={th}>Consent</th><th className={th}>Interests</th><th className={th}>Last contact</th><th className={th}>Last reply</th>
                </tr>
              </thead>
              <tbody>
                {members.slice(0, 200).map(l => {
                  const c = consentOf(l);
                  const reply = ctx.lastInbound.get(l.id);
                  return (
                    <tr key={l.id} className={tr}>
                      {can('lead.bulk') && <td className={td}><input type="checkbox" className="accent-blue-500" checked={selected.has(l.id)} onChange={() => toggle(l.id)} aria-label={`Select ${l.name}`} /></td>}
                      <td className={td}>
                        <Link to={`/leads/${l.id}`} className="flex items-center gap-2 hover:text-white"><Avatar name={l.name} size={28} /><span><span className="block font-medium text-slate-100">{l.name}</span><span className="block text-[10px] text-slate-500">{l.restaurant_name}</span></span></Link>
                      </td>
                      <td className={td}><StatusChip status={l.status} /></td>
                      <td className={td}><Badge color={BADGE[c]}>{CONSENT_LABEL[c]}</Badge></td>
                      <td className={td + ' max-w-[160px] truncate text-slate-400'}>{interestsOf(l).join(', ') || '—'}</td>
                      <td className={td + ' text-slate-400'}>{fmtShort(l.last_contact_at)}</td>
                      <td className={td + ' text-slate-400'}>{reply ? fmtShort(new Date(reply).toISOString()) : '—'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        {members.length > 200 && <p className="mt-2 text-[11px] text-slate-500">Showing the first 200 of {members.length}.</p>}
      </Panel>
    </div>
  );
}
