// src/pages/campaigns/WinBackTab.tsx — find customers who were interested but went quiet, prepare a return message for each,
// and send every draft to the Approval Center. Nothing is sent from this page.
import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { toast } from 'sonner';
import { Clock, HeartHandshake, Send } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Avatar, Empty, Kpi, KpiGrid, Panel, StatusChip, tableWrap, td, th, thead, tr } from '../../components/ui/kit';
import { Badge, statusColor } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { Input, Select } from '../../components/ui/Input';
import { WhatsAppPreview, formatPrice } from '../../components/OfferCard';
import { usePermissions } from '../../lib/permissions';
import { BLOCK_LABEL, buildCtx, buildWinBackMessage, winBackCandidates, withOptOut, type WinBackLang } from '../../lib/segments';
import { winBackMessages } from '../../lib/campaignStats';

interface Settings { days: number; lang: WinBackLang; template: string; templateLang: string; offerId: string }
const KEY = 'forkly_winback_v1';
const DEFAULTS: Settings = { days: 30, lang: 'ar', template: '', templateLang: 'ar', offerId: '' };
const load = (): Settings => { try { const r = localStorage.getItem(KEY); if (r) return { ...DEFAULTS, ...(JSON.parse(r) as Partial<Settings>) }; } catch { /* ignore */ } return DEFAULTS; };

export function WinBackTab() {
  const { data, addMessage, addApproval, logActivity, currentUser } = useApp();
  const { can } = usePermissions();
  const [s, setS] = useState<Settings>(load);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const upd = (patch: Partial<Settings>) => setS(prev => { const n = { ...prev, ...patch }; try { localStorage.setItem(KEY, JSON.stringify(n)); } catch { /* ignore */ } return n; });

  const ctx = useMemo(() => buildCtx(data), [data]);
  const hasTemplate = s.template.trim() !== '';
  const cands = useMemo(() => winBackCandidates(data, Math.max(1, s.days), { channel: 'whatsapp', hasTemplate }, ctx), [data, s.days, hasTemplate, ctx]);
  const ready = cands.filter(c => !c.block);
  const blockedCount = cands.length - ready.length;
  const offer = data.offers.find(o => o.id === s.offerId && o.active);
  const owner = (assigned: string | null) => data.profiles.find(p => p.id === assigned)?.full_name ?? currentUser.full_name;
  const draftText = (c: (typeof cands)[number]) => withOptOut(buildWinBackMessage(c.lead, c.idleDays, s.lang, owner(c.lead.assigned_to), offer ? `${offer.title}: ${formatPrice(offer.price)}` : ''), true);

  const drafts = useMemo(() => winBackMessages(data).sort((a, b) => b.created_at.localeCompare(a.created_at)), [data]);
  const waiting = drafts.filter(m => m.status === 'Pending Approval').length;
  const sample = ready.find(c => selected.has(c.lead.id)) ?? ready[0];

  const toggle = (id: string) => setSelected(p => { const n = new Set(p); if (n.has(id)) n.delete(id); else n.add(id); return n; });
  const chosen = ready.filter(c => selected.has(c.lead.id));
  const allReadyOn = ready.length > 0 && ready.every(c => selected.has(c.lead.id));

  const prepare = () => {
    if (!chosen.length) return;
    for (const c of chosen) {
      const msg = addMessage({
        lead_id: c.lead.id, content: draftText(c), message_type: 'whatsapp', direction: 'outbound', status: 'Pending Approval',
        provider_message_id: null, objective: 'Win-back', simulated: false, campaign_id: null,
        template_name: hasTemplate ? s.template.trim() : null, template_language: hasTemplate ? s.templateLang : null,
      });
      addApproval({ message_id: msg.id, requested_by: currentUser.id, reviewed_by: null, status: 'Pending', approved_content: null, reviewed_at: null });
      logActivity({ lead_id: c.lead.id, actor_id: currentUser.id, event_type: 'Win-back Drafted', description: `Win-back draft prepared for ${c.lead.name} (${c.idleDays} days without activity)`, metadata: { messageId: msg.id } });
    }
    toast.success(`${chosen.length} win-back draft${chosen.length === 1 ? '' : 's'} sent to the Approval Center`);
    setSelected(new Set());
  };

  return (
    <div>
      <KpiGrid cols={4}>
        <Kpi icon={<HeartHandshake size={14} />} value={cands.length} label="Went quiet" sub={`Interested, no activity ${s.days}+ days`} />
        <Kpi value={ready.length} label="Ready for a draft" sub="Consent OK, rules OK" accent="text-emerald-400" />
        <Kpi value={blockedCount} label="Cannot message" sub="Consent / template / recent message" accent={blockedCount ? 'text-amber-300' : undefined} />
        <Kpi icon={<Clock size={14} />} value={waiting} label="Drafts awaiting approval" sub="Open the Approval Center" accent={waiting ? 'text-amber-300' : undefined} />
      </KpiGrid>

      <div className="mb-5 grid grid-cols-1 gap-5 xl:grid-cols-3">
        <Panel title="Win-back settings" icon={<HeartHandshake size={15} />} className="xl:col-span-2">
          <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
            <Input label="No activity for (days)" type="number" min={1} value={s.days} onChange={e => upd({ days: Math.max(1, Number(e.target.value) || 30) })} />
            <Select label="Message language" value={s.lang} onChange={e => upd({ lang: e.target.value as WinBackLang })}>
              <option value="ar">Arabic</option><option value="en">English</option>
            </Select>
            <Select label="Mention an offer (optional)" value={s.offerId} onChange={e => upd({ offerId: e.target.value })}>
              <option value="">No offer</option>
              {data.offers.filter(o => o.active).map(o => <option key={o.id} value={o.id}>{o.title}</option>)}
            </Select>
            <div className="md:col-span-2"><Input label="Approved WhatsApp template (as named in Meta)" placeholder="e.g. winback_ar" value={s.template} onChange={e => upd({ template: e.target.value })} /></div>
            <Select label="Template language" value={s.templateLang} onChange={e => upd({ templateLang: e.target.value })}>
              <option value="ar">Arabic (ar)</option><option value="en">English (en)</option><option value="en_US">English US (en_US)</option>
            </Select>
          </div>
          <p className={`mt-3 text-[11px] ${hasTemplate ? 'text-slate-400' : 'text-amber-300'}`}>
            {hasTemplate
              ? 'Messages go out as this approved template. The text below is what the staff member reviews and can edit in the Approval Center.'
              : 'Customers who went quiet are almost always outside the 24h WhatsApp window. Without an approved template they cannot be messaged, so they are listed as blocked.'}
          </p>
        </Panel>
        <div>
          {sample
            ? <WhatsAppPreview text={draftText(sample)} recipients={chosen.length || ready.length} caption={`Draft preview for ${sample.lead.name}`} />
            : <Panel title="Draft preview"><Empty>No contact is ready yet.</Empty></Panel>}
        </div>
      </div>

      <Panel
        title={`Customers to win back (${cands.length})`}
        icon={<Send size={15} />}
        right={can('campaign.write') && (
          <Button size="sm" disabled={!chosen.length} onClick={prepare}><Send size={13} /> Prepare {chosen.length || ''} draft{chosen.length === 1 ? '' : 's'} for approval</Button>
        )}
      >
        {cands.length === 0 ? <Empty>Nobody has gone quiet for {s.days} days. 🎉</Empty> : (
          <div className={tableWrap}>
            <table className="w-full text-xs">
              <thead className={thead}>
                <tr>
                  <th className={th}><input type="checkbox" className="accent-blue-500" checked={allReadyOn} disabled={!ready.length} onChange={() => setSelected(allReadyOn ? new Set() : new Set(ready.map(c => c.lead.id)))} aria-label="Select all ready" /></th>
                  <th className={th}>Contact</th><th className={th}>Stage</th><th className={th}>Why</th><th className={th}>Status</th>
                </tr>
              </thead>
              <tbody>
                {cands.slice(0, 200).map(c => (
                  <tr key={c.lead.id} className={tr}>
                    <td className={td}><input type="checkbox" className="accent-blue-500" disabled={!!c.block} checked={selected.has(c.lead.id)} onChange={() => toggle(c.lead.id)} aria-label={`Select ${c.lead.name}`} /></td>
                    <td className={td}><Link to={`/leads/${c.lead.id}`} className="flex items-center gap-2 hover:text-white"><Avatar name={c.lead.name} size={28} /><span><span className="block font-medium text-slate-100">{c.lead.name}</span><span className="block text-[10px] text-slate-500">{c.lead.restaurant_name}</span></span></Link></td>
                    <td className={td}><StatusChip status={c.lead.status} /></td>
                    <td className={td + ' text-slate-400'}>{c.reason}</td>
                    <td className={td}>{c.block ? <Badge color={c.block === 'opted_out' ? 'red' : 'amber'}>{BLOCK_LABEL[c.block]}</Badge> : <Badge color="green">Ready</Badge>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>

      <div className="mt-5">
        <Panel title={`Win-back drafts (${drafts.length})`} icon={<Clock size={15} />} to="/approvals" linkLabel="Approval Center">
          {drafts.length === 0 ? <Empty>No win-back drafts yet.</Empty> : (
            <div className="space-y-2">
              {drafts.slice(0, 8).map(m => {
                const l = data.leads.find(x => x.id === m.lead_id);
                return (
                  <div key={m.id} className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-3 text-xs">
                    <div className="min-w-0"><div className="font-medium text-slate-100">{l?.name ?? 'Lead'}</div><div className="truncate text-slate-400">{m.content}</div></div>
                    <Badge color={statusColor(m.status)}>{m.status}</Badge>
                  </div>
                );
              })}
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}
