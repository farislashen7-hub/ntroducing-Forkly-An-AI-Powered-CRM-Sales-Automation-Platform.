-- RUN_ALL.sql: 001 + 002 + 003 + 004 + 005, safe to run more than once. Paste into Supabase -> SQL Editor -> Run.

-- Forkly CRM — initial schema
create extension if not exists "pgcrypto";

create table if not exists profiles (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  email text not null unique,
  role text not null check (role in ('Admin','Sales Manager','Salesperson','Viewer')),
  created_at timestamptz not null default now()
);

create table if not exists leads (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  restaurant_name text not null,
  phone text not null,
  email text,
  source text not null,
  status text not null check (status in ('New','Contacted','Interested','Demo Booked','Trial','Converted','Lost')),
  assigned_to uuid references profiles(id) on delete set null,
  notes text default '',
  last_contact_at timestamptz,
  next_follow_up_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  archived boolean not null default false
);

create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references leads(id) on delete cascade,
  content text not null,
  message_type text not null default 'whatsapp',
  direction text not null check (direction in ('outbound','inbound')),
  status text not null check (status in ('Drafted','Pending Approval','Approved','Sending','Accepted by Provider','Delivered','Failed')),
  provider_message_id text,
  objective text,
  simulated boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists approvals (
  id uuid primary key default gen_random_uuid(),
  message_id uuid not null references messages(id) on delete cascade,
  requested_by uuid references profiles(id),
  reviewed_by uuid references profiles(id),
  status text not null check (status in ('Pending','Approved','Rejected','Regenerated')),
  approved_content text,
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists bookings (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references leads(id) on delete cascade,
  booking_date date not null,
  booking_time time not null,
  timezone text not null default 'America/New_York',
  status text not null check (status in ('Scheduled','Confirmed','Completed','Cancelled','No-show')),
  assigned_to uuid references profiles(id),
  notes text default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists follow_up_tasks (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references leads(id) on delete cascade,
  title text not null,
  description text default '',
  priority text not null check (priority in ('Low','Medium','High','Urgent')),
  due_at timestamptz not null,
  status text not null check (status in ('Pending','Completed','Cancelled')),
  assigned_to uuid references profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists activity_logs (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references leads(id) on delete set null,
  actor_id uuid references profiles(id),
  event_type text not null,
  description text not null,
  metadata jsonb,
  created_at timestamptz not null default now()
);

create table if not exists conversations (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references leads(id) on delete cascade,
  direction text not null check (direction in ('inbound','outbound')),
  content text not null,
  created_at timestamptz not null default now()
);

-- indexes
create index if not exists idx_leads_status on leads(status);
create index if not exists idx_leads_source on leads(source);
create index if not exists idx_leads_assigned on leads(assigned_to);
create index if not exists idx_bookings_date on bookings(booking_date);
create index if not exists idx_tasks_due on follow_up_tasks(due_at);
create index if not exists idx_activity_lead on activity_logs(lead_id);

-- RLS
alter table profiles enable row level security;
alter table leads enable row level security;
alter table messages enable row level security;
alter table approvals enable row level security;
alter table bookings enable row level security;
alter table follow_up_tasks enable row level security;
alter table activity_logs enable row level security;
alter table conversations enable row level security;

-- permissive demo policies (tighten in production)
drop policy if exists "demo_all_profiles" on profiles;
create policy "demo_all_profiles" on profiles for all using (true) with check (true);
drop policy if exists "demo_all_leads" on leads;
create policy "demo_all_leads" on leads for all using (true) with check (true);
drop policy if exists "demo_all_messages" on messages;
create policy "demo_all_messages" on messages for all using (true) with check (true);
drop policy if exists "demo_all_approvals" on approvals;
create policy "demo_all_approvals" on approvals for all using (true) with check (true);
drop policy if exists "demo_all_bookings" on bookings;
create policy "demo_all_bookings" on bookings for all using (true) with check (true);
drop policy if exists "demo_all_tasks" on follow_up_tasks;
create policy "demo_all_tasks" on follow_up_tasks for all using (true) with check (true);
drop policy if exists "demo_all_activity" on activity_logs;
create policy "demo_all_activity" on activity_logs for all using (true) with check (true);
drop policy if exists "demo_all_conversations" on conversations;
create policy "demo_all_conversations" on conversations for all using (true) with check (true);


-- 002: offers table (used by the app), realtime, and helpful constraints
create table if not exists offers (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  discount_label text not null default '',
  price text not null default '',
  original_price text not null default '',
  valid_until date,
  theme text not null default 'indigo' check (theme in ('indigo','green','amber','rose')),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table offers enable row level security;
drop policy if exists "demo_all_offers" on offers;
create policy "demo_all_offers" on offers for all using (true) with check (true);

-- extra activity types used by the app / n8n are free text already (event_type text)
-- allow the WhatsApp number to be matched quickly by n8n callbacks
create index if not exists idx_leads_phone on leads(phone);
create index if not exists idx_messages_provider on messages(provider_message_id);
create index if not exists idx_messages_lead on messages(lead_id);

-- Realtime: so n8n callbacks (inbound replies, delivery status) appear live in the UI
do $$
declare t text;
begin
  foreach t in array array['leads','messages','approvals','bookings','follow_up_tasks','conversations','activity_logs']
  loop
    begin
      execute format('alter publication supabase_realtime add table %I', t);
    exception when duplicate_object then null;
    end;
  end loop;
end $$;


-- 003: offer image + custom WhatsApp message + new theme names + image storage bucket
alter table offers add column if not exists image_url text;
alter table offers add column if not exists message text not null default '';

alter table offers drop constraint if exists offers_theme_check;
update offers set theme = 'purple' where theme = 'indigo';
alter table offers add constraint offers_theme_check check (theme in ('green','amber','purple','rose'));
alter table offers alter column theme set default 'green';

-- public bucket for offer images (max 3MB, jpg/png/webp)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('offers', 'offers', true, 3145728, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = true, file_size_limit = 3145728, allowed_mime_types = array['image/jpeg','image/png','image/webp'];

drop policy if exists "offers_public_read" on storage.objects;
drop policy if exists "offers_demo_insert" on storage.objects;
create policy "offers_public_read" on storage.objects for select using (bucket_id = 'offers');
create policy "offers_demo_insert" on storage.objects for insert with check (bucket_id = 'offers');


-- 004: make EVERY table live in the browser (Supabase Realtime). Idempotent, safe to re-run.
-- 002 forgot `offers` and `profiles`; this covers all 9 tables the app reads.
do $$
declare t text;
begin
  foreach t in array array['profiles','leads','messages','approvals','bookings','follow_up_tasks','activity_logs','conversations','offers']
  loop
    begin
      execute format('alter publication supabase_realtime add table public.%I', t);
    exception
      when duplicate_object then null;   -- already in the publication
      when undefined_table  then null;   -- table not created yet
    end;
  end loop;
end $$;

-- send full old row on UPDATE/DELETE so the UI can always match the row
do $$
declare t text;
begin
  foreach t in array array['profiles','leads','messages','approvals','bookings','follow_up_tasks','activity_logs','conversations','offers']
  loop
    begin
      execute format('alter table public.%I replica identity full', t);
    exception when undefined_table then null;
    end;
  end loop;
end $$;

-- 005: campaigns, consent, interests, approved-template fields

-- ---- consent + interests on leads (marketing messages need opted_in) ----
alter table leads add column if not exists consent_status text not null default 'unknown';
alter table leads drop constraint if exists leads_consent_status_check;
alter table leads add constraint leads_consent_status_check check (consent_status in ('opted_in','opted_out','unknown'));
alter table leads add column if not exists consent_at timestamptz;
alter table leads add column if not exists consent_source text;
alter table leads add column if not exists interests text[] not null default '{}';

-- ---- campaigns ----
create table if not exists campaigns (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  segment_key text not null default 'interested_not_booked',
  segment_param text,
  offer_type text not null default 'announcement',
  offer_id uuid references offers(id) on delete set null,
  message text not null default '',
  channel text not null default 'whatsapp' check (channel in ('whatsapp','sms','email')),
  template_name text,
  template_language text not null default 'ar',
  attachment_url text,
  attachment_name text,
  attachment_type text check (attachment_type in ('image','file')),
  include_optout boolean not null default true,
  scheduled_at timestamptz,
  status text not null default 'Draft' check (status in ('Draft','Pending Approval','Scheduled','Sending','Sent','Failed','Cancelled')),
  audience_lead_ids uuid[] not null default '{}',
  last_error text,
  created_by uuid references profiles(id) on delete set null,
  approved_by uuid references profiles(id) on delete set null,
  sent_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_campaigns_status on campaigns(status, scheduled_at);

-- ---- messages: link to campaign + approved WhatsApp template ----
alter table messages add column if not exists campaign_id uuid references campaigns(id) on delete set null;
alter table messages add column if not exists template_name text;
alter table messages add column if not exists template_language text;
create index if not exists idx_messages_campaign on messages(campaign_id);

-- ---- RLS (permissive demo policy, same as the other tables: tighten before real customers) ----
alter table campaigns enable row level security;
drop policy if exists "demo_all_campaigns" on campaigns;
create policy "demo_all_campaigns" on campaigns for all using (true) with check (true);

-- ---- realtime ----
do $$
begin
  begin alter publication supabase_realtime add table public.campaigns;
  exception when duplicate_object then null; when undefined_table then null; end;
  begin alter table public.campaigns replica identity full;
  exception when undefined_table then null; end;
end $$;

-- ---- storage: campaign attachments (images + PDF, max 10MB) ----
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('campaign-files', 'campaign-files', true, 10485760, array['image/jpeg','image/png','image/webp','application/pdf'])
on conflict (id) do update set public = true, file_size_limit = 10485760, allowed_mime_types = array['image/jpeg','image/png','image/webp','application/pdf'];

drop policy if exists "campaign_files_public_read" on storage.objects;
drop policy if exists "campaign_files_demo_insert" on storage.objects;
create policy "campaign_files_public_read" on storage.objects for select using (bucket_id = 'campaign-files');
create policy "campaign_files_demo_insert" on storage.objects for insert with check (bucket_id = 'campaign-files');
