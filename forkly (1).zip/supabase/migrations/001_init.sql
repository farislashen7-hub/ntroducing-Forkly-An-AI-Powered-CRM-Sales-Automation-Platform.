-- Forkly CRM — initial schema
create extension if not exists "pgcrypto";

create table if not exists profiles (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  email text not null unique,
  role text not null check (role in ('Admin','Sales Manager','Salesperson','Viewer')),
  created_at timestamptz not null default now()
);

create table if not exists leads (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  restaurant_name text not null,
  phone text not null,
  email text,
  source text not null,
  status text not null check (status in ('New','Contacted','Interested','Demo Booked','Trial','Converted','Lost')),
  assigned_to uuid references profiles(id) on delete set null,
  notes text default '',
  last_contact_at timestamptz,
  next_follow_up_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  archived boolean not null default false
);

create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references leads(id) on delete cascade,
  content text not null,
  message_type text not null default 'whatsapp',
  direction text not null check (direction in ('outbound','inbound')),
  status text not null check (status in ('Drafted','Pending Approval','Approved','Sending','Accepted by Provider','Delivered','Failed')),
  provider_message_id text,
  objective text,
  simulated boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists approvals (
  id uuid primary key default gen_random_uuid(),
  message_id uuid not null references messages(id) on delete cascade,
  requested_by uuid references profiles(id),
  reviewed_by uuid references profiles(id),
  status text not null check (status in ('Pending','Approved','Rejected','Regenerated')),
  approved_content text,
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists bookings (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references leads(id) on delete cascade,
  booking_date date not null,
  booking_time time not null,
  timezone text not null default 'America/New_York',
  status text not null check (status in ('Scheduled','Confirmed','Completed','Cancelled','No-show')),
  assigned_to uuid references profiles(id),
  notes text default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists follow_up_tasks (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references leads(id) on delete cascade,
  title text not null,
  description text default '',
  priority text not null check (priority in ('Low','Medium','High','Urgent')),
  due_at timestamptz not null,
  status text not null check (status in ('Pending','Completed','Cancelled')),
  assigned_to uuid references profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists activity_logs (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references leads(id) on delete set null,
  actor_id uuid references profiles(id),
  event_type text not null,
  description text not null,
  metadata jsonb,
  created_at timestamptz not null default now()
);

create table if not exists conversations (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references leads(id) on delete cascade,
  direction text not null check (direction in ('inbound','outbound')),
  content text not null,
  created_at timestamptz not null default now()
);

-- indexes
create index if not exists idx_leads_status on leads(status);
create index if not exists idx_leads_source on leads(source);
create index if not exists idx_leads_assigned on leads(assigned_to);
create index if not exists idx_bookings_date on bookings(booking_date);
create index if not exists idx_tasks_due on follow_up_tasks(due_at);
create index if not exists idx_activity_lead on activity_logs(lead_id);

-- RLS
alter table profiles enable row level security;
alter table leads enable row level security;
alter table messages enable row level security;
alter table approvals enable row level security;
alter table bookings enable row level security;
alter table follow_up_tasks enable row level security;
alter table activity_logs enable row level security;
alter table conversations enable row level security;

-- permissive demo policies (tighten in production)
create policy "demo_all_profiles" on profiles for all using (true) with check (true);
create policy "demo_all_leads" on leads for all using (true) with check (true);
create policy "demo_all_messages" on messages for all using (true) with check (true);
create policy "demo_all_approvals" on approvals for all using (true) with check (true);
create policy "demo_all_bookings" on bookings for all using (true) with check (true);
create policy "demo_all_tasks" on follow_up_tasks for all using (true) with check (true);
create policy "demo_all_activity" on activity_logs for all using (true) with check (true);
create policy "demo_all_conversations" on conversations for all using (true) with check (true);
