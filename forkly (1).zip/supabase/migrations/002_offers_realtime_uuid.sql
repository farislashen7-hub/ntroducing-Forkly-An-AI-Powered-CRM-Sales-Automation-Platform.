-- 002: offers table (used by the app), realtime, and helpful constraints
create table if not exists offers (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  discount_label text not null default '',
  price text not null default '',
  original_price text not null default '',
  valid_until date,
  theme text not null default 'indigo' check (theme in ('indigo','green','amber','rose')),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table offers enable row level security;
drop policy if exists "demo_all_offers" on offers;
create policy "demo_all_offers" on offers for all using (true) with check (true);

-- extra activity types used by the app / n8n are free text already (event_type text)
-- allow the WhatsApp number to be matched quickly by n8n callbacks
create index if not exists idx_leads_phone on leads(phone);
create index if not exists idx_messages_provider on messages(provider_message_id);
create index if not exists idx_messages_lead on messages(lead_id);

-- Realtime: so n8n callbacks (inbound replies, delivery status) appear live in the UI
do $$
declare t text;
begin
  foreach t in array array['leads','messages','approvals','bookings','follow_up_tasks','conversations','activity_logs']
  loop
    begin
      execute format('alter publication supabase_realtime add table %I', t);
    exception when duplicate_object then null;
    end;
  end loop;
end $$;
