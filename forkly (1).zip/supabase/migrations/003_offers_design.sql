-- 003: offer image + custom WhatsApp message + new theme names + image storage bucket
alter table offers add column if not exists image_url text;
alter table offers add column if not exists message text not null default '';

alter table offers drop constraint if exists offers_theme_check;
update offers set theme = 'purple' where theme = 'indigo';
alter table offers add constraint offers_theme_check check (theme in ('green','amber','purple','rose'));
alter table offers alter column theme set default 'green';

-- public bucket for offer images (max 3MB, jpg/png/webp)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('offers', 'offers', true, 3145728, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = true, file_size_limit = 3145728, allowed_mime_types = array['image/jpeg','image/png','image/webp'];

drop policy if exists "offers_public_read" on storage.objects;
drop policy if exists "offers_demo_insert" on storage.objects;
create policy "offers_public_read" on storage.objects for select using (bucket_id = 'offers');
create policy "offers_demo_insert" on storage.objects for insert with check (bucket_id = 'offers');
