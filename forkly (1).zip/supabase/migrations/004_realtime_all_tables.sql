-- 004: make EVERY table live in the browser (Supabase Realtime). Idempotent, safe to re-run.
-- 002 forgot `offers` and `profiles`; this covers all 9 tables the app reads.
do $$
declare t text;
begin
  foreach t in array array['profiles','leads','messages','approvals','bookings','follow_up_tasks','activity_logs','conversations','offers']
  loop
    begin
      execute format('alter publication supabase_realtime add table public.%I', t);
    exception
      when duplicate_object then null;   -- already in the publication
      when undefined_table  then null;   -- table not created yet
    end;
  end loop;
end $$;

-- send full old row on UPDATE/DELETE so the UI can always match the row
do $$
declare t text;
begin
  foreach t in array array['profiles','leads','messages','approvals','bookings','follow_up_tasks','activity_logs','conversations','offers']
  loop
    begin
      execute format('alter table public.%I replica identity full', t);
    exception when undefined_table then null;
    end;
  end loop;
end $$;
