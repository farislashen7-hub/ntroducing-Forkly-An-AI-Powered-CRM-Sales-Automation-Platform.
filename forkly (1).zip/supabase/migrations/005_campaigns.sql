-- 005: marketing campaigns, customer consent, interests, approved-template fields.
-- Idempotent, safe to re-run. Run after 001-004 (or paste RUN_ALL.sql).

-- ---- consent + interests on leads (marketing messages need opted_in) ----
alter table leads add column if not exists consent_status text not null default 'unknown';
alter table leads drop constraint if exists leads_consent_status_check;
alter table leads add constraint leads_consent_status_check check (consent_status in ('opted_in','opted_out','unknown'));
alter table leads add column if not exists consent_at timestamptz;
alter table leads add column if not exists consent_source text;
alter table leads add column if not exists interests text[] not null default '{}';

-- ---- campaigns ----
create table if not exists campaigns (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  segment_key text not null default 'interested_not_booked',
  segment_param text,
  offer_type text not null default 'announcement',
  offer_id uuid references offers(id) on delete set null,
  message text not null default '',
  channel text not null default 'whatsapp' check (channel in ('whatsapp','sms','email')),
  template_name text,
  template_language text not null default 'ar',
  attachment_url text,
  attachment_name text,
  attachment_type text check (attachment_type in ('image','file')),
  include_optout boolean not null default true,
  scheduled_at timestamptz,
  status text not null default 'Draft' check (status in ('Draft','Pending Approval','Scheduled','Sending','Sent','Failed','Cancelled')),
  audience_lead_ids uuid[] not null default '{}',
  last_error text,
  created_by uuid references profiles(id) on delete set null,
  approved_by uuid references profiles(id) on delete set null,
  sent_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_campaigns_status on campaigns(status, scheduled_at);

-- ---- messages: link to campaign + approved WhatsApp template ----
alter table messages add column if not exists campaign_id uuid references campaigns(id) on delete set null;
alter table messages add column if not exists template_name text;
alter table messages add column if not exists template_language text;
create index if not exists idx_messages_campaign on messages(campaign_id);

-- ---- RLS (permissive demo policy, same as the other tables: tighten before real customers) ----
alter table campaigns enable row level security;
drop policy if exists "demo_all_campaigns" on campaigns;
create policy "demo_all_campaigns" on campaigns for all using (true) with check (true);

-- ---- realtime ----
do $$
begin
  begin alter publication supabase_realtime add table public.campaigns;
  exception when duplicate_object then null; when undefined_table then null; end;
  begin alter table public.campaigns replica identity full;
  exception when undefined_table then null; end;
end $$;

-- ---- storage: campaign attachments (images + PDF, max 10MB) ----
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('campaign-files', 'campaign-files', true, 10485760, array['image/jpeg','image/png','image/webp','application/pdf'])
on conflict (id) do update set public = true, file_size_limit = 10485760, allowed_mime_types = array['image/jpeg','image/png','image/webp','application/pdf'];

drop policy if exists "campaign_files_public_read" on storage.objects;
drop policy if exists "campaign_files_demo_insert" on storage.objects;
create policy "campaign_files_public_read" on storage.objects for select using (bucket_id = 'campaign-files');
create policy "campaign_files_demo_insert" on storage.objects for insert with check (bucket_id = 'campaign-files');
