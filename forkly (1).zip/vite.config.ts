import { defineConfig, loadEnv, type Plugin, type PluginOption } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// Runs the Vercel-style handlers in /api during `npm run dev`, so Supabase + n8n
// work locally exactly like in production. Server env vars are loaded here ONLY
// into the Node process — they are never bundled into the browser build.
function apiDev(serverEnv: Record<string, string>): Plugin {
  return {
    name: 'api-dev',
    configureServer(server) {
      for (const [k, v] of Object.entries(serverEnv)) if (process.env[k] === undefined) process.env[k] = v;
      server.middlewares.use(async (req, res, next) => {
        const url = req.url || '';
        if (url.startsWith('/api/deploy') && req.method === 'POST') {
          // DEV ONLY: "Deploy to Vercel" button in Settings. Never exists in the production build.
          const host = String(req.headers.host || '');
          res.setHeader('content-type', 'application/json');
          if (!/^(localhost|127\.0\.0\.1)(:\d+)?$/.test(host)) { res.statusCode = 403; return res.end(JSON.stringify({ ok: false, error: 'Deploy is only available from localhost' })); }
          try {
            // @ts-expect-error plain ESM script
            const { deploy } = await import('./scripts/deploy-lib.mjs');
            const logs: string[] = [];
            const r = await deploy({ root: process.cwd(), env: process.env, log: (m: string) => { logs.push(m); server.config.logger.info(`[deploy] ${m}`); } });
            res.end(JSON.stringify({ ok: true, ...r, logs }));
          } catch (e) {
            res.statusCode = 500;
            res.end(JSON.stringify({ ok: false, error: (e as Error).message }));
          }
          return;
        }
        if (!url.startsWith('/api/')) return next();
        const name = url.split('?')[0].replace(/^\/api\//, '');
        if (!/^[a-z0-9-]+$/i.test(name)) return next();
        try {
          const mod = await server.ssrLoadModule(`/api/${name}.ts`);
          const chunks: Buffer[] = [];
          for await (const c of req) chunks.push(c as Buffer);
          const headers = new Headers();
          for (const [k, v] of Object.entries(req.headers)) if (v !== undefined) headers.set(k, Array.isArray(v) ? v.join(', ') : v);
          const hasBody = !['GET', 'HEAD'].includes(req.method || 'GET');
          const request = new Request(`http://localhost${url}`, { method: req.method, headers, body: hasBody ? Buffer.concat(chunks) : undefined });
          const response: Response = await mod.default.fetch(request);
          res.statusCode = response.status;
          response.headers.forEach((v, k) => res.setHeader(k, v));
          res.end(Buffer.from(await response.arrayBuffer()));
        } catch (e) {
          server.config.logger.error(`[api/${name}] ${(e as Error).stack || e}`);
          res.statusCode = 500;
          res.setHeader('content-type', 'application/json');
          res.end(JSON.stringify({ ok: false, error: 'Server function crashed — see terminal' }));
        }
      });
    },
  };
}

// https://vite.dev/config/
export default defineConfig(async ({ mode }) => {
  const plugins: PluginOption[] = [react(), tailwindcss()];
  try {
    // @ts-expect-error untyped JS module
    const m = await import('./.vite-source-tags.js');
    plugins.push(m.sourceTags());
  } catch { /* optional dev plugin */ }

  const env = loadEnv(mode, process.cwd(), ['VITE_', 'NEXT_PUBLIC_']);
  // Startup check: shows which Supabase URL the app will really use (a shell/OS variable beats .env.local).
  console.log(`[env] VITE_SUPABASE_URL = ${env.VITE_SUPABASE_URL || '(missing)'}  (folder: ${process.cwd()})`);
  if (process.env.VITE_SUPABASE_URL) {
    console.warn('[env] WARNING: VITE_SUPABASE_URL is set in your OS/shell environment and OVERRIDES .env.local. Remove it, then restart.');
  }
  const processEnvDefines: Record<string, string> = {};
  for (const [key, value] of Object.entries(env)) {
    processEnvDefines[`process.env.${key}`] = JSON.stringify(value);
  }

  plugins.push(apiDev(loadEnv(mode, process.cwd(), '')));

  return {
    plugins,
    envPrefix: ['VITE_', 'NEXT_PUBLIC_'],
    define: processEnvDefines,
  };
})
